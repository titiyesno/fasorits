<div class="section-container accordion" data-section="accordion" style="margin-top: 50px;">
    <section >
        <p class="title" data-section-title><a href="<?php echo base_url();?>index.php/berita/aplikan">Pencarian Berita</a></p>
    </section>
</div>