<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class u extends MX_Controller {

    function __construct() {
        parent::__construct();
        $this->load->driver('session');
        $this->load->helper(array('url'));
        $this->load->library('cart');
        $this->load->model('pemesanan/pemesanan_model');
        $this->load->helper(array('form', 'captcha'));
    }

    function cart() {
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";


        $this->template->set_layout('fe');
        $this->template->title("fasor Sepuluh Nopember");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("cart.php");
    }

    function index($id) {
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('fe');
        $this->template->title("fasor Sepuluh Nopember");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $data['data'] = $this->pemesanan_model->disableDate();
        $data['acara'] = $this->pemesanan_model->jenis_acara();
        $data['slot'] = $this->pemesanan_model->slot($id);
        $data['olahraga'] = $this->pemesanan_model->olahraga($id);
        $this->form_validation->set_rules('name', "Name", 'required');
        $this->form_validation->set_rules('captcha', "Captcha", 'required');
        $userCaptcha = set_value('captcha');
        $word = $this->session->userdata('captchaWord');

        $data['data0'] = $this->pemesanan_model->disableDate();
        if ($this->form_validation->run() == TRUE && strcmp(strtolower($userCaptcha), strtolower($word)) == 0) {
            $this->session->unset_userdata('captchaWord');
            $name = set_value('name');
            $data = array('name' => $name);
            print_r($data);
        } else {
            $vals = array(
                'img_path' => './index/',
                'img_url' => 'http://localhost/captcha/',
                'img_width' => '150',
                'img_height' => 30,
                'expiration' => 7200
            );
            /* Generate the captcha */
            $captcha = create_captcha($vals);
            /* Store the captcha value (or 'word') in a session to retrieve later */
            $this->session->set_userdata('captchaWord', $captcha['word']);
            $this->template->build("u_home.php", $data);
        }
    }

    function fasilitas() {
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('fe');
        $this->template->title("fasor Sepuluh Nopember");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $data['data'] = $this->pemesanan_model->disableDate();
        $data['acara'] = $this->pemesanan_model->jenis_acara();
        $data['slot'] = $this->pemesanan_model->slot();
        $data['kategori'] = $this->pemesanan_model->kategori();
        $data['item'] = $this->pemesanan_model->item(1);
        $this->template->build("fasilitas.php", $data);
    }

    function kategori($id) {
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('fe');
        $this->template->title("fasor Sepuluh Nopember");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $data['data'] = $this->pemesanan_model->disableDate();
        $data['acara'] = $this->pemesanan_model->jenis_acara();
        $data['slot'] = $this->pemesanan_model->slot();
        $data['kategori'] = $this->pemesanan_model->kategori();
        $data['item'] = $this->pemesanan_model->item($id);
        $this->template->build("fasilitas.php", $data);
    }

    function umum() {
        $data['noid'] = $this->input->post("noid");
        $data['nama'] = $this->input->post("nama");
        $data['telp'] = $this->input->post("telp");
        $data['alamat'] = $this->input->post("alamat");
        $data['email'] = $this->input->post("email");
        $id = $this->pemesanan_model->create_data($data, 'pemesan');

        $data2['tanggal'] = $this->input->post("date");
        $data2['slot'] = $this->input->post("slot");
        $data2['lapangan'] = $this->input->post("jenis");
        $data2['pemesan_idpemesan'] = $id;
        $data2['admin_idadmin'] = 1;
        $data2['status'] = 0;
        $this->pemesanan_model->create_data($data2, 'pemesanan');

        if ($cart = $this->cart->contents()):
            foreach ($cart as $item):
                $data = array(
                    'item_sewa_iditem_sewa' => $item['id'],
                    'jumlah' => $item['qty'],
                    'harga' => $item['price'],
                    'pemesanan_idpemesanan' => $id
                );

                // Insert product imformation with order detail, store in cart also store in database. 

                $cust_id = $this->pemesanan_model->create_data($data, 'detil');
            endforeach;
        endif;
    }

    function offer() {
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $data['yidic'] = $this->shop_model->getOfferArticle();
        $this->template->set_layout('fe_2');
        $this->template->title("fasor Sepuluh Nopember");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("u_offers.php", $data);
    }

    function shop($id) {
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $data['kategori'] = $this->produk_model->getallcategori();
        $data['produk'] = $this->produk_model->getproduk($id);
        $this->template->set_layout('fe');
        $this->template->title("fasor Sepuluh Nopember");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("u_buy.php", $data);
    }

    function add() {
        // Set array for send data.
        $insert_data = array(
            'id' => $this->input->post('id'),
            'name' => $this->input->post('name'),
            'price' => $this->input->post('price'),
            'qty' => 1
        );

        // This function add items into cart.
        $this->cart->insert($insert_data);

        // This will show insert data in cart.
        redirect('pemesanan/u/fasilitas');
    }

    function remove($rowid) {
        // Check rowid value.
        if ($rowid === "all") {
            // Destroy data which store in  session.
            $this->cart->destroy();
        } else {
            // Destroy selected rowid in session.
            $data = array(
                'rowid' => $rowid,
                'qty' => 0
            );
            // Update cart data, after cancle.
            $this->cart->update($data);
        }

        // This will show cancle data in cart.
        redirect('pemesanan/u/fasilitas');
    }

    function update_cart() {

        // Recieve post values,calcute them and update
        $cart_info = $_POST['cart'];
        foreach ($cart_info as $id => $cart) {
            $rowid = $cart['rowid'];
            $price = $cart['price'];
            $amount = $price * $cart['qty'];
            $qty = $cart['qty'];

            $data = array(
                'rowid' => $rowid,
                'price' => $price,
                'amount' => $amount,
                'qty' => $qty
            );

            $this->cart->update($data);
        }
        redirect('pemesanan/u/fasilitas');
    }

}
