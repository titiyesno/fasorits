<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class pemesanan_model extends CI_model {

    function __construct() {
        parent::__construct();
    }

    function allevent() {
        $sql = "select concat(pemesanan.tanggal,'T',slot.`start`,':00') as start, concat(pemesanan.tanggal,'T',slot.`end`,':00') as end, jenis_acara.nama as title , jenis_acara.warna as 'borderColor', jenis_acara.warna as 'backgroundColor'
                from 
                pemesanan left join jenis_acara on (jenis_acara.idjenis_acara=pemesanan.keperluan) 
                left join slot on (slot.slot=pemesanan.slot)
                order by slot.`start` DESC
                ";
        //where pemesanan.`status` 
        return $this->query($sql);
    }
    function getAllevent(){
        $sql= "select pemesanan.tanggal,pemesanan.status, slot.`start`, jenis_acara.nama, pemesanan.idpemesanan from  pemesanan left join slot on( pemesanan.slot=slot.slot)  left join jenis_acara on jenis_acara.idjenis_acara=pemesanan.keperluan";
        return $this->query($sql);
    }
    function detil($id){
        $sql = 'select * from detil,item where detil.item_sewa_iditem_sewa=item.iditem_sewa && detil.pemesanan_idpemesanan='.$id;
        return $this->query($sql);
    }
    public function pemesan($id)
    {
        $sql = 'select pemesan.* from pemesanan left join pemesan on (pemesan.idpemesan=pemesanan.pemesan_idpemesan) where pemesanan.idpemesanan='.$id;
        return $this->query($sql);
    }
    public function pemesanan($id)
    {
        $sql = 'select pemesanan.* from pemesanan where pemesanan.idpemesanan='.$id;
        return $this->query($sql);
    }
    public function create_data($data, $tabel) {
        $this->db->insert($tabel, $data);
        return $this->db->insert_id();
    }

    public function jenis_acara() {
        $sql = "select * from jenis_acara";
        return $this->query($sql);
    }

    public function slot($id) {
        $sql = "select * from slot where lapangan=?";
        return $this->query($sql,array($id));
    }
    function olahraga($id) {
        $sql = "select * from lapangan where id=?";
        return $this->query($sql,array($id));
    }
    function disableDate() {
        $sql = "select DATE_FORMAT(pemesanan.tanggal,'%m/%d/%y') as 'date' 
                from pemesanan 
                group by pemesanan.tanggal
                having count(pemesanan.slot)=2";
        return $this->query($sql);
    }
    function kategori(){
        $sql = 'select * from kategori';
        return $this->query($sql);
    }
    public function item($id)
    {
        $sql = 'select * from item where item.kategori_idkategori = '.$id;
        return $this->query($sql);
    }
}
