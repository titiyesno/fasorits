<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class admin extends Admin_Controller {
    
    function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('kuisioner/kuisioner_model');
        $this->load->model('kuisioner/pertanyaan_kuisioner_model');
        $this->load->library('form_validation');
                    //tes
    }
    public function index()
    {
        $data['list_pertanyaan'] = $this->pertanyaan_kuisioner_model->read_pertanyaan_kuisioner();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("tambahkuisioner.php",$data);
    }
    
    public function simpankuisioner()
    {
        $idpertanyaan = $this->input->post('idpertanyaan');
        $idaplikan = $this->input->post('idaplikan');
        
        $temp = $this->kuisioner_model->getLastSubmitID($idaplikan);
        $idsubmit = $temp[0]->ID;
        
        $jumlahpertanyaan = $this->input->post('jmlpertanyaan');
        for($a=1;$a<=$jumlahpertanyaan;$a++)
        {
            $idpertanyaan = $this->input->post('idpertanyaan'.$a);
            $rating = $this->input->post('rating'.$a);
            $this->kuisioner_model->create_kuisioner($idsubmit,$idpertanyaan,$idaplikan,$rating);
        }
        redirect("kuisioner/admin");
    }
    
    public function isikuisioner()
    {   
        $id = $this->session->userdata['logged_in']['id'];
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $temp = $this->kuisioner_model->cekbelumisi($id);
        if($temp[0]->row == 0)
        {
            $this->template->build("kuisioner_terisi.php");
        }
        else
        {
            $data['list_kuisioner'] = $this->kuisioner_model->cekbelumisi($id);
            $this->template->build("isikuisioner.php",$data);
        }
    }
    
    public function hasilkuisioner($id="")
    {   
        $data['pertanyaan'] = $this->pertanyaan_kuisioner_model->read_pertanyaan_by_id($id);
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("hasilkuisioner.php",$data);
    }
    
    public function rekap()
    {   
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("rekap.php");
    }
    
    public function get_data_rekap() {
        $pertanyaan = $this->pertanyaan_kuisioner_model->read_pertanyaan_kuisioner();
        $htmlres='';
        $k = 1;
        $jumlah=0;
        $rekap=array();
        foreach ($pertanyaan as $p)
        {
            $jumlah=0;
            $rekap = [];
            for($a=1;$a<=5;$a++)
            {
                $id = $p->ID_PERTANYAAN_KUISIONER;
                $temp = $this->kuisioner_model->hasil_by_pertanyaan($id ,$a);
                $temp2 = $temp[0]->rate;
                $rekap[$a] = $temp2;
                $jumlah+=$temp2;
            }
            $hasil = ($rekap[1]*1)+($rekap[2]*2)+($rekap[3]*3)+($rekap[4]*4)+($rekap[5]*5);
            $htmlres .= 
                "
                    <tr>
                        <td>$k</td>
                        <td>$p->PERTANYAAN</td>
                        <td>$rekap[1]</td>
                        <td>$rekap[2]</td>
                        <td>$rekap[3]</td>
                        <td>$rekap[4]</td>
                        <td>$rekap[5]</td>
                        <td>".$hasil/$jumlah."</td>
                    </tr>
                ";
            
            $k++;
        }
        echo $htmlres;
    }
    
    public function carihasil() {
        header('Cache-Control: no-cache, must-revalidate');
        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');
        $data = $this->input->post('d');
        $idpertanyaan = $data['idpertanyaan'];
        
        $data = array();
        for($a=1;$a<=5;$a++)
        {
            array_push($data, $this->kuisioner_model->hasil_by_pertanyaan($idpertanyaan,$a));
        }
        echo json_encode(array('hasil'=>$data));
        
    }
    
    public function simpantambahkuisioner()
    {
        $pertanyaan = $this->input->post('pertanyaan');
        $this->pertanyaan_kuisioner_model->create_pertanyaan_kuisioner($pertanyaan);
        redirect('kuisioner/admin');
    }
    
    public function hapus($id="")
    {
        $this->pertanyaan_kuisioner_model->delete_pertanyaan_kuisioner($id);
        redirect('kuisioner/admin');
    }
}

?>
