<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class aplikan extends Aplikan_Controller{
    
    function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('kuisioner/kuisioner_model');
        $this->load->model('kuisioner/pertanyaan_kuisioner_model');
        $this->load->model('kamar/gedung_model');
        $this->load->model('kamar/jeniskamar_model');
        $this->load->library('form_validation');
                    //tes
    }
    public function index()
    {
        $id = $this->session->userdata['logged_in']['id'];
        
        $menu = "hf/menu/menu_pemesan.php";
        $footer = "hf/footer/footer.php";
        $subnav = "hf/subnav/subnavkatalog_aplikan.php";
        $this->template->set_layout('front_end');
        $this->template->title("Kuisioner");
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $temp = $this->kuisioner_model->cekbelumisi($id);
        $data['data_gedung'] = $this->gedung_model->read_gedung();
        $data['list_jeniskamar'] = $this->jeniskamar_model->read_jenis();
        if($temp[0]->row == 0)
        {
            $this->template->build("kuisioner_terisi.php",$data);
        }
        else
        {
            $data['list_kuisioner'] = $this->kuisioner_model->cekbelumisi($id);
            $this->template->build("isikuisioner.php",$data);
        }
    }
    
    public function simpankuisioner()
    {
        $idpertanyaan = $this->input->post('idpertanyaan');
        $idaplikan = $this->input->post('idaplikan');
        
        $temp = $this->kuisioner_model->getLastSubmitID($idaplikan);
        $idsubmit = $temp[0]->ID;
        
        $jumlahpertanyaan = $this->input->post('jmlpertanyaan');
        for($a=1;$a<=$jumlahpertanyaan;$a++)
        {
            $idpertanyaan = $this->input->post('idpertanyaan'.$a);
            $rating = $this->input->post('rating'.$a);
            $this->kuisioner_model->create_kuisioner($idsubmit,$idpertanyaan,$idaplikan,$rating);
        }
        redirect("kuisioner/aplikan");
    }
    
}

?>
