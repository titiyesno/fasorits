<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class pertanyaan_kuisioner_model extends CI_model {
    
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function create_pertanyaan_kuisioner($pertanyaan){

        $data = array(
            'PERTANYAAN' => $pertanyaan,
        );
        $this->db->insert('pertanyaan_kuisioner', $data);    
    }
    
    public function read_pertanyaan_kuisioner(){
        $query = $this->db->get('pertanyaan_kuisioner');
        return $query->result();
    }
    
    public function read_pertanyaan_by_id($id){
        $this->db->where('ID_PERTANYAAN_KUISIONER',$id);
        $query = $this->db->get('pertanyaan_kuisioner');
        return $query->result();
    }
    
    public function update_pertanyaan_kuisioner($id,$pertanyaan){

        $data = array(
            'PERTANYAAN' => $pertanyaan,
        );

        $this->db->where('ID_PERTANYAAN_KUISIONER',$id);
        $result = $this->db->update('pertanyaan_kuisioner', $data);
        return $result; 
    }
    
    public function delete_pertanyaan_kuisioner($id){
        $this->db->where('ID_PERTANYAAN_KUISIONER', $id);
        $this->db->delete('pertanyaan_kuisioner');
    }
}