<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class kuisioner_model extends CI_model {
    
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function create_kuisioner($idsubmit,$idpertanyaan,$idaplikan,$rate){

        $data = array(
            'ID_SUBMIT' => $idsubmit,
            'ID_PERTANYAAN_KUISIONER' => $idpertanyaan,
            'ID_APLIKAN' => $idaplikan,
            'RATE' => $rate,
            'TANGGAL_PENGISIAN' => date("Y-m-d H:i:s"),
        );
        $this->db->insert('kuisioner', $data);    
    }
    
    public function read_kuisioner(){
        $query = $this->db->get('kuisioner');
        return $query->result();
    }
    
    public function update_kuisioner($idkuisioner,$rate){

        $data = array(
            'RATE' => $rate,
            'TANGGAL_PENGISIAN' => date("Y-m-d H:i:s"),
        );

        $this->db->where('ID_KUISIONER',$idkuisioner);
        $result = $this->db->update('kuisioner', $data);
        return $result->result(); 
    }
    
    public function delete_kuisioner($idangsuran){
        $this->db->where('ID_ANGSURAN', $idangsuran);
        $this->db->delete('kuisioner');
    }
    
    public function getLastSubmitID($idaplikan) {
        $query = "select s.ID_SUBMIT as ID from submit s, aplikan a where s.ID_APLIKAN = a.ID_APLIKAN and a.ID_APLIKAN = $idaplikan ORDER BY s.TANGGAL_SUBMIT DESC LIMIT 1";
        return $this->db->query($query)->result();
        
    }
    
    public function hasil_by_pertanyaan($idpertanyaan, $rate) {
        $query = "select count(k.ID_KUISIONER) as rate from kuisioner k where k.id_pertanyaan_kuisioner = $idpertanyaan and k.rate = $rate";
        return $this->db->query($query)->result();
    }
    
    public function cekbelumisi($idaplikan)
    {
        $query = "select * , count(pertanyaan_kuisioner.ID_PERTANYAAN_KUISIONER) as row from pertanyaan_kuisioner WHERE pertanyaan_kuisioner.ID_PERTANYAAN_KUISIONER NOT IN (
                select k.id_pertanyaan_kuisioner 
                from kuisioner k, aplikan a
                where k.ID_APLIKAN = a.ID_APLIKAN and a.ID_APLIKAN = $idaplikan)";
        return $this->db->query($query)->result();
    }
}