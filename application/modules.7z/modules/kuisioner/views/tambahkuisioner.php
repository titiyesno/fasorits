<div id="container oxigenfontblue">
<center><h3 class="oxigenfontblue">Tambah Pertanyaan Kuisioner</h3></center>
<hr>
<form action="<?php echo base_url()?>index.php/kuisioner/admin/simpantambahkuisioner" method="POST" class="custom" >
    <div class="row">
        <div class="large-3 columns">
            <label for="pertanyaan" class="oxigenfont right inline" style="color: black">
                Pertanyaan
            </label>
        </div>
        <div class="large-7 columns">
            <textarea type="text" placeholder="Pertanyaan" id="pertanyaan" name="pertanyaan" required></textarea>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
    <div class="row">
        <center><input class="center button" type="submit" value="Tambahkan" style="border: 0px; margin-top: 30px"></center>
    </div>
</form>
<div class="row">
    <div class="large-3 columns">
        <label for="pertanyaan" class="oxigenfont right inline" style="color: black">
            </label>
    </div>
    <div class="large-7 columns">
        <table style="width: 100%">
            <thead>
                <tr>
                    <th style="width: 15%">No</th>
                    <th style="width: 70%">Daftar Pertanyaan Kuisioner</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $a=1; foreach ($list_pertanyaan as $r) { ?>
                <tr>
                    <td><?php echo $a; ?> </td>
                    <td><?php echo $r->PERTANYAAN; ?></td>
                    <td><a class="button oxigenfont" href="<?php echo base_url(); ?>index.php/kuisioner/admin/hasilkuisioner/<?php echo $r->ID_PERTANYAAN_KUISIONER ?>">Hasil</a></td>
                    <td><a class="button oxigenfont" style="background-color: #e9635b" href="<?php echo base_url(); ?>index.php/kuisioner/admin/hapus/<?php echo $r->ID_PERTANYAAN_KUISIONER ?>">Hapus</a></td>
                </tr>
                <?php $a++; } ?>
            </tbody>
        </table>
    </div>
    <div class="large-2 columns">
    </div>
    
</div>
</div>
        

