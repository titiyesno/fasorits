<script type="text/javascript" src="<?php echo base_url(); ?>static/js/Chart.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.2.min.js"></script>
<script>
    var jml = [];
    var temp;
    var responden = 0;
    $(document).ready(function(){
        
        var tes = {};
        tes.d = {};
        var data_pos = {
          
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        };
        tes.d.idpertanyaan = $("#idpertanyaan").val();
        $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>index.php/kuisioner/admin/carihasil",
        
        data: data_pos,
        success: function(data) {
                for(var a=0; a<data.hasil.length; a++)
                {
                    jml[a] = data.hasil[a][0]['rate'];
                    responden = (responden + parseInt(data.hasil[a][0]['rate']));
                }
                $("#jmlresponden").val(responden );
                $("#buruk").val(data.hasil[0][0]['rate'] );
                $("#kurang").val(data.hasil[1][0]['rate']);
                $("#cukup").val(data.hasil[2][0]['rate'] );
                $("#baik").val(data.hasil[3][0]['rate']);
                $("#memuaskan").val(data.hasil[4][0]['rate']);
                drawBar();
            }
        });
        return false; 
    });
    
    function drawBar()
    {
         data = {
                labels : ["Buruk","Kurang","Cukup","Baik","Memuaskan"],
                datasets : [
                        {
                                fillColor : "rgba(151,187,205,0.5)",
                                strokeColor : "rgba(151,187,205,1)",
                                data : jml
                        }
                ]
        }
        var ctx = document.getElementById("visualization").getContext("2d");
        var kotak = document.getElementById("kotakvisual");
        var myNewChart = new Chart(ctx).Bar(data); 
    }
</script>
<div id="container oxigenfontblue">
<center><h3 class="oxigenfontblue">Hasil Kuisioner</h3></center>
<hr>
<div class="row">
    <div class="large-3 columns">
        <label for="pertanyaan" class="oxigenfont right inline" style="color: black">
            Pertanyaan
        </label>
    </div>
    <div class="large-7 columns ">
        <input type="text" disabled="true" value="<?php echo $pertanyaan[0]->PERTANYAAN ?>" />
    </div>
    <div class="large-2 columns">
    </div>
</div>
<div class="row">
    <div class="large-3 columns">
        <label for="responden" class="oxigenfont right inline" style="color: black">
            Jumlah Responden
        </label>
    </div>
    <div class="large-7 columns ">
        <input type="text" disabled="true" id="jmlresponden" name="jmlresponden" value="" />
    </div>
    <div class="large-2 columns">
    </div>
</div>
<div class="row">
    <div class="large-3 columns">
        <label for="buruk" class="oxigenfont right inline" style="color: black">
            Buruk
        </label>
    </div>
    <div class="large-7 columns ">
        <input type="text" disabled="true" id="buruk" name="buruk" value="" />
    </div>
    <div class="large-2 columns">
    </div>
</div>
<div class="row">
    <div class="large-3 columns">
        <label for="kurang" class="oxigenfont right inline" style="color: black">
            Kurang
        </label>
    </div>
    <div class="large-7 columns ">
        <input type="text" disabled="true" id="kurang" name="kurang" value="" />
    </div>
    <div class="large-2 columns">
    </div>
</div>
<div class="row">
    <div class="large-3 columns">
        <label for="cukup" class="oxigenfont right inline" style="color: black">
            Cukup
        </label>
    </div>
    <div class="large-7 columns ">
        <input type="text" disabled="true" id="cukup" name="cukup" value="" />
    </div>
    <div class="large-2 columns">
    </div>
</div>
<div class="row">
    <div class="large-3 columns">
        <label for="baik" class="oxigenfont right inline" style="color: black">
            Baik
        </label>
    </div>
    <div class="large-7 columns ">
        <input type="text" disabled="true" id="baik" name="baik" value="" />
    </div>
    <div class="large-2 columns">
    </div>
</div>
<div class="row">
    <div class="large-3 columns">
        <label for="memuaskan" class="oxigenfont right inline" style="color: black">
            Memuaskan
        </label>
    </div>
    <div class="large-7 columns ">
        <input type="text" disabled="true" id="memuaskan" name="memuaskan" value="" />
    </div>
    <div class="large-2 columns">
    </div>
</div>

<div class="row" >
    <div class="large-3 columns">
        <label for="memuaskan" class="oxigenfont right inline" style="color: black">
        </label>
    </div>
    <div class="large-7 columns">
        <canvas id="visualization" width=500 height=300 style='width:500px;height:300px;'></canvas>
    </div>
    <div class="large-2 columns">
    </div>
</div>
<div class="row" >
    <div class="large-3 columns">
        <input type="hidden" name="idpertanyaan" id="idpertanyaan" disabled="true" value="<?php echo $pertanyaan[0]->ID_PERTANYAAN_KUISIONER ?>" />
    </div>
    <div class="large-7 columns">
    </div>
    <div class="large-2 columns">
    </div>
</div>
</div>
        

