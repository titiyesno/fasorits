<script>
    function caripenghuni(){
         var data_pos = {
          
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        };
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>index.php/kuisioner/admin/get_data_rekap",
            data: data_pos,
            success: function(data){
                $("tbody#tabel_rekap").html(data);
            }
        });
        return false;
    };
    window.onload = caripenghuni();
</script>
<div id="container oxigenfontblue">
<center><h3 class="oxigenfontblue">Rekap Kuisioner</h3></center>
<hr>
<div class="row" style="min-height: 500px">
<!--    <div class="large-1 columns">
        <label for="gedung" class="oxigenfont right inline" style="color: black">
                </label>
    </div>-->
    <div class="large-12 columns">
        <table style="width: 100%" id="tabel_penghuni">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Pertanyaan Kuisioner</th>
                    <th>Buruk</th>
                    <th>Kurang</th>
                    <th>Cukup</th>
                    <th>Baik</th>
                    <th>Memuaskan</th>
                    <th>Nilai</th>
                </tr>
            </thead>
            <tbody id="tabel_rekap">
                
            </tbody>
        </table>
    </div>
<!--    <div class="large-1 columns">
    </div>-->
</div>

</div>
        

