
<div id="container">
<center><h3 class="oxigenfontblue">Kuisioner</h3></center>
<hr>
<div id="container">
    <form action="<?php echo base_url()?>index.php/kuisioner/aplikan/simpankuisioner" method="POST" class="custom" >
    <div>
        <table style="width: 100%">
            <thead>
                <tr>
                    <th style="width: 5%">No</th>
                    <th style="width: 50%">Pertanyaan</th>
                    <th style="width: 45%">Rating</th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $a=1; foreach ($list_kuisioner as $r) { ?>
                <tr>
                    <td><?php echo $a; ?> </td>
                    <td><?php echo $r->PERTANYAAN; ?></td>
                    <td>
                        <select  name="rating<?php echo $a?>" id="rating">
                            <option value="1">Buruk</option>
                            <option value="2">Kurang</option>
                            <option value="3" selected>Cukup</option>
                            <option value="4">Baik</option>
                            <option value="5">Memuaskan</option>
                        </select>
                    </td>
                    <td><input  type="hidden" name="idpertanyaan<?php echo $a?>" value="<?php echo $r->ID_PERTANYAAN_KUISIONER ?>" /></td>
                </tr>
                <?php $a++; } ?>
            </tbody>
        </table>
    </div>
    <div class="row">
        <center><input class="center button" type="submit" value="Simpan" style="border: 0px; margin-top: 30px"></center>
        <input  type="hidden" name="idaplikan" value="<?php echo $this->session->userdata['logged_in']['id']?>" />
        <input  type="hidden" name="jmlpertanyaan" value="<?php echo $a-1?>" />
    </div>
    </form>
</div>
</div>
        

