<div class="row">
    <ul class="breadcrumbs">
        <li><a href="registrasi">Registrasi</a></li>
        <li class="current"><a href="pilihjeniskamar">Pilih Jenis Kamar</a></li>
        <li><a href="pilihkamar">Pilih Kamar</a></li>
    </ul>
</div>
<div class="row">
    <div class="large-12 columns">
        <?php echo form_open("pindahkamar/admin/formpilihjeniskamar");?>
            <div class="row">
                <div class="row">
                    <center><h3 class="oxigenfontblue">Informasi Pembayaran</h3></center>
                </div>
                <div class="oxigenfontblue">
                    <center>Pembayaran dilakukan secara kontan pada saat daftar ulang ketika diterima. KHUSUS untuk mahasiswa dari jalur masuk BIDIK MISI dapat melakukan pembayaran secara cicilan</center><br/>
                </div>
                <div class="row">
                    <div class="large-4 columns">
                        &nbsp;
                    </div>
                    <div class="large-4 columns">
                        <center><label for="pembayaran">Jenis Pembayaran</label>
                            
                            <select class="medium" id="pembayaran" name="pembayaran">
                                <option value="1">Kontan</option>
                                <?php if($this->session->userdata['program_diterima']=="Bidik Misi"){?>
                                <option value="2">Cicilan 2 kali</option>
                                <option value="3">Cicilan 3 kali</option>
                                <option value="4">Cicilan 4 kali</option>
                                <?php }?>
                            </select>
                        </center>
                    </div>
                    <div class="large-4 columns">
                        &nbsp;
                    </div>
                </div>

            </div>
            <div class="row">
                <center><h3 class="oxigenfontblue">Daftar Jenis Kamar</h3></center>
                <hr>
                <div id="body">
                    <?php foreach ($jenis_kamar as $r) { ?>
                        <div class="large-3 small-6 columns">
                            <center>
                                <ul class="pricing-table">
                                    <li class="title oxigenfontblue"><?php echo $r->nama_jenis_kamar; ?></li>
                                    <li class="description oxigenfontblue">Per Kamar <?php echo $r->quota_kamar; ?> Mahasiswa</li>
                                    <li class="price oxigenfontblue"> Rp. <?php echo $r->harga_kamar; ?></li>
                                    <li class="bullet-item"><?php echo $r->keterangan; ?></li>
                                    <li class="cta-button">
                                        <input type="hidden" value="<?php echo $r->id_jenis_kamar ?>" id="id_jenis_kamar" name="id_jenis_kamar" />
                                        <input type="radio" name="pilih" value="<?php echo $r->id_jenis_kamar; ?>" id="pilih"><label for="pilih">&nbsp</label>
                                    </li>
                                </ul>
                            </center>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <div class="row">
                <div  class="right large-12 columns">
                    <input type="submit" value="Next" class="radius small button"/>
                </div>
            </div>
        </form>
    </div>
</div>

