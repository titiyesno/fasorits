<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Admin extends Admin_Controller {
	function __construct() {
		parent::__construct ();
		$this->load->driver ( 'session' );
		$this->load->helper ( array (
				'url' 
		) );
		$this->load->model ( 'user/model_user' );
		$this->load->model ( 'submit_model' );
		$this->load->model ( 'pindahkamar/aplikan_model' );
		$this->load->model ( 'pindahkamar/kamar_model' );
	}
	public function getsubmitdata() {
		$temp1 = $this->aplikan_model->read_penghuni ();
		$data ["submit"] = $this->getPivot ( $temp1 );
		return $data ["submit"];
	}
	private function getPivot($data) {
		header ( 'Cache-Control: no-cache, must-revalidate' );
		header ( 'Content-type: application/json' );
		$header = "[[";
		foreach ( $data as $value ) {
			foreach ( $value as $key => $sembarang ) {
				$header .= '"' . str_replace ( "_", " ", strtoupper ( $key ) ) . '"';
				break;
			}
			$count = 1;
			foreach ( $value as $key => $sembarang ) {
				if ($count > 1)
					$header .= ',"' . str_replace ( "_", " ", strtoupper ( $key ) ) . '"';
				$count ++;
			}
			$header .= "]";
			break;
		}
		
		foreach ( $data as $value ) {
			$header .= ",[";
			foreach ( $value as $key => $data ) {
				if ($key == "CODE_BOOKING")
					$header .= '"<a href=\'' . base_url () . 'index.php/pindahkamar/admin/pilihkamar/' . $data . '\'>' . $data . '</a>"';
				else
					$header .= '"' . $data . '"';
				break;
			}
			$count = 1;
			foreach ( $value as $key => $data ) {
				if ($count > 1) {
					if ($key == "CODE_BOOKING")
						$header .= ',"<a href=\'' . base_url () . 'index.php/pindahkamar/admin/pilihkamar/' . $data . '\'>' . $data . '</a>"';
					else
						$header .= ',"' . $data . '"';
				}
				$count ++;
			}
			$header .= "]";
		}
		$header .= "]";
		echo $header;
	}
	public function index() {
		$menu = "hf/menu/menu_pengelola.php";
		$footer = "hf/footer/footer.php";
		$this->template->set_layout ( 'back_end' );
		$this->template->title ( "Pindah Kamar" );
		$this->template->set_partial ( "menu", $menu );
		$this->template->set_partial ( "footer", $footer );
		$this->template->build ( "penghuniasrama.php" );
	}
	function pilihkamar($nrp) {
		$this->load->library ( 'session' );
		$aplikan = $this->aplikan_model->getaplikan($nrp);
		
		$data ['kamar'] = $this->kamar_model->getDataKamar ($aplikan[0]->ID_JENIS_KAMAR, $aplikan[0]->JENIS_KEL_APLIKAN, $aplikan[0]->PROGRAM_DITERIMA);
		$data['id_jenis_kamar'] = $aplikan[0]->ID_JENIS_KAMAR;
		$data ["nrp"] = $nrp;
		$menu = "hf/menu/menu_pengelola.php";
		$footer = "hf/footer/footer.php";
		$this->template->set_layout ( 'back_end' );
		$this->template->title ( "Pilih Kamar | ITS Student Dormmitory" );
		$this->template->set_partial ( "menu", $menu );
		$this->template->set_partial ( "footer", $footer );
		$this->template->build ( "pilihkamar.php", $data );
	}
	function pilihallkamar($nrp){
		$aplikan = $this->aplikan_model->getaplikan($nrp);
		$data ['kamar'] = $this->kamar_model->getDataAllKamar ($aplikan[0]->JENIS_KEL_APLIKAN, $aplikan[0]->PROGRAM_DITERIMA);
		$data ["nrp"] = $nrp;
		$menu = "hf/menu/menu_pengelola.php";
		$footer = "hf/footer/footer.php";
		$this->template->set_layout ( 'back_end' );
		$this->template->title ( "Pilih Kamar | ITS Student Dormmitory" );
		$this->template->set_partial ( "menu", $menu );
		$this->template->set_partial ( "footer", $footer );
		$this->template->build ( "pilihkamar.php", $data );
	}
	function formpilihjeniskamar() {
		$this->load->library ( 'session' );
		$data ['id_jenis_kamar'] = $this->input->post ( 'pilih' );
		$data ['pembayaran'] = $this->input->post ( 'pembayaran' );
		$this->session->set_userdata ( "jenis_kamar", $data );
		$this->pilihkamar ();
	}
	function formpilihkamar($code, $id_kamar) {
		$menu = "hf/menu/menu_pengelola.php";
		$footer = "hf/footer/footer.php";
		$this->kamar_model->update ( $code, $id_kamar );
		redirect ( "pemesanan/admin/lihatsubmit/".$code);
	}
	public function pindah() {
		$id = $this->input->post ( 'idaplikan' );
		$gedung = $this->input->post ( 'gedung' );
		$nomor = $this->input->post ( 'nomor' );
		$this->model_tiket->update_aplikan ( $id, $gedung, $nomor );
		redirect ( 'pindahkamar/admin/lihat' );
	}
	public function detil() {
		$data ["aplikan"] = $this->aplikan_model->read_aplikan ();
		$menu = "hf/menu/menu_pengelola.php";
		$subnav = "subnav.php";
		$footer = "hf/footer/footer.php";
		$this->template->set_layout ( 'back_end' );
		$this->template->title ( "Data Penghuni" );
		$this->template->set_partial ( "menu", $menu );
		$this->template->set_partial ( "subnav", $subnav );
		$this->template->set_partial ( "footer", $footer );
		$this->template->build ( "detil_penghuni.php" );
	}
}
?>


