<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class kamar_model extends CI_model {

    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    public function getDataKamar($jenis_kamar, $program_diterma, $jenis_kelamin) {
    
    	$sql = "select DISTINCT kamar.ID_KAMAR, kamar.*,  available_room.*, gedung.*, available_room.AVAILABLE as '_AVAILABLE', view_jenis_kamar.* from available_room inner join kamar on (available_room.ID_KAMAR=kamar.ID_KAMAR) left join gedung on (gedung.ID_GEDUNG=kamar.ID_GEDUNG) left join view_jenis_kamar on (view_jenis_kamar.nama_jenis_kamar=available_room.nama_jenis_kamar)
    	where kamar.id_jenis_kamar='$jenis_kamar' and gedung.JENIS_GEDUNG LIKE '%$program_diterma%' and gedung.JENIS_GEDUNG LIKE '%$jenis_kelamin%' 
    	group by kamar.ID_KAMAR
    	";
    	return $this->query($sql);
    }
    public function getDataAllKamar($program_diterma, $jenis_kelamin) {
    
    	$sql = "select DISTINCT kamar.ID_KAMAR, kamar.*,  available_room.*, gedung.*, available_room.AVAILABLE as '_AVAILABLE', view_jenis_kamar.* from available_room inner join kamar on (available_room.ID_KAMAR=kamar.ID_KAMAR) left join gedung on (gedung.ID_GEDUNG=kamar.ID_GEDUNG) left join view_jenis_kamar on (view_jenis_kamar.nama_jenis_kamar=available_room.nama_jenis_kamar)
    	where gedung.JENIS_GEDUNG LIKE '%$program_diterma%' and gedung.JENIS_GEDUNG LIKE '%$jenis_kelamin%'
    	group by kamar.ID_KAMAR
    	";
    	return $this->query($sql);
    }
    public function getJenisKamar() {
        $sql = "select * from jenis_kamar";
        return $this->query($sql);
    }

    public function getGedung() {
        $sql = "select gedung.ID_GEDUNG, gedung.NAMA_GEDUNG from gedung";
        return $this->query($sql);
    }

    public function getKamar() {
        $sql = "select kamar.NOMER_KAMAR, jenis_kamar.nama_jenis_kamar, jenis_kamar.nama_jenis_kamar, jenis_kamar.quota_kamar, jenis_kamar.harga_kamar from kamar, jenis_kamar where kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar and kamar.LANTAI=1 and kamar.ID_GEDUNG=2";
        return $this->query($sql);
    }

    public function getLantai() {
        $sql = "select DISTINCT(kamar.LANTAI) as lantai from kamar order by kamar.LANTAI ASC";
        return $this->query($sql);
    }

    public function getsumit() {
        $sql = "select submit.ID_SUBMIT, submit.TANGGAL_SUBMIT, submit.STATUS_SUBMIT,aplikan.NAMA_APLIKAN, aplikan.NRP_APLIKAN, aplikan.PROGRAM_DITERIMA, aplikan.NRP_APLIKAN,jenis_kamar.nama_jenis_kamar, kamar.NOMER_KAMAR, kamar.LANTAI, gedung.NAMA_GEDUNG, periode.NAMA_PERIODE 
                from submit, aplikan, kamar, jenis_kamar, periode,jenis_submit, gedung
                where submit.ID_APLIKAN=aplikan.ID_APLIKAN and submit.ID_KAMAR=kamar.ID_KAMAR and kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar
                and kamar.ID_GEDUNG=gedung.ID_GEDUNG and submit.ID_JENIS_SUMBIT=jenis_submit.ID_JENIS_SUMBIT and submit.ID_PERIODE=periode.ID_PERIODE";
        return $this->query($sql);
    }

	    function update($code, $id_kamar) {
	    	$sql ='select * from aplikan where NRP_APLIKAN=?';
	    	$aplikan = $this->query($sql,array($code));
	    	$data = array(
	            'ID_KAMAR' => $id_kamar
	        );
	        $this->db->where('ID_APLIKAN', $aplikan[0]->ID_APLIKAN);
	        $this->db->update('submit', $data);
	    }

    /*function getDataKamar($nrp) {
	$sql = "select available_room.*, gedung.NAMA_GEDUNG, kamar.LANTAI,gedung.KETERANGAN_GEDUNG, jenis_kamar.id_jenis_kamar from jenis_kamar  
left join kamar on (kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar) 
left join gedung on (gedung.ID_GEDUNG=kamar.ID_GEDUNG)
left join submit on (kamar.ID_KAMAR=submit.ID_KAMAR) 
left join aplikan on (submit.ID_APLIKAN=aplikan.ID_APLIKAN) 
left join available_room on (available_room.id_jenis_kamar=jenis_kamar.id_jenis_kamar)
where aplikan.NRP_APLIKAN=?";
//echo $sql;
//        $sql = "select DISTINCT kamar.ID_KAMAR,kamar.NOMER_KAMAR, kamar.LANTAI, kamar.KETERANGAN_KAMAR, jenis_kamar.nama_jenis_kamar, jenis_kamar.quota_kamar, jenis_kamar.harga_kamar, jenis_kamar.keterangan, gedung.NAMA_GEDUNG, gedung.KETERANGAN_GEDUNG, gedung.JENIS_GEDUNG, available_room.AVAILABLE from kamar left join jenis_kamar on (kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar) left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG) left join available_room on (available_room.ID_KAMAR=kamar.ID_KAMAR) left join submit on (submit.ID_KAMAR=kamar.ID_KAMAR) left join aplikan on (submit.ID_APLIKAN=aplikan.ID_APLIKAN) where gedung.JENIS_GEDUNG LIKE concat('%',aplikan.JENIS_KEL_APLIKAN,'%') and gedung.JENIS_GEDUNG LIKE concat('%',aplikan.PROGRAM_DITERIMA,'%') and aplikan.NRP_APLIKAN=? group by kamar.ID_KAMAR";
        return $this->query($sql, array($nrp));
    }*/

}

