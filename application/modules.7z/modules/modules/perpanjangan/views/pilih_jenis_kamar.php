<div class="row shadowborder">
    <div class="large-12 columns" id="container">
        <form class="custom">
            <div class="row">
                <div class="row">
                    <center><h3 class="oxigenfontblue">Informasi Pembayaran</h3></center>
                </div>
                <div class="row oxigenfontblue">

                    <center>Pembayaran dilakukan secara kontan pada saat daftar ulang ketika diterima. KHUSUS untuk mahasiswa dari jalur masuk BIDIK MISI dapat melakukan pembayaran secara cicilan</center><br/>

                </div>
                <div class="row">
                    <div class="large-4 columns">
                        &nbsp;
                    </div>
                    <div class="large-4 columns">
                        <center><label for="pembayaran">Jenis Pembayaran</label>
                            <select class="medium" id="pembayaran" name="pembayaran">
                                <option>Kontan</option>
                                <option>Cicilan 2 kali</option>
                                <option>Cicilan 3 kali</option>
                                <option>Cicilan 4 kali</option>
                            </select></center>
                    </div>
                    <div class="large-4 columns">
                        &nbsp;
                    </div>
                </div>

            </div>
            <div class="row">
                <center><h3 class="oxigenfontblue">Daftar Jenis Kamar</h3></center>
                <hr>
                <div id="body">
                    <?php foreach ($jenis_kamar as $r) { ?>
                        <div class="large-3 small-6 columns">
                            <center>
                                <ul class="pricing-table">
                                    <li class="title oxigenfontblue"><?php echo $r->nama_jenis_kamar; ?></li>
                                    <li class="description oxigenfontblue">Per Kamar <?php echo $r->quota_kamar; ?> Mahasiswa</li>
                                    <li class="price oxigenfontblue"> Rp.  <?php echo $r->harga_kamar; ?></li>
                                    <li class="bullet-item"><?php echo $r->keterangan; ?></li>
                                    <li class="cta-button">
                                        <input class="button" type="radio" name="pilih" value="<?php echo $r->id_jenis_kamar; ?>" id="pilih"><label for="pilih">&nbsp</label>
                                    </li>
                                </ul>
                            </center>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </form>
        <div class="row">
            <div  class="right large-12 columns">
                <a href="perjanjian" class="right radius round button">Next</a>    
            </div>
        </div>
    </div>
</div>

