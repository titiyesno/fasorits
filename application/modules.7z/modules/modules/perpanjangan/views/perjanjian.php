<div class="row shadowborder">
    <div class="row">
        <div class="large-12 columns">
            <div class="large-6 columns"></div>
            <div class="large-6 columns">
                <div class="panel"  style="background-color: whitesmoke; overflow: auto ">
                    <div class="large-4 columns oxigenfontblue" style="line-height: 140%;">
                        NO. DOK<br/>    
                        REVISI<br/>
                        TGL. TERBIT<br/>
                        HALAMAN<br/>
                    </div>
                    <div class="large-8 columns oxigenfontblue" style="line-height: 140%;">
                        : FM-ASR.ADM.PMB- 15<br/>
                        : 02<br/>
                        : 07 Januari 2012<br/>
                        : 1 dari 1<br/>    
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="padding: 30px 30px 30px 30px;">
        <center>
            <h3 class="oxigenfontblue">SURAT PERJANJIAN</h3>
            <h6 class="oxigenfontblue"> No:_______/IT2.25/RT/2013</h6>
        </center>
        <div class="large-12 columns" style="font-family: 'Oxygen', sans-serif;">
            <hr size="100">
            <p >
                Pada hari ini : Senin tanggal : 24 Nopember 2013 yang bertanda tangan dibawah ini :                
            </p>
            <div class="row">
                <div class="large-1 columns">1</div>
                <div class="large-1 columns">
                    Nama<br/>
                    Jabaran<br/>
                    Alamat<br/>
                </div>
                <div class="large-10 columns">
                    : Ir. Aggus Zuhdi MF, M.Eng. Ph.D<br/>
                    : Kepala UPT. Asrama Mahasiswa ITS <br/>
                    : Jalan Teknik Elektro, Sukolilo, Surabaya, 60111 <br/>
                </div>
            </div>
            <p>Selanjutnya akan disebut sebagai <b>PIHAK PERTAMA</b></p>
            <div class="row">
                <div class="large-1 columns">2</div>
                <div class="large-1 columns">
                    Nama<br/>
                    Jurusan<br/>
                    NRP<br/>
                    Alamat Asal<br/>
                </div>
                <div class="large-10 columns">
                    : Mahasiswa<br/>
                    : Teknik Informatika <br/>
                    : 5109100145<br/>
                    : Kediri<br/>
                </div>
            </div>
            <p>Selanjutnya akan disebut sebagai <b>PIHAK KEDUA</b></p>
            <div class="row">
                1. PIHAK PERTAMA dan PIHAK KEDUA telah melakukan kesepakatan bersama tentang persetujuan untuk tinggal si asrama mahasiswa ITS dan bersedai mematuhi tata tertib yang berlaku.<br/>
                2. PIHAK PERTAMA menyediakan tempat tingal sewa kamar di Asama Mahasiswa seperti yang telah disetujui PIHAK KEDUA, 1 (satu) Kamar untuk 2 Orang
            </div>
        </div>
        <a href="../../" class="right radius round button">Finish</a>
    </div>

</div>