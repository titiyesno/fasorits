<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class aplikan extends Aplikan_Controller {

    private $path = "aplikan/";

    function __construct() {
        parent::__construct();
        $this->load->driver('session');
        $this->load->helper(array('url'));
        $this->load->model('pemesanan/akun_model');
        $this->load->model('pemesanan/aplikan_model');
        $this->load->model('pemesanan/kamar_model');
    }

    function index() {
        $menu = "hf/menu/menu_pemesan.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('single_usercontrol');
        $this->template->title("Register");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("aplikan/register.php");
    }

    public function pilihjeniskamar() {
        $menu = "hf/menu/menu_pemesan.php";
        $footer = "hf/footer/footer.php";
        $data['kamar'] = $this->kamar_model->getKamar();
        $data['gedung'] = $this->kamar_model->getGedung();
        $data['jenis_kamar'] = $this->kamar_model->getJenisKamar();
        $data['lantai'] = $this->kamar_model->getLantai();
        $this->template->set_layout('single_usercontrol');
        $this->template->title("Pilih Kamar | ITS Student Dormmitory");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("aplikan/pilihjeniskamar.php", $data);
    }

    public function registrasi() {
        $akun['USERNAME'] = addslashes($this->input->post('username'));
        $akun['PASSWORD'] = addslashes($this->input->post('password'));
        $akun['PERTANYAAN_AKUN'] = addslashes($this->input->post('question'));
        $akun['JAWABAN'] = addslashes($this->input->post('answer'));
        $akun['EMAIL'] = addslashes($this->input->post('email'));
        $aplikan['NRP_APLIKAN'] = addslashes($this->input->post('nrp'));
        $aplikan['NAMA_APLIKAN'] = addslashes($this->input->post('nama'));
        $aplikan['TEMPAT_LAHIR_APLIKAN'] = addslashes($this->input->post('tempat'));
        $aplikan['TGL_LAHIR_APLIKAN'] = '2013-11-25'; //addslashes($this->input->post('tanggal'));
        $aplikan['JENIS_KEL_APLIKAN'] = addslashes($this->input->post('jenis_kelamin'));
        $aplikan['AGAMA_APLIKAN'] = addslashes($this->input->post('agama'));
        $aplikan['ALAMAT_APLIKAN'] = addslashes($this->input->post('alamat'));
        $aplikan['TELP_APLIKAN'] = addslashes($this->input->post('telp'));
        $aplikan['JURUSAN_APLIKAN'] = addslashes($this->input->post('jurusan'));
        $aplikan['FAKULTAS_APLIKAN'] = addslashes($this->input->post('fakultas'));
        $aplikan['PROGRAM_DITERIMA'] = addslashes($this->input->post('programditerima'));
        $aplikan['NAMA_ORANGTUA'] = addslashes($this->input->post('parrent_name'));
        $aplikan['ALAMAT_ORANGTUA'] = addslashes($this->input->post('parrent_address'));
        $aplikan['TELP_ORANGTUA'] = addslashes($this->input->post('parrent_telp'));
        $aplikan['PEKERJAAN_ORANTUA'] = addslashes($this->input->post('parrent_job'));
        $idn = $this->akun_model->insert($akun);
            if (isset($idn->ID_AKUN) && $idn->ID_AKUN != 0) {
                $aplikan['ID_APLIKAN'] = $idn->ID_AKUN;
                $aplikan['ID_AKUN'] = $idn->ID_AKUN;
                $this->aplikan_model->insert($aplikan);
                $this->perjanjian();
            } else {
                $this->index();
            }
    }
    function pilihkamar()
    {
        $menu = "hf/menu/menu_pemesan.php";
        $footer = "hf/footer/footer.php";
        $data['kamar'] = $this->kamar_model->getKamar();
        $data['gedung'] = $this->kamar_model->getGedung();
        $data['jenis_kamar'] = $this->kamar_model->getJenisKamar();
        $data['lantai'] = $this->kamar_model->getLantai();
        $this->template->set_layout('single_usercontrol');
        $this->template->title("Pilih Kamar | ITS Student Dormmitory");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("aplikan/pilihkamar.php", $data);
    }
    function perjanjian() {
        $menu = "hf/menu/menu_pemesan.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('single_usercontrol');
        $this->template->title("Register");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("aplikan/perjanjian.php");
    }

    public function pivot() {
        $data = $this->aplikan_model->getdata();
        $this->getPivot($data);
    }

}
?>

