<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class admin extends Admin_Controller {

    private $status_submit = array();

    function __construct() {
        parent::__construct();
        $this->load->driver('session');
        $this->load->helper(array('url'));
        $this->load->model('pemesanan/kamar_model');
        $this->load->model('pemesanan/reservasi_model');
    }
    ///ini tampilan home reservasi admin
    function index() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $subnav = "admin/subnav.php";
        $data["periode"] = $this->reservasi_model->getPeride();
        $data["tahun"] = $this->reservasi_model->gettahunperiode();
        $this->template->set_layout('back_end');
        $this->template->title("Register Management | Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("admin/setting_periode.php", $data);
    }
    // bagian periode
    function periode() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $subnav = "admin/subnav.php";
        $data["periode"] = $this->reservasi_model->getPeride();
        $data["tahun"] = $this->reservasi_model->gettahunperiode();
        $this->template->set_layout('back_end');
        $this->template->title("Register Management | Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("admin/setting_periode.php", $data);
    }

    function tambahperiode() {
        $mulai = $this->input->post('mulai');
        $akhir = $this->input->post('akhir');
        $nama = $this->input->post('nama');
        $this->reservasi_model->addperiode($mulai, $akhir, $nama);
        redirect("pemesanan/admin/periode");
    }

    function lihatsubmit() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $subnav = "admin/subnav.php";
        $data["pesan"] = $this->kamar_model->getsumit();
        $this->template->set_layout('single_usercontrol');
        $this->template->title("Rekap");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("rekapview.php", $data);
    }

    function tahunperiode($tahun) {
        $array = explode("-", $tahun);
        $data["awal"] = $array[0];
        $data["akhir"] = $array[1];
        $data["tahun"] = $this->reservasi_model->gettahunperiode();
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $subnav = "admin/subnav.php";
        $this->template->set_layout('back_end');
        $this->template->title("Rekap");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("admin/lihatpemesanan.php",$data);
    }
    public function getsubmitdata($awal, $akhir)
    {
        $temp1 = $this->reservasi_model->getsubmitperiode($awal, $akhir);
        $data["submit"] = $this->getPivot($temp1);
        return $data["submit"];
    }
    private function getPivot($data) {
        header('Cache-Control: no-cache, must-revalidate');
        header('Content-type: application/json');
        $header = "[[";
        foreach ($data as $value) {
            foreach ($value as $key => $sembarang) {
                $header .= '"' . str_replace("_"," ",strtoupper($key))  . '"';
                break;
            }
            $count = 1;
            foreach ($value as $key => $sembarang) {
                if ($count > 1)
                    $header .= ',"' . str_replace("_"," ",strtoupper($key)) . '"';
                $count++;
            }
            $header .= "]";
            break;
        }

        foreach ($data as $value) {
            $header .= ",[";
            foreach ($value as $key => $data) {
                if ($key == "ID_SUBMIT")
                    $header .= '"<a href=\'' . base_url() . 'index.php/pemesanan/admin/submit/' . $data . '\'>' . $data . '</a>"';
                else
                    $header .= '"' . $data . '"';
                break;
            }
            $count = 1;
            foreach ($value as $key => $data) {
                if ($count > 1) {
                    if ($key == "ID_SUBMIT")
                        $header .= ',"<a href=\'' . base_url() . 'index.php/pemesanan/admin/submit/' . $data . '\'>' . $data . '</a>"';
                    else
                        $header .= ',"' . $data . '"';
                }
                $count++;
            }
            $header .= "]";
        }
        $header .= "]";
        echo $header;
    }
    // ending periode
    function pendaftaran_rekap()
    {
        $tahun = $this->reservasi_model->getperiodesekarang();
        $array = explode("-", $tahun[0]->TAHUN);
        $data["awal"] = $array[0];
        $data["akhir"] = $array[1];
        $data["tahun"] = $this->reservasi_model->gettahunperiode();
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $subnav = "admin/subnav.php";
        $this->template->set_layout('big_end');
        $this->template->title("Rekap");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("admin/lihatpemesanan.php",$data);
    }
}
?>

