<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class kamar_model extends CI_model {

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function getJenisKamar() {
        $sql = "select * from jenis_kamar";
        return $this->query($sql);
    }

    public function getGedung() {
        $sql = "select gedung.ID_GEDUNG, gedung.NAMA_GEDUNG from gedung";
        return $this->query($sql);
    }

    public function getKamar() {
        $sql = "select kamar.NOMER_KAMAR, jenis_kamar.nama_jenis_kamar, jenis_kamar.nama_jenis_kamar, jenis_kamar.quota_kamar, jenis_kamar.harga_kamar from kamar, jenis_kamar where kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar and kamar.LANTAI=1 and kamar.ID_GEDUNG=2";
        return $this->query($sql);
    }

    public function getLantai() {
        $sql = "select DISTINCT(kamar.LANTAI) as lantai from kamar order by kamar.LANTAI ASC";
        return $this->query($sql);
    }

    public function getsumit() {
        $sql = "select submit.ID_SUBMIT, submit.TANGGAL_SUBMIT, submit.STATUS_SUBMIT,aplikan.NAMA_APLIKAN, aplikan.NRP_APLIKAN, aplikan.PROGRAM_DITERIMA, aplikan.NRP_APLIKAN,jenis_kamar.nama_jenis_kamar, kamar.NOMER_KAMAR, kamar.LANTAI, gedung.NAMA_GEDUNG, periode.NAMA_PERIODE 
        from submit, aplikan, kamar, jenis_kamar, periode,jenis_submit, gedung
        where submit.ID_APLIKAN=aplikan.ID_APLIKAN and submit.ID_KAMAR=kamar.ID_KAMAR and kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar
        and kamar.ID_GEDUNG=gedung.ID_GEDUNG and submit.ID_JENIS_SUMBIT=jenis_submit.ID_JENIS_SUMBIT and submit.ID_PERIODE=periode.ID_PERIODE";
        return $this->query($sql);
    }



}