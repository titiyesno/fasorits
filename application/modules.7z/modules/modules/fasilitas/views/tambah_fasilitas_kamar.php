<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.8.1.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.8.1.min.js"></script>
<script>
    function simpanfasilitas() {
        $.ajax({
            type: "POST",
            url: $("#tambahfasilitas-form").attr('action'),
            data: $("#tambahfasilitas-form").serialize(),
            success: function(data) {
                $("tbody#tabelfasilitas").html(data);
            }
        });
        return false;
    }
    ;
    function hapus() {
        $.ajax({
            type: "GET",
            url: $("#tambahfasilitas-form").attr('action'),
            data: $("#tambahfasilitas-form").serialize(),
            success: function(data) {
                $("tbody#tabelfasilitas").html(data);
            }
        });
        return false;
    }
</script>

<div id="container">
    <center><h3 class="oxigenfontblue">Tambah Fasilitas Kamar <?php echo $data_kamar[0]->NOMER_KAMAR ?></h3></center>
    <hr>
    <form  id="tambahfasilitas-form" action="<?php echo base_url() ?>index.php/fasilitas/admin/simpanfasilitaskamar" method="POST" class="custom" >
        <div class="row">
            <div class="large-3 columns">
                <label for="nama" class="oxigenfont right inline" style="color: black">
                    Nama Fasilitas
                </label>
            </div>
            <div class="large-7 columns">
                <input type="text" placeholder="Nama Fasilitas" id="nama_fasilitas" name="nama_fasilitas" required/>
            </div>
            <div class="large-2 columns">
            </div>
        </div>
        <div class="row">
            <div class="large-3 columns">
                <label for="keterangan" class="oxigenfont right inline" style="color: black">
                    Keterangan 
                </label>
            </div>
            <div class="large-7 columns">
                <textarea type="text" placeholder="Keterangan Fasilitas" id="keterangan_fasilitas" name="keterangan_fasilitas" required></textarea>
            </div>
            <div class="large-2 columns">
            </div>
        </div>
        <div class="row">
            <div class="large-3 columns">
                <label for="jumlah" class="oxigenfont right inline" style="color: black">
                    Jumlah
                </label>
            </div>
            <div class="large-7 columns">
                <input type="text" placeholder="Jumlah Fasilitas" id="jumlah_fasilitas" name="jumlah_fasilitas" required/>
            </div>
            <div class="large-2 columns">
            </div>
        </div>
        <div class="row">
            <div class="large-12 columns">
                <input type="hidden" id="idgedung" name="idgedung" value="<?php echo $idgedung ?>" />
                <input type="hidden" id="idkamar" name="idkamar" value="<?php echo $idkamar ?>" />
            </div>
        </div>
        <div class="row">
            <center><input class="center button" onclick="simpanfasilitas()" value="Tambahkan" style="border: 0px; margin-top: 30px"></center>
        </div>
    </form>
    <div class="row">
        <div class="large-2 columns">
            <label for="jumlah" class="oxigenfont right inline" style="color: black">
            </label>
        </div>
        <div class="large-8 columns">
            <table style="width: 100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Keterangan</th>
                        <th>Jumlah</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="tabelfasilitas">
                    <?php $a = 1;
                    foreach ($list_fasilitas as $r) { ?>
                        <tr>
                            <td><?php echo $a; ?></td>
                            <td><?php echo $r->nama ?></td>
                            <td><?php echo $r->keterangan ?></td>
                            <td><?php echo $r->jumlah ?></td>
                            <td><input type="button" onclick="" class="small button"/></td>
                        </tr>
                        <?php $a++;
                    } ?>
                </tbody>
            </table>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
</div>


