<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.8.1.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript">
    function simpanfasilitas(){
 
    $.ajax({
        type: "POST",
        url: '<?php echo base_url("fasilitas/admin/simpanfasilitasgedung")?>',
        data: $("#tambahfasilitas-form").serialize(),
        success: function(data) {
                    $("tbody#tabelfasilitas").html(data);
        }
    });
    return false;
    };
</script>

<div id="container">
<center><h3 class="oxigenfontblue">Tambah Fasilitas Gedung <?php echo $data_gedung[0]->NAMA_GEDUNG ?></h3></center>
<hr>
<?php 
$att = array("id"=>"tambahfasilitas-form");
echo form_open("",$att);?>
    <div class="row">
        <div class="large-3 columns">
            <label for="nama" class="oxigenfont right inline" style="color: black">
                Nama Fasilitas
            </label>
        </div>
        <div class="large-7 columns">
            <input type="text" placeholder="Nama Fasilitas" id="nama_fasilitas" name="nama_fasilitas" required/>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="keterangan" class="oxigenfont right inline" style="color: black">
                Keterangan 
            </label>
        </div>
        <div class="large-7 columns">
            <textarea type="text" placeholder="Keterangan Fasilitas" id="keterangan_fasilitas" name="keterangan_fasilitas" required></textarea>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="jumlah" class="oxigenfont right inline" style="color: black">
                Jumlah
            </label>
        </div>
        <div class="large-7 columns">
            <input type="text" placeholder="Jumlah Fasilitas" id="jumlah_fasilitas" name="jumlah_fasilitas" required/>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
    <div class="row">
        <div class="large-12 columns">
            <input type="hidden" id="idgedung" name="idgedung" value="<?php echo $idgedung ?>" />
            <input type="hidden" id="idkamar" name="idkamar" value="<?php echo $idkamar ?>" />
        </div>
    </div>
    <div class="row">
        <center><input class="center small button" onclick="simpanfasilitas()" value="Tambahkan" style="border: 0px; margin-top: 30px"></center>
        <center><a class="center small button" href="<?php echo base_url(); ?>index.php/kamar/admin"></a></center>
    </div>
</form>
<div class="row">
    <div class="large-2 columns">
    </div>
    <div class="large-8 columns">
        <table style="width: 100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Keterangan</th>
                    <th>Jumlah</th>
                    <th></th>
                </tr>
            </thead>
            <tbody id="tabelfasilitas">
            </tbody>
        </table>
    </div>
    <div class="large-2 columns">
    </div>
</div>
</div>
        

