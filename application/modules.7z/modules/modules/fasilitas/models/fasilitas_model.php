<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class fasilitas_model extends CI_model {
    
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function create_fasilitas($idgedung,$idkamar,$nama,$keterangan,$jumlah){

        $data = array(
            'id_gedung' => $idgedung,
            'id_kamar' => $idkamar,
            'nama' => $nama,
            'keterangan' => $keterangan,
            'jumlah' => $jumlah,
        );
        $this->db->insert('fasilitas', $data);    
    }
    
    public function read_fasilitas(){
        $query = $this->db->get('fasilitas');
        return $query->result();
    }
    
    public function read_fasilitas_by_idgedung($id){
        $this->db->where('id_gedung',$id);
        $query = $this->db->get('fasilitas');
        return $query->result();
    }
    
    public function read_fasilitas_by_idkamar($id){
        $this->db->where('id_kamar',$id);
        $query = $this->db->get('fasilitas');
        return $query->result();
    }
    
//    public function update_fasilitas($id,$idgedung,$nama,$keterangan,$jumlah){
//
//        $data = array(
//            'id_gedung' => $idgedung,
//            'nama' => $nama,
//            'keterangan' => $keterangan,
//            'jumlah' => $jumlah,
//        );
//        $this->db->where('ID_FASILITAS',$id);
//        $result = $this->db->update('fasilitas', $data);
//        return $result; 
//    }
    
    public function delete_fasilitas($id){
        $this->db->where('id_fasilitas', $id);
        $this->db->delete('fasilitas');
    }
    
    public function delete_fasilitas_by_kamar($id){
        $this->db->where('id_kamar', $id);
        $this->db->delete('fasilitas');
        return $this->read_fasilitas_by_idgedung($id);
    }
    
    public function delete_fasilitas_by_gedung($id){
        $this->db->where('id_gedung', $id);
        $this->db->delete('fasilitas');
    }
    
}