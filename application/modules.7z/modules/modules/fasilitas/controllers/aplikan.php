<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class aplikan extends Aplikan_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('fasilitas_model');
        $this->load->model('kamar/gedung_model');
        $this->load->library('form_validation');
        $this->load->library('image_CRUD');
    }

    public function index() {
        $data['list_fasilitas'] = $this->fasilitas_model->read_fasilitas();
        
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("tambah_fasilitas.php", $data);
    }
    
    public function getfasilitas_bygedung() {
        $idgedung = $this->input->post('idgedung');
        $data_fasilitas = $this->fasilitas_model->read_fasilitas_by_idgedung($idgedung);
        $a=1;
        $htmlres = '';
        foreach ($data_fasilitas as $r) 
          { 
            $htmlres .= 
                "
                    <tr>
                        <td>$a</td>
                        <td>$r->nama</td>
                        <td>$r->keterangan</td>
                        <td>$r->jumlah</td>
                        <td></td>
                    </tr>
                ";
            $a++;
          } 
          echo $htmlres;
    }
    
}

?>
