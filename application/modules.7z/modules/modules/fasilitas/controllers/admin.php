<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class admin extends Admin_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('fasilitas_model');
        $this->load->model('kamar/gedung_model');
        $this->load->model('kamar/kamar_model');
        $this->load->library('form_validation');
    }

    public function index() {
        $data['list_fasilitas'] = $this->fasilitas_model->read_fasilitas();
        
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("tambah_fasilitas.php", $data);
    }
    
    public function tambahfasilitas_gedung() {
        $idgedung = $this->input->post('idgedung');
        $data['idgedung'] = $this->input->post('idgedung');
        $data['idkamar'] = "";
        $data['data_gedung'] = $this->gedung_model->read_gedung_by_id($idgedung);
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("tambah_fasilitas_gedung.php", $data);
    }
    
    public function tambahfasilitas_kamar($idkamar="") {
        $data['list_fasilitas'] = $this->fasilitas_model->read_fasilitas_by_idkamar($idkamar);
        $data['idgedung'] = "";
        $data['idkamar'] = $idkamar;
        $data['data_kamar'] = $this->kamar_model->read_kamar_by_id($idkamar);
        $menu = "hf/menu/menu_pengelola.php";
//        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("tambah_fasilitas_kamar.php", $data);
    }

    public function simpanfasilitasgedung() {
        $idgedung = $this->input->post('idgedung');
        $idkamar = $this->input->post('idkamar');
        $nama = $this->input->post('nama_fasilitas');
        $keterangan = $this->input->post('keterangan_fasilitas');
        $jumlah = $this->input->post('jumlah_fasilitas');
        $idkamar = null;
        $this->fasilitas_model->create_fasilitas($idgedung,$idkamar,$nama,$keterangan,$jumlah);
        $data_fasilitas = $this->fasilitas_model->read_fasilitas_by_idgedung($idgedung);
        $a=1;
        $htmlres = '';
        foreach ($data_fasilitas as $r) 
          { 
            $htmlres .= 
                "
                    <tr>
                        <td>$a</td>
                        <td>$r->nama</td>
                        <td>$r->keterangan</td>
                        <td>$r->jumlah</td>
                        <td></td>
                        <td><input class=\"btn btn-danger btn-sm\" onclick=\"hapusfasilitas(".$r->id_fasilitas.")\" value=\"Hapus\"></td>
                    </tr>
                ";
            $a++;
          } 
          echo $htmlres;
    }
    
    public function hapusfasilitasgedung() {
        header('Cache-Control: no-cache, must-revalidate');
        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');
        $temp = $this->input->post('id');
        $idgedung = $temp['idgedung'];
        $id= $temp['idfasilitas'];
        $this->fasilitas_model->delete_fasilitas($id);
        $data_fasilitas = $this->fasilitas_model->read_fasilitas_by_idgedung($idgedung);
        $a=1;
        $htmlres = '';
        foreach ($data_fasilitas as $r) 
          { 
            $htmlres .= 
                "
                    <tr>
                        <td>$a</td>
                        <td>$r->nama</td>
                        <td>$r->keterangan</td>
                        <td>$r->jumlah</td>
                        <td></td>
                        <td><input class=\"center small button\" onclick=\"hapusfasilitas(".$r->id_fasilitas.",".$idgedung.")\" value=\"Hapus\"></td>
                    </tr>
                ";
            $a++;
          } 
          echo $htmlres;
    }
    public function hapusfasilitas($id,$idkamar){
        $this->fasilitas_model->delete_fasilitas($id);
        redirect("kamar/admin/ubah_kamar/".$idkamar);
    }

    public function hapusfasilitaskamar() {
        header('Cache-Control: no-cache, must-revalidate');
        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');
        $temp = $this->input->post('id');
        $idkamar = $temp['idkamar'];
        $id= $temp['idfasilitas'];
        $this->fasilitas_model->delete_fasilitas($id);
        $data_fasilitas = $this->fasilitas_model->delete_fasilitas_by_kamar($idkamar);
        $a=1;
        $htmlres = '';
        foreach ($data_fasilitas as $r) 
          { 
            $htmlres .= 
                "
                    <tr>
                        <td>$a</td>
                        <td>$r->nama</td>
                        <td>$r->keterangan</td>
                        <td>$r->jumlah</td>
                        <td><input class=\"center small button\" onclick=\"hapusfasilitas(".$r->id_fasilitas.",".$idjeniskamar.")\" value=\"Hapus\"></td>
                    </tr>
                ";
            $a++;
          } 
          echo $htmlres;
    }
    
    public function simpanfasilitaskamar() {
        $idgedung = $this->input->post('idgedung');
        $idkamar = $this->input->post('idkamar');
        $nama = $this->input->post('nama_fasilitas');
        $keterangan = $this->input->post('keterangan_fasilitas');
        $jumlah = $this->input->post('jumlah_fasilitas');
        $idgedung = null;
        $this->fasilitas_model->create_fasilitas($idgedung,$idkamar,$nama,$keterangan,$jumlah);
        $data_fasilitas = $this->fasilitas_model->read_fasilitas_by_idkamar($idkamar);
        $a=1;
        $htmlres = '';
        foreach ($data_fasilitas as $r) 
          { 
            $htmlres .= 
                '
                    <tr>
                        <td>'.$a.'</td>
                        <td>'.$r->nama.'</td>
                        <td>'.$r->keterangan.'</td>
                        <td>'.$r->jumlah.'</td>
                            <td>
                        <a class="tiny orange button" href="'.base_url().'index.php/fasilitas/admin/hapusfasilitas/'.$r->id_fasilitas .'/'.$idkamar.'">Hapus</a>
                            </td>
                    </tr>
                ';
            $a++;
          } 
          echo $htmlres;
    }
    
    public function getfasilitas_bygedung() {
        $idgedung = $this->input->post('idgedung');
        $data_fasilitas = $this->fasilitas_model->read_fasilitas_by_idgedung($idgedung);
        $a=1;
        $htmlres = '';
        foreach ($data_fasilitas as $r) 
          { 
            $htmlres .= 
                "
                    <tr>
                        <td>$a</td>
                        <td>$r->nama</td>
                        <td>$r->keterangan</td>
                        <td>$r->jumlah</td>
                        <td></td>
                    </tr>
                ";
            $a++;
          } 
          echo $htmlres;
    }
    
    public function hapus($id="") {
        $this->fasilitas_model->delete_fasilitas($id);
        redirect('fasilitas/admin');
    }

}

?>
