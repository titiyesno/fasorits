<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>

<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script>
    var map;
    var markers = [];
    function initialize() {

        var myOptions = {
            zoom: 15,
            center: new google.maps.LatLng(-7.276513, 112.791692),
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            PanControlOptions: false,
            zoomControl: true

        };
        map = new google.maps.Map(document.getElementById('map-canvas'), myOptions);

        google.maps.event.addListener(map, 'click', function(event)
        {
            clearMarkers();
            marker = new google.maps.Marker(
                    {
                        draggable: true,
                        animation: google.maps.Animation.DROP,
                        map: map,
                        position: event.latLng
                    })
            markers.push(marker);
            $("#lat").val(marker.position.lat());
            $("#long").val(marker.position.lng());

        });

    }
    function clearMarkers() {
        for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(null)
        }
        markers = [];
    }
    ;

    function assign_namagaleri() {
        $("#namagaleri").val($("#nama").val());
    }

    google.maps.event.addDomListener(window, 'load', initialize);
    $(function() {
        var items = [
<?php
$itung = 0;
foreach ($data as $p)
    foreach ($p as $u => $i) {
        echo "'" . $u . "',";
    }
?>
        ];

        function split(val) {
            return val.split(/,\s*/);
        }
        function extractLast(term) {
            return split(term).pop();
        }

        $("#jenis")
                .autocomplete({
                    minLength: 0,
                    source: function(request, response) {
                        response($.ui.autocomplete.filter(
                                items, extractLast(request.term)));
                    },
                    focus: function() {
                        return false;
                    },
                    select: function(event, ui) {
                        var terms = split(this.value);
                        // remove the current input
                        terms.pop();
                        // add the selected item
                        terms.push(ui.item.value);
                        // add placeholder to get the comma-and-space at the end
                        terms.push("");
                        this.value = terms.join(", ");
                        return false;
                    }
                });
    });
</script>
<section class="content-header">
    <h1>
        Tambah Gedung 
        <small>Data Operation</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Katalog</li>
        <li class="active">Gedung</li>
    </ol>
</section>
<div class="content">
    <div class="row">
        <div class="col-sm-12">
            <div class="box">
                <div class="box-header">
                    <center><h3 class="box-title">Tambah Gedung</h3></center>
                </div>
                <div class="box-body">
                    <div class="row">
                        <?php
                        echo form_open("kamar/admin/SimpanTambahGedung");
                        ?>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="nama" >
                                    Nama Gedung
                                </label>        
                                <input class="form-control" oninput="assign_namagaleri()" type="text" placeholder="Nama Gedung" id="nama" name="nama" required/>
                            </div>
                            <div class="form-group">
                                <label for="keterangan" >
                                    Keterangan
                                </label>
                                <input class="form-control" type="text" placeholder="Keterangan" id="keterangan" name="keterangan" required/>
                            </div>
                            <div class="form-group">
                                <label for="jenis" >
                                    Jenis Gedung
                                </label>
                                <textarea  class="form-control" type="text" placeholder="Jenis Gedung" id="jenis" name="jenis" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="profile" >
                                    Profil Gedung
                                </label>
                                <textarea class="form-control" placeholder="Profil Gedung" id="profile" name="profil" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="galeri" >
                                    Nama Galeri Foto
                                </label>
                                <input class="form-control" readonly="" type="text" placeholder="Nama Galeri Foto" id="namagaleri" name="namagaleri" required/>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div id="map-canvas" style="width: 100%; height: 350px"></div>
                            <input type="hidden" name="lat" id="lat" value="" />
                            <input type="hidden" name="long" id="long" value="" />
                        </div>
                    </div>

                    <div class="row">
                        <center><input class="btn btn-primary" type="submit" value="Lanjut" style="border: 0px; margin-top: 30px"></center>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
