<script>
    function simpanfasilitas() {
        $.ajax({
            type: "POST",
            url: $("#tambahfasilitas-form").attr('action'),
            data: $("#tambahfasilitas-form").serialize(),
            success: function(data) {
                $("tbody#tabelfasilitas").html(data);
                $('#TambahFasilitasModal').foundation('reveal', 'close');
            }
        });
        return false;
    }
    ;
    function hapusfasilitas(id, idkamar)
    {
        var temp = {};
        temp.id = {};
        temp.id.idkamar = idkamar;
        temp.id.idfasilitas = id;
        $.ajax({
            type: "POST",
            url: '<?php echo base_url("index.php/fasilitas/admin/hapusfasilitaskamar") ?>',
            data: temp,
            success: function(data) {
                $("coba").html(data);
            }
        });

    }

</script>
<section class="content-header">
    <h1>
        Edit Kamar 
        <small>Data Operation</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Katalog</li>
        <li class="active">Kamar</li>
    </ol>
</section>
<div class="content">
    <div class="row">
        <div class="col-sm-6">
            <form action="<?php echo base_url() ?>index.php/kamar/admin/SimpanUbahKamar" method="POST" class="custom" >
                <div class="box">
                    <div class="box-header">
                        <center><h3 class="box-title"><?php echo $data_kamar[0]->NOMER_KAMAR ?></h3></center>
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            <label for="gedung" >
                                Pilih Gedung
                            </label>
                            <select class="form-control" onchange="" name="idgedung" >
                                <?php
                                foreach ($data_gedung as $r) {
                                    if ($r->ID_GEDUNG != $data_kamar[0]->ID_GEDUNG) {
                                        ?>
                                        <option  value="<?php echo $r->ID_GEDUNG; ?>" ><?php echo $r->NAMA_GEDUNG; ?></option>
                                    <?php } else if ($r->ID_GEDUNG == $data_kamar[0]->ID_GEDUNG) { ?>
                                        <option selected value="<?php echo $r->ID_GEDUNG; ?>" ><?php echo $r->NAMA_GEDUNG; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                            <input class="form-control" type="hidden" name="idgedung" id="idgedung" value="<?php echo $data_kamar[0]->ID_GEDUNG ?>" />
                        </div>
                    
                    <div class="form-group">
                        <label for="jeniskamar">
                            Pilih Jenis Kamar
                        </label>
                        <select class="form-control" onchange="" name="idjeniskamar" id="idjeniskamar"  >
                            <?php
                            foreach ($data_jenis as $k) {
                                if ($k->id_jenis_kamar == $data_kamar[0]->ID_JENIS_KAMAR) {
                                    ?>
                                    <option selected value="<?php echo $k->id_jenis_kamar; ?>" ><?php echo $k->nama_jenis_kamar; ?></option>
                                <?php } else  ?>
                                <option value="<?php echo $k->id_jenis_kamar; ?>" ><?php echo $k->nama_jenis_kamar; ?></option>
                            <?php } ?>
                        </select>
                        <input class="form-control" type="hidden" name="jeniskamar" id="jeniskamar" value="<?php echo $data_kamar[0]->ID_JENIS_KAMAR ?>" />
                    </div>
                    <div class="form-group">
                        <label for="nomor">
                            Nomor Kamar
                        </label>
                        <input class="form-control" type="text" placeholder="Nomor Kamar" id="nomor" name="nomor" value="<?php echo $data_kamar[0]->NOMER_KAMAR ?>" required/>
                    </div>
                    <div class="form-group">
                        <label for="keterangan">
                            Keterangan Kamar :
                        </label>
                        <textarea class="form-control" placeholder="Keterangan Kamar" id="keterangan" name="keterangan" ><?php echo $data_kamar[0]->KETERANGAN_KAMAR ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="lantai">
                            Lantai
                        </label>
                        <input class="form-control" type="text" placeholder="Lantai Kamar" id="lantai" value="<?php echo $data_kamar[0]->LANTAI ?>" name="lantai" required/>
                    </div>
                    <div class="form-group">
                        <label for="sewa">
                            Status Sewa Kamar
                        </label>
                        <input type="radio" name="sewa" id="sewa" <?php if ($data_kamar[0]->STATUS_SEWA == '1') echo 'checked'; ?> value="1"/>Disewakan</br>
                        <input type="radio" name="sewa" id="sewa" <?php if ($data_kamar[0]->STATUS_SEWA == '0') echo 'checked'; ?> value="0"/>Tidak Disewakan</br>
                    </div>
                    <div class="form-group">
                        <center>
                            <input class="btn btn-primary" type="submit" value="Simpan">
                            <a class="btn btn-danger" href="<?php echo base_url() ?>index.php/kamar/admin/hapus_kamar/<?php echo $data_kamar[0]->ID_KAMAR ?>">Hapus</a>
                        </center>
                        <input type="hidden" name="idkamar" value="<?php echo $data_kamar[0]->ID_KAMAR ?>"/>
                    </div>
                </div>
            </form>
	</div>
        </div>
        <div class="col-sm-6">               
            <div class="box">
                <div class="box-header"><h3 class="box-title">Fasilitas</h3></div>
                <div class="box-body">
                    <table class="table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Keterangan</th>
                                <th>Jumlah</th>

                                <th>Hapus</th>
                            </tr>
                        </thead>
                        <tbody id="tabelfasilitas">
                            <?php
                            $a = 1;
                            foreach ($list_fasilitas as $r) {
                                ?>
                                <tr>
                                    <td><?php echo $a; ?></td>
                                    <td><?php echo $r->nama; ?></td>
                                    <td><?php echo $r->keterangan; ?></td>
                                    <td><?php echo $r->jumlah; ?></td>

                                    <td>

                                        <a class="tiny orange button" href="<?php echo base_url() ?>index.php/fasilitas/admin/hapusfasilitas/<?php echo $r->id_fasilitas . '/' . $data_kamar[0]->ID_KAMAR; ?>">Hapus</a>
                                    </td>  
                                </tr>
                                <?php
                                $a++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>    
            </div>
            <div class="box">
                <div class="box-header"><h3 class="box-title">Tambah Fasilitas</h3></div>
                <div class="box-body">
                    <form  id="tambahfasilitas-form" action="<?php echo base_url() ?>index.php/fasilitas/admin/simpanfasilitaskamar" method="POST" class="custom" >
                        <div class="form-group">
                            <label for="nama">
                                Nama Fasilitas
                            </label>
                            <input class="form-control" type="text" placeholder="Nama Fasilitas" id="nama_fasilitas" name="nama_fasilitas" required/>
                        </div>

                        <div class="form-group">
                            <label for="keterangan">
                                Keterangan 
                            </label>
                            <textarea class="form-control" placeholder="Keterangan Fasilitas" id="keterangan_fasilitas" name="keterangan_fasilitas"></textarea>

                        </div>
                        <div class="form-group">
                                <label for="jumlah">
                                    Jumlah
                                </label>
                            <input type="text" class="form-control" placeholder="Jumlah Fasilitas" id="jumlah_fasilitas" name="jumlah_fasilitas" required/>
                        </div>
                        <div class="form-group">
                                <input type="hidden" id="idkamar" name="idkamar" value="<?php echo $idkamar ?>" />
                        </div>
                        <div class="form-group">
                            <center><input class="btn btn-primary" onclick="simpanfasilitas()" value="Tambahkan" style="border: 0px; margin-top: 30px"></center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

