<section class="content-header">
    <h1>
        Daftar Jenis Kamar
        <small>Report</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Katalog</li>
        <li class="active">Jenis Kamar</li>
    </ol>
</section>
<div class="content">
    <div class="box">
        <div class="box-header">
            <center><h3 class="box-title">Daftar Jenis Kamar</h3></center>
        </div>
        <div class="box-body">
            <div class="row">
                <?php
                $a = 1;
                foreach ($list_jeniskamar as $r) {
                    ?>

                    <div class="col-md-3">
                        <!-- Info box -->
                        <div class="box box-solid box-info" style="min-height: 400px">
                            <div class="box-header">
                                <h3 class="box-title"><?php echo $r->nama_jenis_kamar; ?></h3>
                                <div class="box-tools pull-right">
                                    <button class="btn btn-info btn-sm" data-widget="collapse"><i class="fa fa-minus"></i></button>
                                    <button class="btn btn-info btn-sm" data-widget="remove"><i class="fa fa-times"></i></button>
                                </div>
                            </div>
                            <div class="box-body">
                                Quota Kamar: <code><?php echo $r->quota_kamar; ?></code> Orang
                                <p> </p>
                                <p><?php echo "Rp " . numberToConcurent(".", $r->harga_kamar * 11); ?> per 11 Bulan</p>
                                <p><?php echo str_replace(",", ",<br/>", $r->keterangan); ?></p>
                            </div><!-- /.box-body -->
                            <div class="box-footer">
                                <a class="btn btn-primary" href="<?php echo base_url(); ?>index.php/kamar/admin/ubah_jeniskamar/<?php echo $r->id_galeri ?>/<?php echo $r->id_jenis_kamar ?>">Ubah</a>
                                <a class="btn btn-danger" href="<?php echo base_url(); ?>index.php/kamar/admin/hapus_jeniskamar/<?php echo $r->id_jenis_kamar ?>/<?php echo $r->id_galeri ?>">Hapus</a>

                            </div>
                        </div><!-- /.box -->
                    </div>
                    <?php
                    $a++;
                }
                ?>
            </div>
        </div>
    </div>
</div>
