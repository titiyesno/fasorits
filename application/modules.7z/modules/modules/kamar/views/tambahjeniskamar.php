<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script>
    function assign_namagaleri() {
        $("#namagaleri").val($("#nama").val());
    }
</script>
<section class="content-header">
    <h1>
        Tambah Jenis Kamar
        <small>Data Operation</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Katalog</li>
        <li class="active">Jenis Kamar</li>
    </ol>
</section>
<div class="content">
    <div class="row">
        <div class="col-sm-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Tambah Jenis Kamar</h3>
                </div>
                <div class="box-body">
                    <form action="<?php echo base_url() ?>index.php/kamar/admin/SimpanTambahJenisKamar" method="POST" role="form">

                        <div class="form-group">
                            <label for="nama" >
                                Nama Jenis Kamar
                            </label>
                            <input class="form-control" oninput="assign_namagaleri()" type="text" placeholder="Nama Jenis Kamar" id="nama" name="nama" required/>
                        </div>
                        <div class="form-group">
                            <label for="kuota">
                                Kuota Jenis Kamar
                            </label>
                            <input class="form-control" type="text" placeholder="Kuota Jenis Kamar" id="kuota" name="kuota" required/>
                        </div>
                        <div class="form-group">
                            <label for="harga">
                                Harga Jenis Kamar
                            </label>
                            <input class="form-control" type="text" placeholder="Harga Jenis Kamar" id="harga" name="harga" required/>
                        </div>
                        <div class="form-group">
                                <label for="profile">
                                    Keterangan
                                </label>
                            <textarea class="form-control" placeholder="Keterangan" id="keterangan" name="keterangan" required></textarea>
                        </div>
                        <div class="form-group">
                                <label for="galeri">
                                    Nama Galeri Foto
                                </label>
                            <input class="form-control" disabled type="text" placeholder="Nama Galeri Foto" id="namagaleri" name="namagaleri" required/>
                        </div>
                        <div class="form-group">
                            <center><input class="btn btn-primary" type="submit" value="Tambahkan Jenis Kamar" style="border: 0px; margin-top: 30px"></center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
