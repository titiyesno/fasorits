
<center><h3 >Daftar Jenis Kamar</h3></center>
<hr>

<div id="body">
    <div class="row">
        <div class="col-sm-12">
            <center>
                <?php $a = 1;
                foreach ($list_jeniskamar as $r) {
                    ?>

                    <div class="col-md-3">
                        <!-- Info box -->
                        <div class="box box-solid box-info">
                            <div class="box-header">
                                <h3 class="box-title"><?php echo $r->nama_jenis_kamar; ?></h3>
                                <div class="box-tools pull-right">
                                    <button class="btn btn-info btn-sm" data-widget="collapse"><i class="fa fa-minus"></i></button>
                                    <button class="btn btn-info btn-sm" data-widget="remove"><i class="fa fa-times"></i></button>
                                </div>
                            </div>
                            <div class="box-body">
                                Quota Kamar: <code><?php echo $r->quota_kamar; ?></code> Orang
                                <p> </p>
                                <p><?php echo "Rp " . numberToConcurent(".", $r->harga_kamar * 11); ?> per 11 Bulan</p>
                                <p><?php echo str_replace(",", ",<br/>", $r->keterangan); ?></p>
                            </div><!-- /.box-body -->
                        </div><!-- /.box -->
                    </div>
                    <?php $a++;
                }
                ?>
            </center>
        </div>
    </div>
</div>
