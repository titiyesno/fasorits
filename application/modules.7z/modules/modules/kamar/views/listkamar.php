
<script>
    function getkamar_bygedung() {
        $.ajax({
            type: "POST",
            url: $("#cari_kamar_form").attr('action'),
            data: $("#cari_kamar_form").serialize(),
            success: function(data) {
                $("tbody#divkamar").html(data);
            }
        });
        return false;
    }
    ;

    function daftarkamar() {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>index.php/kamar/admin/cari_listkamar_ajax",
            success: function(data) {
                $("tbody#divkamar").html(data);
            }

        });
    }
    ;
    jQuery(window).load(function() {
        getkamar_bygedung();
    });
</script>
<div id="container">
    <center><h3 class="oxigenfontblue">Daftar Kamar</h3></center>
    <hr>
    <div id="body">
        <form id="cari_kamar_form" method="post" class="custom" action="<?php echo site_url('kamar/admin/cari_kamar_by_gedung'); ?>">
            <div class="row">
                <div class="large-3 columns">
                    <label for="gedung" class="oxigenfont right inline" style="color: black">
                        Pilih gedung
                    </label>
                </div>
                <div class="large-6 columns">
                    <select onchange="getkamar_bygedung()"  type="text" name="idgedung" id="idgedung">
                        <?php foreach ($data_gedung as $r) { ?>
                            <option value="<?php echo $r->ID_GEDUNG; ?>" ><?php echo $r->NAMA_GEDUNG; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="large-3 columns">
                </div>
            </div>
        </form>
        <div class="row">
            <div class="large-3 columns">
                <label for="gedung" class="oxigenfont right inline" style="color: black">
                </label>
            </div>
            <div class="large-6 columns">
                <table style="width: 100%">
                    <thead>
                        <tr>
                            <th>Nomor Kamar</th>
                            <th>Penghuni</th>
                            <th>Kapasitas Kamar</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody id="divkamar">
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
                <a>*klik nomor kamar untuk ubah data tiap kamar</a>
            </div>
            <div class="large-3 columns">
            </div>
        </div>

    </div>
</div>
