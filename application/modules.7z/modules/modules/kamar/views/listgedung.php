<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script>
    var map;
    var markers = [];
    var lat = [];
    var long = [];
    var koordGedung;
    var a;
    function initialize() {

        var myOptions = {
            zoom: 15,
            center: new google.maps.LatLng($("#lat").val(), $("#long").val()),
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            PanControlOptions: false,
            zoomControl: true

        };
        map = new google.maps.Map(document.getElementById('map-canvas'), myOptions);
        getKoordinat();
    }

    function getKoordinat()
    {

        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>index.php/kamar/admin/getKoordinat",
            success: function(data) {
                for (a = 0; a < data.hasil.length; a++)
                {
                    createMarker(data.hasil[a]['nama'], data.hasil[a]['la'], data.hasil[a]['lo']);
                }
            }
        });
        return false;
    }

    function createMarker(nama, lati, longi)
    {
        koordGedung = new google.maps.LatLng(lati, longi);
        marker = new google.maps.Marker(
                {
                    draggable: true,
                    animation: google.maps.Animation.DROP,
                    map: map,
                    position: koordGedung,
                    title: nama
                })
        markers.push(marker);
        google.maps.event.addListener(marker, 'mouseup', function(event)
        {

            $("#lat").val(event.latLng.lat());
            $("#long").val(event.latLng.lng());

        });
    }

    function clearMarkers() {
        for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(null)
        }
        markers = [];
    }
    ;
    google.maps.event.addDomListener(window, 'load', initialize);
</script>
<section class="content-header">
    <h1>
        Daftar Kamar 
        <small>Report</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Katalog</li>
        <li class="active">Gedung</li>
    </ol>
</section>
<div class="content">
    <div class="box">
        <div class="box-header">
            <center><h3 class="box-title">Daftar Gedung</h3></center>
        </div>
        <div class="box-body">
            <div id="map-canvas" style="width: 100%; height: 350px; margin-bottom: 20px"></div>
            <div class="row"> <?php
                $a = 1;
                foreach ($list_gedung as $r) {
                    ?> 
                    <div class="col-md-4"> <!-- Primary box --> 
                        <div class="box box-solid box-primary" style="min-height: 400px"> 
                            <div class="box-header"> 
                                <h3 class="box-title"><?php echo $r->NAMA_GEDUNG; ?></h3> 
                                <div class="box-tools pull-right"> 
                                    <button class="btn btn-primary btn-sm" data-widget="collapse"><i class="fa fa-minus"></i></button> <button class="btn btn-primary btn-sm" data-widget="remove"><i class="fa fa-times"></i></button> </div> </div> 
                            <div class="box-body"> <code><?php echo $r->KETERANGAN_GEDUNG; ?></code> <p> <?php
                                    $data = explode("-", $r->PROFIL_GEDUNG);
                                    $html = "";
                                    for ($i = 1; $i < count($data); $i++) {
                                        $html.="<li class=''>" . $data[$i] . "</li>";
                                    } $html.="";
                                    echo $html;
                                    ?> </p> 

                                <a class="btn btn-primary" href="<?php echo base_url(); ?>index.php/kamar/admin/ubah_gedung/<?php echo $r->ID_GALERI ?>/<?php echo $r->ID_GEDUNG ?>">Edit</a>
                                <a class="btn btn-danger" style="background-color: #e9635b" href="<?php echo base_url(); ?>index.php/kamar/admin/hapus_gedung/<?php echo $r->ID_GEDUNG ?>/<?php echo $r->ID_GALERI ?>">Remove</a>
                                <input type="hidden" name="lat" id="lat" value="<?php echo $r->LATITUDE ?>" />
                                <input type="hidden" name="long" id="long" value="<?php echo $r->LONGITUDE ?>" />
                                <input type="hidden" name="idgedung" id="idgedung" value="<?php echo $r->ID_GEDUNG ?>" />
                                <input type="hidden" name="lat" id="lat" value="<?php echo $r->LATITUDE ?>" />
                                <input type="hidden" name="long" id="long" value="<?php echo $r->LONGITUDE ?>" />
                                <input type="hidden" name="idgedung" id="idgedung" value="<?php echo $r->ID_GEDUNG ?>">
                            </div><!-- /.box-body --> </div><!-- /.box --> </div> 





                    <?php
                    $a++;
                }
                ?> 
            </div>
        </div>
    </div>
</div>

