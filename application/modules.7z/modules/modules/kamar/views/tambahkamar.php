<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.2.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script type="text/javascript">////
  $(document).ready(function() {
    $('#buttonForModal').click(function() {
//      $('#myModal').reveal({
//             animation: 'fadeAndPop', //fade, fadeAndPop, none
//             animationspeed: 300, //how fast animations are
//             closeOnBackgroundClick: true, //if you click background will modal close?
//             dismissModalClass: 'close-reveal-modal' //the class of a button or element that will close an open modal
//        });
         $('#myModal').reveal();     
    });
  });
</script>
<section class="content-header">
    <h1>
        Tambah Kamar
        <small>Data Operation</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Katalog</li>
        <li class="active">Kamar</li>
    </ol>
</section>
<div id="container">
    <center><h3 class="oxigenfontblue">Tambah Kamar</h3></center>
    <hr>
    <form action="<?php echo base_url()?>index.php/kamar/admin/SimpanTambahKamar" method="POST" class="custom" >
    <div class="row">
        <div class="large-3 columns">
            <label for="gedung" class="oxigenfont right inline" style="color: black">
                Pilih Gedung
            </label>
        </div>
        <div class="large-7 columns ">
            <select onchange=""  type="text" name="idgedung" id="idgedung" >
                <?php foreach ($data_gedung as $r) { ?>
                    <option value="<?php echo $r->ID_GEDUNG;?>" ><?php echo $r->NAMA_GEDUNG; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="jeniskamar" class="oxigenfont right inline" style="color: black">
                Pilih Jenis Kamar
            </label>
        </div>
        <div class="large-7 columns ">
            <select onchange=""  type="text" name="jeniskamar" id="jeniskamar" >
                <?php foreach ($data_jenis as $k) { ?>
                    <option value="<?php echo $k->id_jenis_kamar;?>" ><?php echo $k->nama_jenis_kamar; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="nomor" class="oxigenfont right inline" style="color: black">
                Nomor Kamar
            </label>
        </div>
        <div class="large-7 columns">
            <input type="text" placeholder="Nomor Kamar" id="nomor" name="nomor" required/>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="lantai" class="oxigenfont right inline" style="color: black">
                Lantai
            </label>
        </div>
        <div class="large-7 columns">
            <input type="text" placeholder="Lantai Kamar" id="lantai" name="lantai" required/>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="keterangan" class="oxigenfont right inline" style="color: black">
                Keterangan Kamar
            </label>
        </div>
        <div class="large-7 columns">
            <textarea type="text" placeholder="Keterangan Kamar" id="keterangan" name="keterangan" required></textarea>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="sewa" class="oxigenfont right inline" style="color: black">
                Status Sewa Kamar
            </label>
        </div>
        <div class="large-7 columns">
            <input type="radio" name="sewa" id="sewa" value="1" checked/>Disewakan</br>
            <input type="radio" name="sewa" id="sewa" value="0"/>Tidak Disewakan</br>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
    <div class="row">
        <center><input class="center button" type="submit" value="Tambahkan Kamar" style="border: 0px; margin-top: 30px"></center>
    </div>
    </form>
</div>