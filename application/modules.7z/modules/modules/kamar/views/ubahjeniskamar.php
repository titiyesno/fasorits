<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.10.2.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script>
    function assign_namagaleri() {
        $("#galerinama").val($("#nama").val());
    }
</script>
<?php foreach ($css_files as $file): ?>
    <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach ($js_files as $file): ?>
    <script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
<section class="content-header">
    <h1>
        Ubah Jenis Kamar
        <small>Data Operation</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Katalog</li>
        <li class="active">Jenis Kamar</li>
    </ol>
</section>
<div class="content">
    <div class="row">
        <div class="col-sm-6">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Tambah Jenis Kamar</h3>
                </div>
                <div class="box-body">
                    <form action="<?php echo base_url() ?>index.php/kamar/admin/SimpanUbahJenisKamar" method="POST" class="custom" >

                        <div class="form-group">
                            <label for="nama" >
                                Nama Jenis Kamar
                            </label>
                            <input class="form-control" oninput="assign_namagaleri()" type="text" placeholder="Nama Jenis Kamar" id="nama" name="nama" value="<?php echo $data_jeniskamar[0]->nama_jenis_kamar ?>" required/>
                        </div>
                        <div class="form-group">
                            <label for="kuota">
                                Kuota Jenis Kamar
                            </label>
                            <input class="form-control" type="text" placeholder="Kuota Jenis Kamar" id="kuota" name="kuota" value="<?php echo $data_jeniskamar[0]->quota_kamar ?>" required/>
                        </div>
                        <div class="form-group">
                            <label for="harga">
                                Harga Jenis Kamar
                            </label>
                            <input class="form-control" type="text" placeholder="Harga Jenis Kamar" id="harga" name="harga" value="<?php echo $data_jeniskamar[0]->harga_kamar ?>" required/>
                        </div>
                        <div class="form-group">
                            <label for="profile">
                                Keterangan
                            </label>
                            <textarea class="form-control" placeholder="Keterangan" id="keterangan" name="keterangan" required><?php echo $data_jeniskamar[0]->keterangan ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="galeri">
                                Nama Galeri Foto
                            </label>
                            <input type="hidden" value="<?php echo $data_galeri[0]->ID_GALERI ?>" id="tes" name="tes" />
                            <input class="form-control" type="text" disabled placeholder="Nama Galeri" value="<?php echo $data_galeri[0]->NAMA_GALERI ?>" id="galerinama" name="galerinama" required/>
                            <input type="hidden" name="idjeniskamar" id="idjeniskamar" value="<?php echo $data_jeniskamar[0]->id_jenis_kamar ?>" />
                        </div>
                        <div class="form-group">
                            <center><input class="btn btn-primary" type="submit" value="Ubah Jenis Kamar" style="border: 0px; margin-top: 30px"></center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="box">
                <div class="box-header">
                   <h3 class="box-title">Ubah Gambar Jenis Kamar</h3>
                </div>
                <div class="box-body">
                    <?php echo $output; ?>
                </div>
            </div>
        </div>
    </div>
</div>