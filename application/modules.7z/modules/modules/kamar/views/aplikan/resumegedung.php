<script>
    var id;
    $(document).ready(function(){
        id = $("#idgedung").val();
        $.ajax({
            type: "POST",
            url: $("#idgedung_form").attr('action'),
            data: $("#idgedung_form").serialize(),
            success: function(data){
                $("tbody#availableroom").html(data);
            }
        });
    });
</script>
<?php 
foreach($css_files as $file): ?>
	<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach($js_files as $file): ?>
	<script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
<div id="container">
    <center><h3 class="oxigenfontblue">Katalog <?php echo $data_gedung_by_id[0]->NAMA_GEDUNG ?></h3></center>
    <hr>
    <div class="row">
        <div class="large-3 columns">
            <label for="jmlkamar" class="oxigenfont right inline" style="color: black">
                Jumlah Kamar
            </label>
        </div>
        <div class="large-9 columns ">
            <input readonly type="text" value="<?php echo $jumlahkamar[0]->jumlah ?>"  id="jmlkamar" name="jmlkamar" />
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="profil" class="oxigenfont right inline" style="color: black">
                Profil
            </label>
        </div>
        <div class="large-9 columns ">
            <textarea readonly type="text" placeholder="Profil Gedung" id="profil" name="profil" ><?php echo $data_gedung_by_id[0]->PROFIL_GEDUNG ?></textarea>
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="jmlkamar" class="oxigenfont right inline" style="color: black">
                Keterangan
            </label>
        </div>
        <div class="large-9 columns ">
            <textarea readonly type="text" placeholder="Keterangan Gedung" id="keterangan" name="keterangan" ><?php echo $data_gedung_by_id[0]->KETERANGAN_GEDUNG ?></textarea>
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="foto" class="oxigenfont right inline" style="color: black">
                Foto Gedung
            </label>
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            
        </div>
        <div class="large-9 columns">
            <?php echo $output; ?>
        </div>
    </div>
    <div class="row" style="margin-top: 15px">
        <div class="large-3 columns">
            <label for="fasilitas" class="oxigenfont right inline" style="color: black">
                Fasilitas
           </label>
        </div>
        <div class="large-9 columns">
            <table style="width: 100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Keterangan</th>
                        <th>Jumlah</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="tabelfasilitas">
                    <?php $a=1; foreach($list_fasilitas as $r) { ?>
                    <tr>
                        <td><?php echo $a ;?></td>
                        <td><?php echo $r->nama ;?></td>
                        <td><?php echo $r->keterangan ;?></td>
                        <td><?php echo $r->jumlah ;?></td>
                        <td></td>
                    </tr>
                    <?php $a++; } ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row" style="margin-top: 15px">
        <form id="idgedung_form" method="post" class="custom" action="<?php echo site_url('kamar/aplikan/available_room_gedung'); ?>">
        <div class="large-3 columns">
            <label for="fasilitas" class="oxigenfont right inline" style="color: black">
                Daftar Kamar
           </label>
            <input type="hidden" id="idgedung" name="idgedung" value="<?php echo $data_gedung_by_id[0]->ID_GEDUNG ?>" />
        </div>
        </form>
        <div class="large-9 columns">
            <table style="width: 100%">
                <thead>
                    <tr>
                        <th>Nomor Kamar</th>
                        <th>Jenis</th>
                        <th>Tersedia</th>
                        <th>Kapasitas</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="availableroom">
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>