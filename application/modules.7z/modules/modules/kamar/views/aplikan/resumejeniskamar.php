<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.2.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script>
    var id;
    $(document).ready(function(){
        id = $("#idjeniskamar").val();
        $.ajax({
            type: "POST",
            url: $("#idjenis_form").attr('action'),
            data: $("#idjenis_form").serialize(),
            success: function(data){
                $("tbody#availableroom").html(data);
            }
        });
    });
</script>
<?php 
foreach($css_files as $file): ?>
	<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach($js_files as $file): ?>
	<script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
<div id="container" >
    <center><h3 class="oxigenfontblue">Katalog Jenis Kamar <?php echo $data_jeniskamar[0]->nama_jenis_kamar ?></h3></center>
    <hr>
    <form  method="POST" class="custom" >
    <div class="row">
        <div class="large-3 columns">
            <label for="nama" class="oxigenfont right inline" style="color: black">
                Nama Jenis Kamar
            </label>
        </div>
        <div class="large-9 columns">
            <input readonly type="text" placeholder="Nama Jenis Kamar" id="nama" name="nama" value="<?php echo $data_jeniskamar[0]->nama_jenis_kamar ?>" required/>
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="kuota" class="oxigenfont right inline" style="color: black">
                Kuota Jenis Kamar
            </label>
        </div>
        <div class="large-9 columns">
            <input readonly type="text" placeholder="Kuota Jenis Kamar" id="kuota" name="kuota" value="<?php echo $data_jeniskamar[0]->quota_kamar ?>" required/>
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="harga" class="oxigenfont right inline" style="color: black">
                Harga Jenis Kamar
            </label>
        </div>
        <div class="large-9 columns">
            <input readonly type="text" placeholder="Harga Jenis Kamar" id="harga" name="harga" value="<?php echo $data_jeniskamar[0]->harga_kamar ?>" required/>
        </div>
    </div>
    <div class="row">
        <div class="large-3 columns">
            <label for="profile" class="oxigenfont right inline" style="color: black">
                Keterangan
            </label>
        </div>
        <div class="large-9 columns">
            <textarea readonly type="text" placeholder="Keterangan" id="keterangan" name="keterangan" value="" required><?php echo $data_jeniskamar[0]->keterangan ?></textarea>
        </div>
    </div>
    </form>
    <div class="row">
        <div class="large-3 columns">
            <label for="galeri" class="oxigenfont right inline" style="color: black">
                Galeri Foto
            </label>
        </div>
        <div class="large-9 columns ">
            <?php echo $output; ?>
        </div>
    </div>
    <div class="row" style="margin-top: 15px">
        <form id="idjenis_form" method="post" class="custom" action="<?php echo site_url('kamar/aplikan/available_room_jeniskamar'); ?>">
        <div class="large-3 columns">
            <label for="fasilitas" class="oxigenfont right inline" style="color: black">
                Daftar Kamar
           </label>
            <input type="hidden" id="idjeniskamar" name="idjeniskamar" value="<?php echo $data_jeniskamar[0]->id_jenis_kamar ?>" />
           
        </div>
        </form>
        <div class="large-9 columns">
            <table style="width: 100%">
                <thead>
                    <tr>
                        <th>Nomor Kamar</th>
                        <th>Jenis</th>
                        <th>Tersedia</th>
                        <th>Kapasitas</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="availableroom">
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    
</div>