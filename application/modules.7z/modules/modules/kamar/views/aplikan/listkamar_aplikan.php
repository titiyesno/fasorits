<script src="<?php echo base_url(); ?>static/ckeditor/ckeditor.js"></script>
<script src="<?php echo base_url(); ?>static/ckeditor/adapters/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.8.1.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.8.1.min.js"></script>
<script>
    function getkamar_bygedung(){
    $.ajax({
        type: "POST",
        url: $("#cari_kamar_form").attr('action'),
        data: $("#cari_kamar_form").serialize(),
        success: function(data) {
                    $("tbody#divkamar").html(data);
        }
    });
    return false;
    };
    
    function daftarkamar(){
    $.ajax({
        type: "POST",
        url: "<?php echo base_url(); ?>index.php/kamar/aplikan/cari_listkamar_ajax",
        success: function(data){
            $("tbody#divkamar").html(data);
        }
        
    });
    };
    window.onload = daftarkamar();
</script>
<div id="container">
    <center><h3 class="oxigenfontblue">Daftar Kamar</h3></center>
    <hr>
    <div id="body">
        <form id="cari_kamar_form" method="post" class="custom" action="<?php echo site_url('index.php/kamar/aplikan/cari_kamar_by_gedung'); ?>">
        <div class="row">
            <div class="large-3 columns">
                <label for="gedung" class="oxigenfont right inline" style="color: black">
                    Pilih gedung
                </label>
            </div>
            <div class="large-9 columns">
                <select onchange="getkamar_bygedung()"  type="text" name="idgedung" id="idgedung">
                    <?php foreach ($data_gedung as $r) { ?>
                        <option value="<?php echo $r->ID_GEDUNG;?>" ><?php echo $r->NAMA_GEDUNG; ?></option>
                    <?php } ?>
                </select>
            </div>
        </div>
        </form>
        <div >
            <table style="width: 100%">
                <thead>
                    <tr>
                        <th>Nomor Kamar</th>
                        <th>Kapasitas Kamar</th>
                        <th>Lantai</th>
                        <th>Status</th>
                        <th>Pesan</th>
                    </tr>
                </thead>
                <tbody id="divkamar">
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <th><input type="button" style="width:auto" value="Pesan"/></th>
                    </tr>
                </tbody>
            </table>
        </div>
        
    </div>
</div>
