<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class umum extends MX_Controller {

    private $filter = array(
        "gender" => array("Laki-Laki" => 0, "Perempuan" => 0),
        "jalur_masuk" => array(
            "PMDK" => 0,
            "Kemitraan" => 0,
            "Bidik Misi" => 0,
            "Depag" => 0,
            "International" => 0,
            "SNMPTN" => 0
        )
    );

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('kamar/gedung_model');
        $this->load->model('kamar/kamar_model');
        $this->load->model('kamar/jeniskamar_model');
        $this->load->model('fasilitas/fasilitas_model');
        $this->load->model('galeri/galeri_model');
        $this->load->library('form_validation');
        $this->load->library('image_CRUD');
    }

    public function index() {
       $data["list_gedung"] = $this->gedung_model->read_gedung();
        $menu = "hf/menu/menu_umum.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('front_end');
        $this->template->title("Gedung Asrama - Asrama ITS");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("roomandfasilities.php", $data);
    }
    public function kamar() {
       $data["list_jeniskamar"] = $this->jeniskamar_model->read_jenis();
        $menu = "hf/menu/menu_umum.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('front_end');
        $this->template->title("Gedung Asrama - Asrama ITS");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("listjeniskamar.php", $data);
    }
    
    public function tambah_gedung() {
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $data['data'] = $this->filter;
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("tambahgedung.php", $data);
    }

    public function SimpanTambahGedung() {
        $namagaleri = $this->input->post('namagaleri');
        $nama = $this->input->post('nama');
        $keterangan = $this->input->post('keterangan');
        $jenis = $this->input->post('jenis');
        $profil = $this->input->post('profil');
        $lat = $this->input->post('lat');
        $long = $this->input->post('long');
        $lantai = $this->input->post('lantai');
        $idgaleri = $this->galeri_model->create_galeri($namagaleri);
        $idgedung = $this->gedung_model->create_gedung($idgaleri, $nama, $keterangan, $jenis, $profil, $lat, $long, $lantai);
        redirect("galeri/admin/organize_foto_galeri/$idgaleri/$idgedung");
    }

    public function daftar_gedung() {
        $data["list_gedung"] = $this->gedung_model->read_gedung();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("listgedung.php", $data);
    }

    public function ubah_gedung($idgaleri = "", $idgedung = "") {
        $data['idgedung'] = $idgedung;
        $data['idkamar'] = "";
        $data['list_fasilitas'] = $this->fasilitas_model->read_fasilitas_by_idgedung($idgedung);
        $data["data_gedung"] = $this->gedung_model->read_gedung_by_id($idgedung);
        $data['data_galeri'] = $this->galeri_model->read_galeri_by_id($idgaleri);
        $image_crud = new image_CRUD();
        $image_crud->set_primary_key_field('ID_GAMBAR');
        $image_crud->set_url_field('ALAMAT_GAMBAR');
        $image_crud->set_title_field('JUDUL_GAMBAR');
        $image_crud->set_table('gambar')
                ->set_relation_field('ID_GALERI')
                ->set_ordering_field('PRIORITAS')
                ->set_image_path('assets/uploads');
        $image_crud->set_idgaleri('ID_GALERI');
        $output = $image_crud->render();
        $data['filter'] = $this->filter;
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav,$data);
        $this->template->set_partial("footer", $footer, $data);
        $this->template->build("ubahgedung.php", $output);
    }

    public function SimpanPerubahanGedung() {
        $id = $this->input->post('idgedung');
        $idgaleri = $this->input->post('galeriid');
        $nama = $this->input->post('nama');
        $keterangan = $this->input->post('keterangan');
        $jenis = $this->input->post('jenis');
        $profil = $this->input->post('profil');
        $lat = $this->input->post('lat');
        $long = $this->input->post('long');
        $this->galeri_model->update_galeri($idgaleri, $nama);
        $this->gedung_model->update_gedung($id, $idgaleri, $nama, $keterangan, $jenis, $profil, $lat, $long);
        redirect("kamar/admin/daftar_gedung");
    }

    public function hapus_gedung($idgedung = "", $idgaleri = "") {
        $this->fasilitas_model->delete_fasilitas_by_gedung($idgedung);
        $this->gedung_model->delete_gedung($idgedung);
        redirect('kamar/admin/daftar_gedung');
    }

    public function tambah_kamar() {
        $data['data_jenis'] = $this->jeniskamar_model->read_jenis();
        $data['data_gedung'] = $this->gedung_model->read_gedung();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("tambahkamar.php", $data);
    }

    public function SimpanTambahKamar() {
        $sewa = $this->input->post('sewa');
        $idgedung = $this->input->post('idgedung');
        $idjenis = $this->input->post('jeniskamar');
        $nomor = $this->input->post('nomor');
        $lantai = $this->input->post('lantai');
        $keterangan = $this->input->post('keterangan');
        $idkamar = $this->kamar_model->create_kamar($idjenis, $idgedung, $nomor, $keterangan, $lantai, $sewa);
        redirect("fasilitas/admin/tambahfasilitas_kamar/$idkamar");
    }

    public function daftar_kamar() {
        $data['data_gedung'] = $this->gedung_model->read_gedung();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("listkamar.php", $data);
    }

    public function semua_kamar() {
        $data['data_gedung'] = $this->gedung_model->read_gedung();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("listkamar.php", $data);
    }

    public function ubah_kamar($idkamar = "") {
        $data['idkamar'] = $idkamar;
        $data['data_jenis'] = $this->jeniskamar_model->read_jenis();
        $data['data_gedung'] = $this->gedung_model->read_gedung();
        $data["data_kamar"] = $this->kamar_model->read_kamar_by_id($idkamar);
        $data['list_fasilitas'] = $this->fasilitas_model->read_fasilitas_by_idkamar($idkamar);
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("ubahkamar.php", $data);
    }

    public function SimpanUbahKamar() {
        $sewa = $this->input->post('sewa');
        $id = $this->input->post('idkamar');
        $idgedung = $this->input->post('idgedung');
        $idjenis = $this->input->post('idjeniskamar');
        $nomor = $this->input->post('nomor');
        $lantai = $this->input->post('lantai');
        $keterangan = $this->input->post('keterangan');
        $this->kamar_model->update_kamar($id, $idjenis, $idgedung, $nomor, $keterangan, $lantai, $sewa);
        redirect("kamar/admin/daftar_kamar");
    }

    public function hapus_kamar($idkamar = "") {
        $error = "Terdapat data Submit yang menggunakan data kamar ini. "
                . "Kamar ini tidak dapat dihapus";
        if($this->kamar_model->delete_kamar($idkamar)==0){
            echo "<script type='text/javascript'>alert(\"$error\");</script>";
            $this->ubah_kamar($idkamar);
        }
        else redirect("kamar/admin/daftar_kamar");
        
    }

    function getKoordinat() {
        header('Cache-Control: no-cache, must-revalidate');
        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');

        $datakoordinat = $this->gedung_model->getAllKoordinat();
        echo json_encode(array('hasil' => $datakoordinat));
    }

    public function cari_listkamar_ajax() {
        $list_kamar = $this->kamar_model->read_nomor_kuota_kamar();
        $a = 1;
        $htmlres = '';
        foreach ($list_kamar as $r) {
            $htmlres .=
                    "
                    <table style=\"width: 100%\">
                        <tbody>
                            <tr>
                                <td><a href=\"" . base_url() . "index.php/kamar/admin/ubah_kamar/$r->id_kamar\">$r->nomer_kamar</a></td>
                                <td></td>
                                <td>$r->quota_kamar</td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                ";
            $a++;
        }
        echo $htmlres;
    }

    public function cari_kamar_by_gedung() {
        $idgedung = $this->input->post('idgedung');
        $data_kamar = $this->kamar_model->read_kamar_by_gedung($idgedung);
        $a = 1;
        $htmlres = '';
        foreach ($data_kamar as $r) {
            $htmlres .=
                    "
                    <table style=\"width: 100%\">
                        <tbody>
                            <tr>
                                <td><a href=\"" . base_url() . "index.php/kamar/admin/ubah_kamar/$r->ID_KAMAR\">$r->NOMER_KAMAR</a></td>
                                <td>$r->Penghuni</td>
                                <td>$r->quota_kamar</td>
                                <td>$r->STATUS</td>
                            </tr>
                        </tbody>
                    </table>
                ";
            $a++;
        }
        echo $htmlres;
    }

    public function tambah_jeniskamar() {
//        $data['listgaleri'] = $this->galeri_model->read_galeri();
        $menu = "hf/menu/menu_pengelola.php";
//        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("tambahjeniskamar.php");
    }

    public function SimpanTambahJenisKamar() {
        $namagaleri = $this->input->post('namagaleri');
        $nama = $this->input->post('nama');
        $keterangan = $this->input->post('keterangan');
        $kuota = $this->input->post('kuota');
        $harga = $this->input->post('harga');
        $idgaleri = $this->galeri_model->create_galeri($namagaleri);
        $idjeniskamar = $this->jeniskamar_model->create_jenis($idgaleri, $nama, $kuota, $harga, $keterangan);
        redirect("galeri/admin/organize_foto_galeri_jeniskamar/$idgaleri/$idjeniskamar");
    }

    public function ubah_jeniskamar($idgaleri = "", $id = "") {
        $data["data_jeniskamar"] = $this->jeniskamar_model->read_jeniskamar_by_id($id);
        $data['data_galeri'] = $this->galeri_model->read_galeri_by_id($idgaleri);
        $image_crud = new image_CRUD();
        $image_crud->set_primary_key_field('ID_GAMBAR');
        $image_crud->set_url_field('ALAMAT_GAMBAR');
        $image_crud->set_title_field('JUDUL_GAMBAR');
        $image_crud->set_table('gambar')
                ->set_relation_field('ID_GALERI')
                ->set_ordering_field('PRIORITAS')
                ->set_image_path('assets/uploads');
        $image_crud->set_idgaleri('ID_GALERI');
        $output = $image_crud->render();

        $menu = "hf/menu/menu_pengelola.php";
//        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav,$data);
        $this->template->set_partial("footer", $footer, $data);
        $this->template->build("ubahjeniskamar.php", $output);
    }

    public function SimpanUbahJenisKamar() {
        $id = $this->input->post('idjeniskamar');
        $idgaleri = $this->input->post('tes');
        $nama = $this->input->post('nama');
        $keterangan = $this->input->post('keterangan');
        $kuota = $this->input->post('kuota');
        $harga = $this->input->post('harga');
        $this->galeri_model->update_galeri($idgaleri, $nama);
        $this->jeniskamar_model->update_jeniskamar($id, $idgaleri, $nama, $kuota, $harga, $keterangan);
        redirect("kamar/admin/daftar_jeniskamar");
    }

    public function daftar_jeniskamar() {
        $data["list_jeniskamar"] = $this->jeniskamar_model->read_jenis();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("listjeniskamar.php", $data);
    }

    public function hapus_jeniskamar($id = "", $idgaleri = "") {
        $this->galeri_model->delete_galeri($idgaleri);
        $this->jeniskamar_model->delete_jeniskamar($id);
        redirect('kamar/admin/daftar_jeniskamar');
    }

    function organize_foto_galeri($id = "") {
        $data['datagaleri'] = $this->galeri_model->read_galeri_by_id($id);
        $image_crud = new image_CRUD();
        $image_crud->set_primary_key_field('ID_GAMBAR');
        $image_crud->set_url_field('ALAMAT_GAMBAR');
        $image_crud->set_title_field('JUDUL_GAMBAR');
        $image_crud->set_token("Syalala");
        $image_crud->set_table('gambar')
                ->set_relation_field('ID_GALERI')
                ->set_ordering_field('PRIORITAS')
                ->set_image_path('assets/uploads');
        $image_crud->set_idgaleri('ID_GALERI');
        $output = $image_crud->render();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav,$data);
        $this->template->set_partial("footer", $footer, $data);
        $this->template->build("viewalbum.php", $output);
    }

    public function upload() {
        if (isset($_FILES['upload']['name'])) {
            // total files //
            $count = count($_FILES['upload']['name']);
            // all uploads //
            $uploads = $_FILES['upload'];

            for ($i = 0; $i < $count; $i++) {
                if ($uploads['error'][$i] == 0) {
                    move_uploaded_file($uploads['tmp_name'][$i], 'storage/' . $uploads['name'][$i]);
                    echo $uploads['name'][$i] . "\n";
                }
            }
        }
    }

    function lihat_galeri($id = "") {
        $data['datagaleri'] = $this->galeri_model->read_galeri_by_id($id);
        $image_crud = new image_CRUD();
        $image_crud->unset_upload();
        $image_crud->unset_delete();

        $image_crud->set_primary_key_field('ID_GAMBAR');
        $image_crud->set_url_field('ALAMAT_GAMBAR');
        $image_crud->set_table('gambar')
                ->set_relation_field('ID_GALERI')
                ->set_ordering_field('PRIORITAS')
                ->set_image_path('assets/uploads');

        $output = $image_crud->render();

        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav,$data);
        $this->template->set_partial("footer", $footer, $data);
        $this->template->build("viewalbum.php", $output);
    }

}

?>
