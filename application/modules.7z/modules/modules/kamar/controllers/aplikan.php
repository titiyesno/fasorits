<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class aplikan extends Aplikan_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('kamar/gedung_model');
        $this->load->model('kamar/kamar_model');
        $this->load->model('kamar/jeniskamar_model');
        $this->load->model('galeri/galeri_model');
        $this->load->model('fasilitas/fasilitas_model');
        $this->load->library('form_validation');
        $this->load->library('image_CRUD');
        //tes
    }
    
    public function index() {
        redirect('kuisioner/aplikan');
    }
    
    public function kataloggedung($idgaleri="") {
        $id = $this->input->post('idgedung');
        
        $data['datagaleri'] = $this->galeri_model->read_galeri_by_id($idgaleri);
        $image_crud = new image_CRUD();
        $image_crud->unset_upload();
        $image_crud->unset_delete();
        $image_crud->set_primary_key_field('ID_GAMBAR');
        $image_crud->set_url_field('ALAMAT_GAMBAR');
        $image_crud->set_table('gambar')
        ->set_relation_field('ID_GALERI')
        ->set_ordering_field('PRIORITAS')
        ->set_image_path('assets/uploads');
        $output = $image_crud->render();
        
        $data['rooms'] = $this->kamar_model->available_room_bygedung($id);
        $data['list_fasilitas'] = $this->fasilitas_model->read_fasilitas_by_idgedung($id);
        $data['data_gedung_by_id'] = $this->gedung_model->read_gedung_by_id($id);
        $data['jumlahkamar'] = $this->gedung_model->CountRoom($id);
        $data['data_gedung'] = $this->gedung_model->read_gedung();
        $data['list_jeniskamar'] = $this->jeniskamar_model->read_jenis();
        $menu = "hf/menu/menu_pemesan.php";
        $subnav = "hf/subnav/subnavkatalog_aplikan.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('front_end');
        $this->template->title("Katalog Gedung");
        $this->template->set_partial("subnav", $subnav, $data);
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("aplikan/resumegedung.php",$output);
    }
    
    public function katalogjeniskamar($idgaleri="") {
        $id = $this->input->post('idjeniskamar');
        
        $data['datagaleri'] = $this->galeri_model->read_galeri_by_id($idgaleri);
        $image_crud = new image_CRUD();
        $image_crud->unset_upload();
        $image_crud->unset_delete();
        $image_crud->set_primary_key_field('ID_GAMBAR');
        $image_crud->set_url_field('ALAMAT_GAMBAR');
        $image_crud->set_table('gambar')
        ->set_relation_field('ID_GALERI')
        ->set_ordering_field('PRIORITAS')
        ->set_image_path('assets/uploads');
        $output = $image_crud->render();
        
        $data['rooms'] = $this->kamar_model->available_room_byjeniskamar($id);
        $data['data_jeniskamar'] = $this->jeniskamar_model->read_jeniskamar_by_id($id);
        $data['data_gedung'] = $this->gedung_model->read_gedung();
        $data['list_jeniskamar'] = $this->jeniskamar_model->read_jenis();
        $menu = "hf/menu/menu_pemesan.php";
        $subnav = "hf/subnav/subnavkatalog_aplikan.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('front_end');
        $this->template->title("Katalog Jenis Kamar");
        $this->template->set_partial("subnav", $subnav, $data);
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("aplikan/resumejeniskamar.php",$output);
    }
    
    public function available_room_jeniskamar() {
        $id = $this->input->post('idjeniskamar');
        $list_kamar = $this->kamar_model->available_room_byjeniskamar($id);
        $a=1;
        $htmlres = '';
        foreach ($list_kamar as $r) 
          { 
            if($r->Available!=0)
            {
                $htmlres .= 
                    "
                        <tr>
                            <td>$r->NOMER_KAMAR</td>
                            <td>$r->nama_jenis_kamar</td>
                            <td>$r->Available orang</td>
                            <td>$r->quota_kamar orang</td>
                            <td><a class=\"button oxigenfont\" href=\"".base_url()."/index.php/pemesanan/aplikan/$r->ID_KAMAR\">Pesan</a></td>
                        </tr>
                    ";
            }
            else
            {
                $htmlres .= 
                    "
                        <tr>
                            <td>$r->NOMER_KAMAR</td>
                            <td>$r->nama_jenis_kamar</td>
                            <td>-</td>
                            <td>$r->quota_kamar orang</td>
                            <td><a class=\"button oxigenfont\" style=\"background-color: #e9635b\" >Penuh</a></td>
                        </tr>
                    ";
            }
            $a++;
          } 
          echo $htmlres;
    }
    
    public function available_room_gedung() {
        $id = $this->input->post('idgedung');
        $list_kamar = $this->kamar_model->available_room_bygedung($id);
        $a=1;
        $htmlres = '';
        foreach ($list_kamar as $r) 
          { 
            if($r->Available!=0)
            {
                $htmlres .= 
                    "
                        <tr>
                            <td>$r->NOMER_KAMAR</td>
                            <td>$r->nama_jenis_kamar</td>
                            <td>$r->Available orang</td>
                            <td>$r->quota_kamar orang</td>
                            <td><a class=\"button oxigenfont\" href=\"".base_url()."/index.php/pemesanan/aplikan/$r->ID_KAMAR\">Pesan</a></td>
                        </tr>
                    ";
            }
            else
            {
                $htmlres .= 
                    "
                        <tr>
                            <td>$r->NOMER_KAMAR</td>
                            <td>$r->nama_jenis_kamar</td>
                            <td>-</td>
                            <td>$r->quota_kamar orang</td>
                            <td><a class=\"button oxigenfont\" style=\"background-color: #e9635b\" >Penuh</a></td>
                        </tr>
                    ";
            }
            $a++;
          } 
          echo $htmlres;
    }
    
    public function getgedung_byid()
    {
        header('Cache-Control: no-cache, must-revalidate');
        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');
        
        $data = $this->input->post('d');
        $dataid = $data['idgedung'];
        $datagedung = $this->gedung_model->read_gedung_by_id($dataid);
        echo json_encode(array('datagedung'=>$datagedung));
    }
    
    public function getjeniskamar_byid()
    {
        header('Cache-Control: no-cache, must-revalidate');
        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');
        
        $data = $this->input->post('d');
        $dataid = $data['idjeniskamar'];
        $datajeniskamar = $this->jeniskamar_model->read_jeniskamar_by_id($dataid);
        echo json_encode(array('datajeniskamar'=>$datajeniskamar));
    }
}

?>
