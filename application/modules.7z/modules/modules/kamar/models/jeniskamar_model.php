<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class jeniskamar_model extends CI_model {
    
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function create_jenis($idgaleri,$nama,$kuota,$harga,$ket){
        $data = array(
            'ID_GALERI' => $idgaleri,
            'NAMA_JENIS_KAMAR' => $nama,
            'QUOTA_KAMAR' => $kuota,
            'HARGA_KAMAR' => $harga,
            'KETERANGAN' => $ket
        );
        $this->db->insert('jenis_kamar', $data);    
        return $this->db->insert_id();
    }
    
    public function read_jenis(){
        $query = $this->db->get('view_jenis_kamar');
        return $query->result();
    }
    
    public function read_jeniskamar_by_id($id){
        $this->db->where('ID_JENIS_KAMAR',$id);
        $query = $this->db->get('jenis_kamar');
        return $query->result();
    }
    
    public function getById(){
        $this->db->select('ID_JENIS_KAMAR');
        $this->db->from('jenis_kamar');
        $query=$this->db->get()->result();
        return $query;
    }
    
    public function update_jeniskamar($id,$idgaleri,$nama,$kuota,$harga,$ket){

        $data = array(
            'ID_GALERI' => $idgaleri,
            'NAMA_JENIS_KAMAR' => $nama,
            'QUOTA_KAMAR' => $kuota,
            'HARGA_KAMAR' => $harga,
            'KETERANGAN' => $ket
        );
        $this->db->where('ID_JENIS_KAMAR',$id);
        $result = $this->db->update('jenis_kamar', $data);
        return $result; 
    }
    
    public function delete_jeniskamar($id){
        $this->db->where('ID_JENIS_KAMAR', $id);
        $this->db->delete('jenis_kamar');
    }
    
    public function getAllJenisKamarWithCapacity()
    {
        
    }
    
}