<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class kamar_model extends CI_model {

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function create_kamar($idjenis, $idgedung, $nomer, $ket, $lantai, $sewa) {

        $data = array(
            'ID_JENIS_KAMAR' => $idjenis,
            'ID_GEDUNG' => $idgedung,
            'NOMER_KAMAR' => $nomer,
            'KETERANGAN_KAMAR' => $ket,
            'LANTAI' => $lantai,
            'STATUS_SEWA' => $sewa
        );
        $this->db->insert('kamar', $data);
        $idkamar = $this->db->insert_id();
        $sqlquota = "select jenis_kamar.quota_kamar 
        from jenis_kamar, kamar
        WHERE jenis_kamar.id_jenis_kamar = kamar.ID_JENIS_KAMAR and kamar.ID_KAMAR = $idkamar";
        $temp = $this->db->query($sqlquota)->result();
        $jml = $temp[0]->quota_kamar;
        $sql = "insert into fasilitas (id_gedung,id_kamar,nama,keterangan,jumlah) "
                . "VALUES (null,'$idkamar','Kursi','Kursi Belajar','$jml') , "
                . "(null,'$idkamar','Kasur','Kasur Spring Bed','$jml') , (null,'$idkamar','Lemari','Lemari Pakaian','$jml')";
        $this->db->query($sql);
        return $idkamar;
    }

    public function read_kamar() {
        $query = $this->db->get('kamar');
        return $query->result();
    }

    public function read_nomor_kuota_kamar() {
        $query = "SELECT k.id_kamar, k.nomer_kamar, jk.quota_kamar, k.LANTAI
                FROM kamar k, jenis_kamar jk
                WHERE k.id_jenis_kamar = jk.id_jenis_kamar";
        return $this->db->query($query)->result();
    }

    public function read_kamar_by_id($id) {
        $this->db->where('ID_KAMAR', $id);
        $query = $this->db->get('kamar');
        return $query->result();
    }

    public function available_room_byjeniskamar($idjeniskamar) {
        $query = "select kamar.ID_KAMAR, kamar.NOMER_KAMAR, jenis_kamar.nama_jenis_kamar, 
        jenis_kamar.quota_kamar - COUNT(submit.ID_SUBMIT) as 'Available', 
        jenis_kamar.quota_kamar
        from 
        kamar 
        left join jenis_kamar on (jenis_kamar.id_jenis_kamar=kamar.ID_JENIS_KAMAR)
        left join submit on (submit.ID_KAMAR=kamar.ID_KAMAR)
        left join periode on (submit.ID_PERIODE=periode.ID_PERIODE)
        WHERE jenis_kamar.id_jenis_kamar = $idjeniskamar and kamar.STATUS_SEWA = 1
        GROUP by kamar.ID_KAMAR";
        return $this->db->query($query)->result();
    }

    public function available_room_bygedung($idgedung) {
        $query = "select kamar.ID_KAMAR, kamar.NOMER_KAMAR, jenis_kamar.nama_jenis_kamar, 
        jenis_kamar.quota_kamar - COUNT(submit.ID_SUBMIT) as 'Available', 
        jenis_kamar.quota_kamar
        from 
        kamar 
        left join jenis_kamar on (jenis_kamar.id_jenis_kamar=kamar.ID_JENIS_KAMAR)
        left join submit on (submit.ID_KAMAR=kamar.ID_KAMAR)
        left join periode on (submit.ID_PERIODE=periode.ID_PERIODE)
        WHERE kamar.ID_GEDUNG = $idgedung
        GROUP by kamar.ID_KAMAR";
        return $this->db->query($query)->result();
    }

    public function read_kamar_by_gedung($id) {
        $sql = 'select kamar.ID_KAMAR, kamar.NOMER_KAMAR, count(b.ID_SUBMIT) as "Penghuni", if(kamar.STATUS_SEWA=0,"Tidak Disewakan","Disewakan") as "STATUS" , jenis_kamar.quota_kamar
                from kamar left join (select * from submit where submit.STATUS_SUBMIT!="daftar") b on (kamar.ID_KAMAR=b.ID_KAMAR) left join jenis_kamar on (jenis_kamar.id_jenis_kamar=kamar.ID_JENIS_KAMAR)
                left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG)
                where gedung.ID_GEDUNG=?
                group by kamar.ID_KAMAR';
        return $this->query($sql, array($id));
    }

        public function getdataforpivotkamar() {
        $sql = 'select kamar.ID_KAMAR, count(b.ID_SUBMIT) as "Penghuni", kamar.NOMER_KAMAR, 
kamar.KETERANGAN_KAMAR, kamar.LANTAI, if(kamar.STATUS_SEWA=1,"DISEWAKAN","TIDAK DISEWAKAN") as "STATUS_SEWA",
                jenis_kamar.nama_jenis_kamar, jenis_kamar.quota_kamar, jenis_kamar.harga_kamar, 
                gedung.NAMA_GEDUNG
                from kamar left join jenis_kamar on (kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar) 
                left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG)
                left join (select * from submit where submit.STATUS_SUBMIT="diterima" or submit.STATUS_SUBMIT="penghuni") b on (b.ID_KAMAR=kamar.ID_KAMAR)

                group by kamar.ID_KAMAR ';
        return $this->query($sql);
    }
    public function getById() {
        $this->db->select('ID_KAMAR');
        $this->db->select('NOMER_KAMAR');
        $this->db->from('kamar');
        $query = $this->db->get()->result();
        return $query;
    }

    public function update_kamar($id, $idjenis, $idgedung, $nomer, $ket, $lantai, $sewa) {

        $data = array(
            'ID_JENIS_KAMAR' => $idjenis,
            'ID_GEDUNG' => $idgedung,
            'NOMER_KAMAR' => $nomer,
            'KETERANGAN_KAMAR' => $ket,
            'LANTAI' => $lantai,
            'STATUS_SEWA' => $sewa
        );
        $this->db->where('ID_KAMAR', $id);
        $result = $this->db->update('kamar', $data);
        return $result;
    }

    public function delete_kamar($id) {
        $sql = 'select * from fasilitas where fasilitas.ID_KAMAR=?';
        $data = $this->query($sql, array($id));
        $sql2 = 'select * from submit where submit.ID_KAMAR=?';
        $data2 = $this->query($sql, array($id));

        if (count($data2) > 0)
            return 0;
        else {
            $sql = 'delete from fasilitas where id_kamar=?';
            echo $sql;
            $this->query($sql, array($id));

            $sql = 'delete from kamar where ID_KAMAR=?';
            echo $sql;
            $this->query($sql, array($id));
            return 1;
        }
    }

}
