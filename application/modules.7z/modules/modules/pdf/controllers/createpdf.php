<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

//Controller: application/controllers/createpdf.php
class createpdf extends CI_Controller {
    var $var_image;
    function __construct() {
        parent::__construct();
        $this->load->helper(array('html', 'form', 'text', 'url'));
        $this->load->helper('file');
        $this->load->model('fasilitas/fasilitas_model');
        $this->load->model('kamar/gedung_model');
        $this->load->helper('pdf_helper');
    }

    function index() {
        $this->load->view('HTMLpage', array('error' => ' '));
    }
    
    function cetak($idgedung){
        $tes['datagedung'] = $this->gedung_model->read_gedung_by_id($idgedung);
        $tes['data'] = $this->fasilitas_model->read_fasilitas_by_idgedung($idgedung);
        $this->load->view('tes',$tes);
    }

    function saveaspdf() {
        $configg['upload_path'] = './uploads/';
        $configg['allowed_types'] = 'gif|jpg|png';
        $configg['max_size'] = '2000';
        $configg['max_width'] = '5000';
        $configg['max_height'] = '5000';
        //$var_array = array("gambar" => "");
        $cek = false;
        $this->load->library('upload', $configg);
        if (!$this->upload->do_upload()) {
            $error = array('error' => $this->upload->display_errors());
            $this->load->view('HTMLpage', $error);
        } else {
            $data = array('upload_data' => $this->upload->data());
            $this->var_image = $data['upload_data']['full_path'];
            //$var_image = $data['upload_data']['full_path'];
            //$var_array = array("gambar" => $str);
            $cek = true;
            if ($cek == true) {
                $this->load->helper('pdf_helper');
                $tes['nama'] = $this->input->post('nama');
                $tes['alamat'] = $this->input->post('alamat');
                $tes['nohp'] = $this->input->post('nohp');
                $tes['citacita'] = $this->input->post('citacita');
                $tes['var_image'] = $this->var_image;
            }
            $this->load->view('pdfreport', $tes);
        }

        //echo 'berhasil';
        
    }

}

?>
