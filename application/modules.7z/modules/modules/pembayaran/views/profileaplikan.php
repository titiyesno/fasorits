<section class="content-header">
	<h1>
        Pembayaran [<?php echo $aplikan[0]->NRP_APLIKAN; ?>]
        <small>Transaksi</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i
				class="fa fa-dashboard"></i> Home</a></li>
		<li class="active">Reservasi</li>
		<li class="">Pembayaran</li>
	</ol>
</section>

<?php
$d = $status [0];
if ($d->STATUS == "BELUM LUNAS")
	$warna = "danger";
else
	$warna = "info";
$kurang = $d->KURANG;
?>

<section class="content">
	<div class="row">
		<div class="col-sm-12">
		<div class="box box-danger">
	<div class="box-header">
		<h3 class="box-title">
			Perilaku Khusus
		</h3>
	</div>
	<div class="box-body">
	<p class="callout callout-danger">
	Mahasiswa Berikut ini Mengundurkan diri dari Asrama dan Tidak Memiliki Tanggung jawab Pembayaran
	<a href="<?php echo base_url("index.php/pemesanan/admin/reject/".$aplikan[0]->ID_SUBMIT)?>" class="btn btn-danger">
					Reject Mahasiswa
						</a>
	</p>
	<p class="callout callout-danger">
	Mahasiswa Berikut ini Bersedia Untuk Pindah Kamar 
	<a href="<?php echo base_url("index.php/pindahkamar/admin/pilihkamar/".$aplikan[0]->NRP_APLIKAN)?>" class="btn btn-primary">
					Pindah Kamar
						</a>
	</p>
	</div>
</div>
			<div class="box">
				<div class="box-header">
					<h3 class="box-title">Payment</h3>
				</div>
				<div class="box-body">
					<p class="callout callout-<?php echo $warna ?>">
            		<?php if ($d->STATUS == "BELUM LUNAS"  ) { ?>
            		Mahasiswa ini memiliki Tunggakan sebesar Rp. 
            		<?php
															
															echo numberToConcurent ( ".", $kurang );
														} else
															echo "Lunas";
														?>,-
        			</p>
        			<?php if (count($kuisioner) == 0) { ?>
			        <p class="callout callout-danger">Mahasiswa Ini belum Mengisi
						Kuisioner</p>
			        <?php } else { ?>
			        <p class="callout callout-primary">Mahasiswa Ini Sudah
						Mengisi Kuisioner</p>    
			    	<?php } ?>
			    	
			    	   	               					
					
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="box">
				<div class="box-header">
					<h3 class="box-title">Form Pembayaran Asrama</h3>
				</div>
				<div class="box-body">
				<?php foreach ( $angsuran as $data1 ) { ?>
			    	<?php echo form_open("pembayaran/admin/pay")?>
						<div class="form-group">
						<label>NRP</label>
							<?php echo $data1->NRP_APLIKAN; ?>
						</div>
					<div class="form-group">
						<label>Jenis Kamar</label>
							<?php echo $data1->nama_jenis_kamar; ?>
						</div>
					<div class="form-group">
						<label>Jumlah Pembayaran</label> <input type="text" name="nominal"
							placeholder="Rp." />
					</div>
					<div class="form-group">
						<label>Tanggal Pembayaran</label> <input type="date" id="tanggal"
							name="tanggal" />
					</div>
					<div class="form-group">
						<label>Via</label> <select name="via">
							<option>Transfer</option>
							<option>Tunai</option>
							<option>Debit</option>
						</select>
					</div>
					<div class="form-group">
						<label>Action</label> <input type="hidden" name="id"
							value="<?php echo $data1->ID_SUBMIT; ?>" /> <input type="hidden"
							name="nrp" value="<?php echo $data1->NRP_APLIKAN; ?>" /><input
							type="hidden" name="kode_booking"
							value="<?php echo $aplikan[0]->CODE_BOOKING; ?>" /> <input
							type="submit" value="Confirm" class="small round button" />
					</div>
					</form>
                            <?php } ?>    
                            <table class="table-bordered" style="width: 100%">
						<thead>
							<tr>
								<th>No</th>
								<th>Tanggal Entri</th>
								<th>Nominal</th>
								<th>Tanggal Bayar</th>
								<th>Via</th>
								<th>Bukti</th>
                                                                <th>Hapus</th>

							</tr>
						</thead>
						<tbody>
                        <?php
																								$a = 1;
																								foreach ( $histori as $data1 ) {
																									?>
                            <tr>
								<td><?php
																									echo $a;
																									$a ++;
																									?></td>
								<td><?php echo $data1->TANGGAL_ANGSURAN; ?></td>
								<td><?php echo "Rp. " .  numberToConcurent(".",$data1->NOMINAL_ANGSURAN); ?></td>
								<td><?php echo $data1->TANGGAL_BAYAR; ?></td>
								<td><?php echo $data1->VIA; ?></td>
								<td><a
									onclick="window.open('<?php echo base_url("index.php/pembayaran/admin/bukti/" . $data1->ID_ANGSURAN) ?>', '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');">Cetak
										Bukti</a></td>
                                                                                <td><a href="<?php echo base_url()?>index.php/pembayaran/admin/hapus/<?php echo $data1->ID_ANGSURAN."/".$aplikan[0]->NRP_APLIKAN?>">Hapus</a></td>
							</tr>
                        <?php } ?>
                    </tbody>
					</table>
				</div>
			</div>
			
		</div>
            <input type="money"/>
		<div class="col-sm-6">
			<div class="box">
				<div class="box-header">
					<h3 class="box-title">Form Pembayaran Deposito</h3>
				</div>
				<div class="box-body">
				<?php echo form_open("pembayaran/admin/deposit")?>
					<div class="form-group">
						<label>Tanggal Pembayaran</label> <input type="date" id="tanggal"
							name="tanggal" />
					</div>
					<div class="form-group">
						<label>Jumlah Pembayaran</label> <input type="text" name="nominal"
							placeholder="Rp." />
					</div>
					<div class="form-group">
						<label>Action</label> <input type="hidden" name="id"
							value="<?php echo $data1->ID_SUBMIT; ?>" /> <input type="hidden"
							name="nrp" value="<?php echo $data1->NRP_APLIKAN; ?>" /><input
							type="hidden" name="kode_booking"
							value="<?php echo $aplikan[0]->CODE_BOOKING; ?>" /> <input
							type="submit" value="Confirm" class="small round button" />
					</div>
					</form>
					<table class="table-bordered" style="width: 100%">
						<thead>
							<tr>
								<th>No</th>
								<th>Tanggal Bayar</th>
								<th>Nominal</th>
								<th>Bukti</th>
							</tr>
						</thead>
						<tbody>
                        <?php
							$a = 1;
							foreach ( $deposit as $data1 ) {
							?>
                            <tr>
								<td><?php 
								echo $a;
								$a ++;
								?></td>
								<td><?php echo $data1->TANGGAL_BAYAR_DEPOSITO; ?></td>
								<td><?php echo "Rp. " . numberToConcurent(".",$data1->DEPOSIT); ?></td>
								<td><a
									onclick="window.open('<?php echo base_url("index.php/pembayaran/admin/bukti/" . $data1->ID_SUBMIT) ?>', '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');">Cetak
										Bukti</a></td>
							</tr>
                        <?php } ?>
                    </tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<div class="row"></div>
	<div class="row">
		<div class="col-sm-6">
			<div class="box box-primary">
				<div class="box-header">
					<h3 class="box-title">Information</h3>
				</div>
				<div class="box-body">
					<div class="form-group">
						<label> Nama </label>
						<h4><?php echo $aplikan[0]->NAMA_APLIKAN; ?></h4>
					</div>
					<div class="form-group">
						<label> TTL </label>
						<h4><?php echo $aplikan[0]->TEMPAT_LAHIR_APLIKAN; ?>, <?php echo $aplikan[0]->TGL_LAHIR_APLIKAN; ?></h4>
					</div>
					<div class="form-group">
						<label> Jenis Kelamin </label>
						<h4><?php echo $aplikan [0]->JENIS_KEL_APLIKAN ?></h4>
					</div>
					<div class="form-group">
						<label> Agama </label>
						<h4><?php echo $aplikan[0]->AGAMA_APLIKAN; ?></h4>
					</div>
					<div class="form-group">
						<label> Alamat </label>
						<h4><?php echo $aplikan[0]->ALAMAT_APLIKAN; ?></h4>
					</div>
					<div class="form-group">
						<label> Telp </label>
						<h4><?php echo $aplikan[0]->TELP_APLIKAN; ?></h4>
					</div>
					<hr>
					<div class="form-group">
						<label> Jurusan </label>
						<h4><?php echo $aplikan[0]->JURUSAN_APLIKAN; ?></h4>
					</div>
					<div class="form-group">
						<label> Fakultas </label>
						<h4><?php echo $aplikan[0]->FAKULTAS_APLIKAN; ?></h4>
					</div>
					<div class="form-group">
						<label> Program Diterima </label>
						<h4><?php echo $aplikan[0]->PROGRAM_DITERIMA; ?></h4>
					</div>
					<div class="form-group">
						<label> Nama Orangtua </label>
						<h4><?php echo $aplikan[0]->NAMA_ORANGTUA; ?></h4>
					</div>
					<div class="form-group">
						<label> Alamat Orangtua </label>
						<h4><?php echo $aplikan[0]->ALAMAT_ORANGTUA; ?></h4>
					</div>
					<div class="form-group">
						<label> Telp Orangtua </label>
						<h4><?php echo $aplikan[0]->TELP_ORANGTUA; ?></h4>
					</div>
					<div class="form-group">
						<label> Pekerjaan Orangtua </label>
						<h4><?php echo $aplikan[0]->PEKERJAAN_ORANTUA; ?></h4>
					</div>
					<div class="form-group">
						<label> Penhasilan Orangtua/Bulan </label>
						<h4>Rp. <?php echo  numberToConcurent ( ".",  $aplikan[0]->PENGHASILAN_ORANGTUA ); ?></h4>
					</div>
				</div>
				<div class="form-group">
					<img class="img-thumbnail" style="width: 100%"
						data-caption="Copy KTP"
						src="<?php echo base_url('content/aplikan/uploads/' . $aplikan[0]->COPY_KTP) ?>" />
					<img class="img-thumbnail" style="width: 100%"
						data-caption="Copy Foto"
						src="<?php echo base_url('content/aplikan/uploads/' . $aplikan[0]->COPY_KTP) ?>" />
					<img class="img-thumbnail" style="width: 100%"
						data-caption="Copy KTM"
						src="<?php echo base_url('content/aplikan/uploads/' . $aplikan[0]->COPY_FOTO) ?>" />
				</div>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="box box-primary">
				<div class="box-header">
					<h3 class="box-title">Pemesanan</h3>
				</div>
				<div class="box-body">
					<div class="form-group">
						<label>Code Booking</lable>
							<h4><?php echo $aplikan[0]->CODE_BOOKING; ?></h4>
					
					</div>
					<div class="form-group">
						<label> Rooms </label>
						<h4><?php echo $aplikan[0]->NOMER_KAMAR; ?></h4>
					</div>
					<div class="form-group">
						<label> Nama Gedung </label>
						<h4><?php echo $aplikan[0]->NAMA_GEDUNG; ?></h4>
					</div>
					<div class="form-group">
						<label> Lantai </label>
							<?php echo $aplikan[0]->LANTAI; ?>
					</div>
					<div class="form-group">
						<label> Jenis Kamar </label>
						<h4><?php echo $aplikan[0]->nama_jenis_kamar; ?></h4>
					</div>
					<div class="form-group">
						<label>Bulan Masuk</lable>
							<h4><?php echo date("F", mktime(null, null, null, $aplikan[0]->BULAN_MASUK));?></h4>
					
					</div>
					<div class="form-group">
						<label>Angsuran</lable>
							<h4><?php echo $aplikan[0]->ANGSURAN; ?></h4>
					
					</div>
				</div>
			</div>
		</div>

	</div>

</section>

