<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class model_user extends CI_model {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->load->view('login');
    }

    function getUserNonActiv() {
        $sql = 'select * from akun left join aplikan on (akun.ID_AKUN=aplikan.ID_AKUN) where aplikan.STATUS=0';
        return $this->query($sql);
    }

    function getFakultas($jurusan) {
        $sql = 'select * from jurusan where nama=?';
        return $this->query($sql, array($jurusan));
    }
    function update($data,$id){
        $this->db->where("ID_APLIKAN",$id);
        $this->db->update("aplikan",$data);
    }
            function activ($nrp, $noreg) {
        $sql = 'select * from akun, aplikan where aplikan.ID_AKUN=akun.ID_AKUN and akun.PASSWORD=? and aplikan.NRP_APLIKAN=?';
        $result = $this->query($sql, array($noreg, $nrp));
        if (count($result) == 1) {
            $data = array(
                'STATUS' => '1',
            );
            print_r($result);
            $this->db->where('NRP_APLIKAN', $nrp);
            $this->db->update('aplikan', $data);
        }
    }

    function getaplikan($id) {
        $sql = "select * from aplikan where id_aplikan=?";
        return $this->query($sql, array($id));
    }

    function login($uname, $passw) {
        if (isset($uname) && isset($passw) && $uname != "" && $passw != "") {
            $sql = "call login(?,?,@privilege,@id,@nama)";
            $this->query($sql, array($uname, $passw));
            return $this->query("select @privilege as privilege, @id as id, @nama as nama");
        }
    }

    function updatefotoApp($ktm, $ktp, $foto, $nrp) {
        $data = array(
            'COPY_KTM' => $ktm,
            'COPY_KTP' => $ktp,
            'COPY_FOTO' => $foto
        );

        $this->db->where('NRP_APLIKAN', $nrp);
        $this->db->update('aplikan', $data);
    }

    function cek_jumlahsubmit($id) {
        $sql = "select aplikan.ID_APLIKAN, aplikan.NRP_APLIKAN, count(submit.ID_SUBMIT) as 'N' from aplikan left join submit on (submit.ID_APLIKAN=aplikan.ID_APLIKAN)
                where aplikan.ID_APLIKAN=?
                group by aplikan.ID_APLIKAN
                order by aplikan.ID_APLIKAN";
        return $this->query($sql, array($id));
    }

}

