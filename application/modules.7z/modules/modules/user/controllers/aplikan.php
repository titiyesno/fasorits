<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class aplikan extends MX_Controller {

    function __construct() {
        parent::__construct();
        $this->load->driver('session');
        $this->load->helper(array('url'));
        $this->load->model('user/model_user');
        $this->load->model('pemesanan/reservasi_model');
    }

    function index() {
        $menu = "hf/menu/menu_pemesan.php";
        $data["submit"] = $this->model_user->cek_jumlahsubmit($this->session->userdata["logged_in"]["id"]);
        $this->template->set_layout('big_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->build("home.php", $data);
    }

    function registrasi() {
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('single_usercontrol');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("register_aplikan.php");
    }

    function me() {
        $data["aplikan"] = $this->model_user->getaplikan($this->session->userdata["logged_in"]["id"]);
        $data['fak'] = $this->model_user->getFakultas($data["aplikan"][0]->JURUSAN_APLIKAN);
        
        $data['fakultas'] = $this->reservasi_model->getFakultas();
        $menu = "hf/menu/menu_pemesan.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('big_end');
        $this->template->title("Profile | Aplikan | Sistem Reservasi Online Asrama ITS");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("viewprofile.php", $data);
    }

    function upload() {
        $aplikan['NRP_APLIKAN'] = addslashes($this->input->post("nrp"));
        $ktp_path = $this->upload_aplikan("ktp", $aplikan['NRP_APLIKAN']);
        $foto_path = $this->upload_aplikan("foto", $aplikan['NRP_APLIKAN']);
        $ktm_path = $this->upload_aplikan("ktm", $aplikan['NRP_APLIKAN']);
        $this->model_user->updatefotoApp($ktm_path, $ktp_path, $foto_path, $aplikan['NRP_APLIKAN']);
        redirect("user/aplikan/me");
    }
    function getFakultas($jurusan){
        $this->model_user->getFakultas($jurusan);
    }
    function createPath($path) {
        if (!file_exists($path)) {
            mkdir($path, 0777, true);
        }
        return true;
    }
    function update()
    {
        $id = $this->session->userdata["logged_in"]["id"];
        $aplikan['NAMA_APLIKAN'] = $this->input->post('nama');
        $aplikan['TEMPAT_LAHIR_APLIKAN'] = $this->input->post('tempat');
        $aplikan['TGL_LAHIR_APLIKAN'] = date("Y-m-d", strtotime(addslashes($this->input->post('ttl_t'))));
        //print_r($aplikan);
        //print_r($this->input->post());
        $aplikan['JENIS_KEL_APLIKAN'] = $this->input->post('jenis_kelamin') == 1 ? "Laki-laki" : "Perempuan";
        $aplikan['AGAMA_APLIKAN'] = $this->input->post('agama');
        $aplikan['ALAMAT_APLIKAN'] = $this->input->post('alamat');
        $aplikan['TELP_APLIKAN'] = $this->input->post('telp');
        $aplikan['JURUSAN_APLIKAN'] = $this->input->post('jurusan');
        $temp = $this->input->post('fakultas');
        $temp1 = $this->reservasi_model->getFakultasID($temp);
        $aplikan['FAKULTAS_APLIKAN'] = $temp1[0]->nama;
        $aplikan['PROGRAM_DITERIMA'] = $this->input->post('programditerima');
        $aplikan['NAMA_ORANGTUA'] = $this->input->post('parrent_name');
        $aplikan['ALAMAT_ORANGTUA'] = $this->input->post('parrent_address');
        $aplikan['TELP_ORANGTUA'] = $this->input->post('parrent_telp');
        $aplikan['PEKERJAAN_ORANTUA'] = $this->input->post('parrent_job');
        $aplikan['PENGHASILAN_ORANGTUA'] = $this->input->post('parrent_income');
        $this->model_user->update($aplikan,$id);
        $this->me();
    }
            function upload_aplikan($name, $nrp) {
        if ($this->createPath(getcwd() . "/content/aplikan/uploads/" . $nrp)) {
            $config['upload_path'] = getcwd() . "/content/aplikan/uploads/" . $nrp;
            $config['allowed_types'] = '*';
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload($name)) {
                $data = array('error' => $this->upload->display_errors());
                echo 'haha';
                return "";
            } else {
                $data = array('upload_data' => $this->upload->data());
                echo 'syalala';
            }

            $newfile = $nrp . "_" . $name . $data['upload_data']["file_ext"];
            if (file_exists(getcwd() . "/content/aplikan/uploads/" . $nrp . "/" . $newfile)) {
                unlink(getcwd() . "/content/aplikan/uploads/" . $nrp . "/" . $newfile);
            }
            rename($data['upload_data']["full_path"], getcwd() . "/content/aplikan/uploads/" . $nrp . "/" . $newfile);
            //===========================================================================================
            // $this->resize_image(getcwd() . "\uploads\\" . $nrp . "\\", $newfile, 100, 100);
            return $nrp . "/" . $newfile;
        }
    }

}
?>


