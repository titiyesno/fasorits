<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class user extends MX_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->driver('session');
        $this->load->model('user/model_user');
        $this->load->driver('session');
        $this->load->library('session');
        $this->load->helper(array('url'));
        $this->load->helper('email');
        $this->load->library('image_lib');
        $this->load->helper("code");
        $this->load->model('pemesanan/kamar_model');
        $this->load->model('pemesanan/reservasi_model');
        $this->load->model('pemesanan/akun_model');
        $this->load->model('pemesanan/aplikan_model');
        //$this->load->helper('ssl');
    }

    function daftarPengawas() {
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('single_usercontrol');
        $this->template->title("Daftar Pengawas");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("register_pengawas.php");
    }

    function daftarPengelola() {
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('single_usercontrol');
        $this->template->title("Daftar Pengelola");
        //$this->template->set_partial("menu",$menu);
        //$this->template->set_partial("footer",$footer);
        $this->template->build("register_pengawas.php");
    }

    function contact() {
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('front_end');
        $this->template->title("Daftar Pengelola");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("contact.php");
    }

    function me() {
        
    }

    function index() {

        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('b');
        $this->template->title("Login Site | ITS Dormitory  Website");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->load->view("login.php");
    }

    function cek_login() {
        $username = addslashes($this->input->post('username'));
        $password = addslashes($this->input->post('password'));
        if (!isset($username) && !isset($password)){ //&& ord($password) == 0 && ord($username) == 0) {
            redirect("user/");
        } else {
            $result = $this->model_user->login($username, $password);
            $session_arr = array();
            $url = "";
            if ($result != null) {

                if ($result[0]->privilege == 'admin') {
                    $url = "pemesanan/admin";
                    $session_arr = array("privilege" => "admin", "id" => $result[0]->id, "nama" => $result[0]->nama);
                } else if ($result[0]->privilege == 'pengawas') {
                    $url = "pemesanan/pengawas";
                    $session_arr = array("privilege" => "pengawas", "id" => $result[0]->id, "nama" => $result[0]->nama);
                } else if ($result[0]->privilege == 'aplikan') {
                    $url = "pemesanan/aplikan";
                    $session_arr = array("privilege" => "aplikan", "id" => $result[0]->id, "nama" => $result[0]->nama);
                }
                $this->session->set_userdata("logged_in", $session_arr);
                if ($result[0]->privilege == "zong") {
                    $this->erorlogin(true);
                } else {

                    //$url = $this->session->userdata('last_url');
                    redirect($url);
                }
            } else {
                $this->erorlogin(TRUE);
            }
        }
    }

    function login() {
        if (isset($this->session->userdata['logged_in']["privilege"])) {
            if ("admin" == $this->session->userdata['logged_in']["privilege"])
                redirect('user/admin/', 'refresh');
            if ("aplikan" == $this->session->userdata['logged_in']["privilege"])
                redirect('user/aplikan/', 'refresh');
            if ("pengawas" == $this->session->userdata['logged_in']["privilege"])
                redirect('user/pengawas/', 'refresh');
        } else
            redirect("user/");
        //$this->checkLogin();
    }

    function erorlogin($flag) {
        ;
        $data = array();
        if ($flag) {
            $data["eror"] = "Username atau Password yang Anda Masukkan Tidak Benar atau Akun Anda Belum Diaktivasi<br/>";
        }
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('b');
        $this->template->title("Login Site | ITS Dormitory  Website");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->load->view("login.php", $data);
    }

    function logout() {
        $this->session->set_userdata('logged_in', NULL);
        redirect("/");
    }

    function registrasi() {
        $periode = $this->reservasi_model->getperiode();
        if (count($periode) == 0)
            redirect("");
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $data['fakultas'] = $this->reservasi_model->getFakultas();
        $this->template->set_layout('front_end');
        $this->template->title("Register");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("register.php", $data);
    }

    function home() {
        $menu = "hf/menu/menu_umum.php";
        $this->template->set_layout('single_usercontrol');
        $this->template->title("Login Page");
        $this->template->set_partial("menu", $menu);
        $this->template->build("login.php");
    }

    function co() {
        $menu = "hf/menu/menu_umum.php";
        $this->template->set_layout('single_usercontrol');
        $this->template->title("Login Page");
        $this->template->set_partial("menu", $menu);
        $this->template->build("co.php");
    }

    function submit() {
        $akun = array();
        $aplikan = array();
        $akun['USERNAME'] = $this->input->post('nrp');
        $akun['PASSWORD'] = $this->input->post('password');
        $akun['PERTANYAAN_AKUN'] = $this->input->post('question');
        $akun['JAWABAN'] = $this->input->post('answer');
        $akun['EMAIL'] = $this->input->post('email');
        $aplikan['NRP_APLIKAN'] = $this->input->post('nrp');
        $aplikan['NAMA_APLIKAN'] = $this->input->post('nama');
        $aplikan['TEMPAT_LAHIR_APLIKAN'] = $this->input->post('tempat');
        $aplikan['TGL_LAHIR_APLIKAN'] = date("Y-m-d", strtotime(addslashes($this->input->post('ttl_t'))));
        //print_r($aplikan);
        //print_r($this->input->post());
        $aplikan['JENIS_KEL_APLIKAN'] = $this->input->post('jenis_kelamin') == 1 ? "Laki-laki" : "Perempuan";
        $aplikan['AGAMA_APLIKAN'] = $this->input->post('agama');
        $aplikan['ALAMAT_APLIKAN'] = $this->input->post('alamat');
        $aplikan['TELP_APLIKAN'] = $this->input->post('telp');
        $aplikan['JURUSAN_APLIKAN'] = $this->input->post('jurusan');
        $temp = $this->input->post('fakultas');
        $temp1 = $this->reservasi_model->getFakultasID($temp);
        $aplikan['FAKULTAS_APLIKAN'] = $temp1[0]->nama;
        $aplikan['PROGRAM_DITERIMA'] = $this->input->post('programditerima');
        $aplikan['NAMA_ORANGTUA'] = $this->input->post('parrent_name');
        $aplikan['ALAMAT_ORANGTUA'] = $this->input->post('parrent_address');
        $aplikan['TELP_ORANGTUA'] = $this->input->post('parrent_telp');
        $aplikan['PEKERJAAN_ORANTUA'] = $this->input->post('parrent_job');
        $aplikan['PENGHASILAN_ORANGTUA'] = $this->input->post('parrent_income');
        $ktp_path = $this->upload_aplikan("ktp", $aplikan['NRP_APLIKAN']);
        $foto_path = $this->upload_aplikan("foto", $aplikan['NRP_APLIKAN']);
        $ktm_path = $this->upload_aplikan("ktm", $aplikan['NRP_APLIKAN']);

        $isi = "Click this Activation  <a href='" . base_url('index.php/user/user/activ/' . $aplikan['NRP_APLIKAN'] . '/' . md5($akun['PASSWORD'])) . "'>Link</a> to Activate your Account or click here : " . base_url('index.php/user/user/activ/' . $aplikan['NRP_APLIKAN'] . '/' . md5($akun['PASSWORD']));
        if (sendEmail($akun['EMAIL'], 'Aktivasi Akun Asrama ITS', $isi)==1) {
            $idn = $this->akun_model->insert($akun);
            if (isset($idn->ID_AKUN) && $idn->ID_AKUN != 0) {
                $aplikan['ID_APLIKAN'] = $idn->ID_AKUN;
                $aplikan['ID_AKUN'] = $idn->ID_AKUN;
                $aplikan['COPY_KTP'] = $ktp_path;
                $aplikan['COPY_KTM'] = $ktm_path;
                $aplikan['COPY_FOTO'] = $foto_path;
                $this->aplikan_model->insert($aplikan);
                $this->session->set_userdata("pesan", "Registrasi Berhasil, Silahkan Login");
                redirect("user/user/afterlogin");
            } else
            $this->erorreg("Mengalami Permasalahan Pengiriman Email, NRP yang anda telah digunakan dalam proses pendaftaran sebelumnya");    
        }
        else {
            $this->erorreg("Mengalami Permasalahan Pengiriman Email, Apakah Email yang anda gunakan Benar? Apabila Sudah Benar, cobalah lain waktu mungkin server sedang sibuk. Gunakan Email Gmail jika masih gagal dalam proses pendaftaran");
            
        }
    }

    function activ($nrp, $noreg) {
        $noreg = addslashes($noreg);
        $nrp = addslashes($nrp);
        $this->model_user->activ($nrp, $noreg);
        redirect("user/login");
    }

    function erorreg($pesan) {
        $data['pesan'] = $pesan;
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('front_end');
        $this->template->title("Register");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("error_login.php", $data);
    }

    function afterlogin() {
        $menu = "hf/menu/menu_umum.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('front_end');
        $this->template->title("Register");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("afterlogin.php");
    }

    function getjurusan($id) {
        $result = $this->reservasi_model->getJurusan($id);

        $html = '<select name="jurusan" class="form-control" required="" id="jurusan">';
        if ($result != null) {
            foreach ($result as $data) {
                $html = $html . '<option>' . $data->nama . '</option>';
            }
        }
        $html.='</select>';
        echo $html;
    }

    function upload_aplikan($name, $nrp) {
        if ($this->createPath(getcwd() . "/content/aplikan/uploads/" . $nrp)) {
            $config['upload_path'] = getcwd() . "/content/aplikan/uploads/" . $nrp;
            $config['allowed_types'] = '*';
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload($name)) {
                $data = array('error' => $this->upload->display_errors());
                echo 'haha';
                //return "";
            } else {
                $data = array('upload_data' => $this->upload->data());
                //  echo 'syalala';
            }
            //print_r($data);
            $newfile = $nrp . "_" . $name . $data['upload_data']["file_ext"];
            rename($data['upload_data']["full_path"], getcwd() . "/content/aplikan/uploads/" . $nrp . "/" . $newfile);
            //===========================================================================================
            // $this->resize_image(getcwd() . "\uploads\\" . $nrp . "\\", $newfile, 100, 100);
            return $nrp . "/" . $newfile;
        }
    }

    public function resize_image($file_path, $name, $width, $height) {
        $this->load->library('image_lib');
        $sour = $file_path . $name;
        $dest = $file_path . "thumbs_" . $name;
        copy($sour, $dest);
        $img_cfg['image_library'] = 'gd2';
        $img_cfg['source_image'] = $sour;
        $img_cfg['maintain_ratio'] = TRUE;
        $config['create_thumb'] = FALSE;
        $img_cfg['new_image'] = $dest;
        $img_cfg['width'] = $width;
        $img_cfg['quality'] = 100;
        $img_cfg['height'] = $height;
        $this->image_lib->initialize($img_cfg);
        $this->image_lib->resize();
    }

    function createPath($path) {
        if (!file_exists($path)) {
            mkdir($path, 0777, true);
        }
        return true;
    }

    public function cari_all_berita() {

        $berita = $this->berita_model->read_all_berita();

        $a = 1;
        $htmlres = '';

        foreach ($berita as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $matches = array();
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" . base_url() . "/static/images/berita/$g->ALAMAT_GAMBAR\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "/index.php/berita/admin/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

    public function cari_berita_by_tanggal() {
        $tanggal = $this->input->post('tanggal');
        $tanggal_hasil = $this->berita_model->cari_by_tanggal($tanggal);
        $a = 1;
        $htmlres = '';
        foreach ($tanggal_hasil as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" . base_url() . "/static/images/berita/$g->ALAMAT_GAMBAR\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "/index.php/berita/admin/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

    public function cari_berita_by_jenis() {
        $jenis = $this->input->post('jenis');
        $jenis_hasil = $this->berita_model->cari_by_jenis($jenis);
        $a = 1;
        $htmlres = '';
        foreach ($jenis_hasil as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" . base_url() . "/static/images/berita/$g->ALAMAT_GAMBAR\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "/index.php/berita/admin/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

    public function cari_berita_by_judul() {
        $judul = $this->input->post('judul');
        $judul_hasil = $this->berita_model->cari_by_judul($judul);
        $a = 1;
        $htmlres = '';
        foreach ($judul_hasil as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" . base_url() . "static/images/berita/$g->ALAMAT_GAMBAR\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "index.php/berita/admin/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

    function sendEmail() {
        $config = Array(
            'protocol' => 'smtp',
//            'smtp_host' => 'ssl://smtp.its.ac.id',
//            'smtp_user' => 'reservasi.asrama@its.ac.id',
//            'smtp_pass' => '123456aa',
//            'smtp_port' => 465,
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_user' => 'asrama.its.2014@gmail.com',
            'smtp_pass' => 'brambang', // change it to yours
            'mailtype' => 'html'
        );
        $config['crlf'] = "\r\n";
        $config['newline'] = "\r\n";
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");

        //$this->email->from("asrama.its.2014@gmail.com", "Reservasi Asrama");
        $this->email->from($config['smtp_user'], "Reservasi Asrama");
        $this->email->to("misbachul09@mhs.if.its.ac.id");

        $this->email->subject('Email Subject');
        $this->email->message('Email Message');

        if ($this->email->send()) {
            //Success email Sent
            echo $this->email->print_debugger();
        } else {
            //Email Failed To Send
            echo $this->email->print_debugger();
        }
    }

    function apa() {
        echo sendEmail("asrama@its.ac.id", 'Aktivasi Akun Asrama ITS', "chek akun berhasil");
/*        $CI = & get_instance();
        $config = Array(
            'protocol' => 'smtp',
            //'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_user' => 'reservasi.asrama@its.ac.id',
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_pass' => '123456789',
            'smtp_port' => 465,
            
            //'smtp_user' => 'asrama.its.2014@gmail.com',
            //           'smtp_pass' => 'brambang', // change it to yours
            'mailtype' => 'html'
        );
        $config['crlf'] = "\r\n";
        $config['newline'] = "\r\n";
        $CI->load->library('email', $config);
        $CI->email->set_newline("\r\n");

        //$this->email->from("asrama.its.2014@gmail.com", "Reservasi Asrama");
        $CI->email->from($config['smtp_user'], "Reservasi Asrama ITS");
        $CI->email->to("misbachul.h@gmail.com");

        $CI->email->subject('Email Subject');
        $CI->email->message('Email Message');

        if ($CI->email->send()) {
            //Success email Sent
            echo $CI->email->print_debugger();
        } else {
            //Email Failed To Send
            echo $CI->email->print_debugger();
        }
*/
    }

}
?>


