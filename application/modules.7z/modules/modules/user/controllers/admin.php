<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class admin extends Admin_Controller {

    function __construct() {
        parent::__construct();
        $this->load->driver('session');
        $this->load->helper(array('url'));
        $this->load->helper('email');
        $this->load->model('user/model_user');
    }

    function sql() {
        $sql = 'select * from akun';
//$result=$this->db->query($sql);
//print_r($result->result());
        echo $sql;
    }

    function index() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $header = "hf/header/header.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->set_partial("header", $header);
        $this->template->build("home.php");
    }
function haha()
{
echo        sendMail('misbachul.h@gmail.com', 'Aktivasi Akun Asrama ITS', 'Test 1234');
}
    function resendEmail($flag) {

$i=0;
        $result = $this->model_user->getUserNonActiv();
        echo count($result) . '<br>';
//if($flag)
		foreach($result as $data){
		echo $data->NRP_APLIKAN."-".$data->EMAIL."<br/>";
            $isi = "Click this Activation  <a href='" . base_url() . 'index.php/user/user/activ/' . $data->NRP_APLIKAN . '/' . md5($data->PASSWORD) . "'>Link</a> to Activate your Account or click here : " . base_url() . 'index.php/user/user/activ/' . $data->NRP_APLIKAN . '/' . md5($data->PASSWORD);
			echo $isi.'<br/><br/>';
//			if(flag==$i)
//echo $data->EMAIL.$isi.$data->NRP_APLIKAN.$data->EMAIL;
//sleep(10);
try {
//	echo sendMail($data->EMAIL,"Aktivasi Akun Asrama ITS", $isi)."-".$data->NRP_APLIKAN."-".$data->EMAIL."<br/>";
//	break;
} catch (Exception $e) {
    echo 'Caught exception: ',  $data->EMAIL, "\n";
}
//echo sendMail($data->EMAIL,"Aktivasi Akun Asrama ITS", $isi)."-".$data->NRP_APLIKAN."-".$data->EMAIL."<br/>";
$i++;
		}
    }

}
?>





