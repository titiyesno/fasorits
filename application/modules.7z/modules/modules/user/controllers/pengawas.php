<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class pengawas extends Monitoring_Controller{
    function __construct() {
        parent::__construct();
        $this->load->driver('session');
        $this->load->helper(array('url'));
        $this->load->model('user/model_user');
    }
    function index() {
        $menu = "hf/menu/menu_pengelola.php";
        $this->template->set_layout('single_usercontrol');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu",$menu);
        $this->template->build("register_aplikan.php");
    }
}
?>

