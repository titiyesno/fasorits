<meta charset="utf-8" />
<meta name="viewport" content="width=device-width" />

<script src="<?php echo base_url() ?>static/js/vendor/jquery.js"></script>
<script src="<?php echo base_url() ?>static/js/foundation/foundation.js"></script>
<script src="<?php echo base_url() ?>static/js/foundation/foundation.reveal.js"></script>
<script src="<?php echo base_url() ?>static/js/jquery.min.js"></script>

<link rel="stylesheet" href="<?php echo base_url() ?>static/pivot/bootstrap.min.css" type="text/css">
<script type="text/javascript" async="" src="<?php echo base_url() ?>static/pivot/c.js"></script>
<script async="" src="<?php echo base_url() ?>static/pivot/analytics.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>static/pivot/subnav.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>static/pivot/accounting.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>static/pivot/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>static/pivot/dataTables.bootstrap.js"></script>

<link rel="stylesheet" href="<?php echo base_url() ?>static/css/normalize.css">
<link rel="stylesheet" href="<?php echo base_url() ?>static/css/foundation.css">
<link rel="stylesheet" href="<?php echo base_url() ?>static/css/styles.css">



<link rel="stylesheet" href="<?php echo base_url() ?>static/css/foundation-datepicker.css">
<script src='<?php echo base_url() ?>static/js/foundation/foundation-datepicker.js'></script>
<link href='<?php echo base_url() ?>static/css/font.css' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="<?php echo base_url() ?>static/css/slidemenu/component.css">
<link rel="stylesheet" href="<?php echo base_url() ?>static/css/slidemenu/icons.css">
<script type="text/javascript" src="<?php echo base_url() ?>static/js/slidemenu/classie.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>static/js/slidemenu/mlpushmenu.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>static/js/slidemenu/modernizr.custom.js"></script>


<a href="#" data-reveal-id="myModal">Click Me For A Modal</a>

<div id="myModal" class="reveal-modal" data-reveal>
  <h2>Awesome. I have it.</h2>
  <p class="lead">Your couch.  It is mine.</p>
  <p>Im a cool paragraph that lives inside of an even cooler modal. Wins</p>
  <a class="close-reveal-modal">&#215;</a>
</div>
<script src="<?php echo base_url() ?>static/js/foundation.min.js"></script>
<script>
    $(document).foundation();
</script>