<div style="background-color: white;" >
    <div class="row" >
        <div  class="shadowborder">
            <div class="large-3 columns">
                &nbsp;
            </div>
            <div class="large-6 columns">
                <span class="label"><h3 class="oxigenfont">Account</h3></span>
                <div class="panel">
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="username" class="oxigenfont right" style="color: black">
                                Username
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" placeholder="Username" id="username" name="username"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="password" class="oxigenfont right" style="color: black">
                                Password
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="password" placeholder="Password" id="password" name="password"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="question" class="oxigenfont right" style="color: black">
                                <span data-tooltip data-options="disable-for-touch:true" class="has-tip" title="Pertanyaan Ini digunakan untuk <br/>membantu pemulihan password ketika anda lupa">Safety Question</span>
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" id="question" placeholder="Question" name="question"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="question" class="oxigenfont right" style="color: black">
                                <span data-tooltip data-options="disable-for-touch:true" class="has-tip" title="Jawaban pada pertanyaan anda diatas">Answer</span>
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" id="answer" placeholder="Answer" name="answer"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="large-3 columns">
                &nbsp;
            </div>
        </div>

    </div>
</div>
<script>
    $(function () {
        window.prettyPrint && prettyPrint();
        $('#dp1').fdatepicker({
            format: 'mm-dd-yyyy'
        });
        $('#dp2').fdatepicker({
            closeButton: true
        });
        $('#dp3').fdatepicker();
        $('#dp3').fdatepicker();
        $('#dp-margin').fdatepicker();
        $('#dpYears').fdatepicker();
        $('#dpMonths').fdatepicker();
        var startDate = new Date(2012, 1, 20);
        var endDate = new Date(2012, 1, 25);
        $('#dp4').fdatepicker()
        .on('changeDate', function (ev) {
            if (ev.date.valueOf() > endDate.valueOf()) {
                $('#alert').show().find('strong').text('The start date can not be greater then the end date');
            } else {
                $('#alert').hide();
                startDate = new Date(ev.date);
                $('#startDate').text($('#dp4').data('date'));
            }
            $('#dp4').fdatepicker('hide');
        });
        $('#dp5').fdatepicker()
        .on('changeDate', function (ev) {
            if (ev.date.valueOf() < startDate.valueOf()) {
                $('#alert').show().find('strong').text('The end date can not be less then the start date');
            } else {
                $('#alert').hide();
                endDate = new Date(ev.date);
                $('#endDate').text($('#dp5').data('date'));
            }
            $('#dp5').fdatepicker('hide');
        });
        // implementation of disabled form fields
        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);
        var checkin = $('#dpd1').fdatepicker({
            onRender: function (date) {
                return date.valueOf() < now.valueOf() ? 'disabled' : '';
            }
        }).on('changeDate', function (ev) {
            if (ev.date.valueOf() > checkout.date.valueOf()) {
                var newDate = new Date(ev.date)
                newDate.setDate(newDate.getDate() + 1);
                checkout.setValue(newDate);
            }
            checkin.hide();
            $('#dpd2')[0].focus();
        }).data('datepicker');
        var checkout = $('#dpd2').fdatepicker({
            onRender: function (date) {
                return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
            }
        }).on('changeDate', function (ev) {
            checkout.hide();
        }).data('datepicker');
    });
</script>
<script type="text/javascript">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-30989810-2']);
    _gaq.push(['_trackPageview']);
    (function () {
        var ga = document.createElement('script');
        ga.type = 'text/javascript';
        ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ga, s);
    })();
</script>