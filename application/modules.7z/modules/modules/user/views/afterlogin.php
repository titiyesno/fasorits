<div class="row" style="min-height: 400px">
<div class="callout callout-info" >
    <h4>Aktivasi Account</h4>
    <p>Registrasi Berhasil, Periksa Email anda untuk mengaktivasi akun yang dibuat</p>
</div>
</div>