<script src="<?php echo base_url() ?>assets/js/plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/js/plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/js/plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url() ?>assets/js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url() ?>assets/js/plugins/colorpicker/bootstrap-colorpicker.min.js" type="text/javascript"></script>
<!-- bootstrap time picker -->
<script src="<?php echo base_url() ?>assets/js/js/plugins/timepicker/bootstrap-timepicker.min.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript">

    function getXMLHTTP() { //fuction to return the xml http object
        var xmlhttp = false;
        try {
            xmlhttp = new XMLHttpRequest();
        }
        catch (e) {
            try {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (e) {
                try {
                    xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
                }
                catch (e1) {
                    xmlhttp = false;
                }
            }
        }

        return xmlhttp;
    }

    function getJurusan(fakid) {
        var strURL = "<?php echo base_url() ?>index.php/user/user/getJurusan/" + fakid;
        var req = getXMLHTTP();

        if (req) {

            req.onreadystatechange = function() {
                if (req.readyState == 4) {
                    // only if "OK"
                    if (req.status == 200) {
                        document.getElementById('divjurusan').innerHTML = req.responseText;
                    } else {
                        alert("There was a problem while using XMLHTTP:\n" + req.statusText);
                    }
                }
            }
            req.open("GET", strURL, true);
            req.send(null);
        }

    }
</script>
<?php
$att = array("role" => "form", "enctype" => "multipart/form-data", "id" => "registrasi-form", "data-toggle" => "validator");
echo form_open("user/user/submit", $att)
?>

<div  class="col-lg-12 col-md-12  col-sm-12 col-xs-12">
    <section class="content-header">
        <center><h1  class="title">
                Form Pendaftaran Asrama ITS
            </h1>
        </center>
    </section>
    <div class="col-md-6 col-sm-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">Account</h3>
            </div><!-- /.box-header -->
            <!-- form start -->

            <div class="box-body">
                <div class="form-group">
                    <label for="nrp" >
                        NRP <small>required</small>
                    </label>
                    <input type="text" placeholder="NRP" class="form-control" id="nrp" name="nrp" pattern='([0-9]){10,10}'  required autocomplete="off" data-placement="top" data-trigger="manual" data-content="NRP is required, must be number, and must be 10 characters"/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="password">
                        Password <small>required</small>
                    </label>
                    <input type="password" class="form-control" placeholder="Password" id="password" name="password" data-minlength="6" required autocomplete="off"/>
                    <div class="help-block">Minimum of 6 characters</div>
                </div>
                <div class="form-group">
                    <label for="email" >
                        Email <small>required</small>
                    </label>
                    <input type="email" class="form-control" placeholder="Email" id="email" name="email" required autocomplete="off" data-content="Email is required"/>
                    <div class="help-block with-errors"></div>
                </div>

            </div>
        </div>
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">In case you forget your ID or Password</h3>
            </div><!-- /.box-header -->
            <!-- form start -->

            <div class="box-body">
                <div class="form-group">
                    <label for="question" >
                        Safety Question <small>required</small>
                    </label>
                    <small>Contoh : Apa nama makanan favorit Ibuku? </small>
                    <input type="text" class="form-control" id="question" placeholder="Question" name="question" required autocomplete="off"/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="answer">
                        Answer <small>required</small>
                    </label>
                    <input type="text" id="answer" placeholder="Answer" class="form-control" name="answer" required autocomplete="off"/>
                    <div class="help-block with-errors"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-sm-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">Informations</h3>
            </div><!-- /.box-header -->
            <!-- form start -->

            <div class="box-body">
                <div class="form-group">
                    <label for="nama" >
                        NAMA <small>required</small>
                    </label>
                    <input class="form-control" type="text" placeholder="Nama" id="nama" name="nama" required autocomplete="off"/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="dp1">
                        Tempat Lahir <small>required</small>
                    </label>
                    <input type="text" name="tempat" class="form-control" placeholder="Tempat Lahir" id="tempat" required autocomplete="off"/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label >
                        Tanggal Lahir <small>required</small> <small>format : dd/mm/yyyy ex:24/03/1995</small>
                    </label>
                    <input type="date" name="ttl_t" class="form-control" data-inputmask="'alias': 'yyyy/mm/dd'" data-mask="">
                    <div class="help-block with-errors"></div>
                </div>

                <div class="form-group">
                    <label for="x1" >
                        Jenis Kelamin <small>required</small>
                    </label>
                    <label class="checkbox-inline">
                        <input id="checkbox1"  name="jenis_kelamin" type="radio" value="1" checked="">Laki-laki
                    </label>
                    <label class="checkbox-inline">
                        <input id="checkbox2" name="jenis_kelamin" type="radio" value="0" >Perempuan
                    </label>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="agama">
                        Agama <small>required</small>
                    </label>
                    <select id="agama" name="agama" class="form-control" required="">
                        <option selected DISABLED>Agama</option>
                        <option>Islam</option>
                        <option>Kristen</option>
                        <option>Protestan</option>
                        <option>Hindu</option>
                        <option>Budha</option>
                        <option>Kong Hu Cu</option>
                        <option>Lainnya</option>
                    </select>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="alamat">
                        Alamat <small>required</small>
                    </label>
                    <textarea placeholder="Alamat" id="alamat" name="alamat" class="form-control" required></textarea>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="telp">
                        Telp <small>required</small>
                    </label>
                    <input type="text" placeholder="Telepon Aplikan" class="form-control" id="telp" name="telp" autocomplete="off" required/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="fakultas">
                        Fakultas <small>required</small>
                    </label>
                    <select name="fakultas" class="form-control" required="" id="fakultas" onChange="getJurusan(this.value)">
                        <option disabled>Pilih Fakultas</option>
                        <?php foreach ($fakultas as $data) { ?>
                            <option value="<?php echo $data->id; ?>"><?php echo $data->nama; ?></option>
                        <?php } ?>
                    </select>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="jurusan">
                        Jurusan <small>required</small>
                    </label>
                    <div  id="divjurusan">
                        <select name="jurusan"  required="" id="jurusan" class="form-control">
                            <option disabled>Pilih Fakultas Dahulu</option>
                        </select>
                    </div>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="programditerima">
                        Program Diterima <small>required</small>
                    </label>
                    <select id="programditerima" class="form-control" name="programditerima">
                        <option selected DISABLED>Program Diterima</option>
                        <option>SNMPTN/Bidik Misi</option>
                        <option>SNMPTN/Reguler</option>
                        <option>SBMPTN/Bidik Misi</option>
                        <option>SBMPTN/Reguler</option>
                        <option>ITK</option>
                        <option>Beasiswa Kemenag</option>
						<option>Afirmasi Dikti</option>
						<option>DIII-Kerjasama</option>
						<option>DIII-PLN</option>
						<option>DIII/Bidik Misi</option>
						<option>DIII/Reguler</option>
						<option>DIV-Teknik Sipil</option>
						<option>DIV-Teknik Sipil Mandiri</option>
						<option>Lanjut Jenjang</option>
                        <option>Kemitraan dan Mandiri</option>
                        <option>UMDESIGN</option>
                        <option>International</option>
			<option>PIKTI</option>
			<option>PAPSI</option>
                    </select>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="parrent_name" >
                        Nama Orangtua <small>required</small>
                    </label>
                    <input type="text" placeholder="Nama Orangtua" class="form-control" id="parrent_name" name="parrent_name" autocomplete="off" required/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="parrent_address">
                        Alamat Orangtua <small>required</small>
                    </label>
                    <textarea class="form-control" placeholder="Alamat Orangtua" id="parrent_address" name="parrent_address" required></textarea>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="parrent_telp">
                        Telp Orangtua <small>required</small>
                    </label>
                    <input type="text" placeholder="Telepon Orangtua" class="form-control" id="parrent_telp" name="parrent_telp" autocomplete="off" required/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="parrent_job">
                        Pekerjaan Orangtua <small>required</small>
                    </label>
                    <input class="form-control" type="text" placeholder="Pekerjaan Orangtua" id="parrent_job" name="parrent_job" autocomplete="off" required/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="parrent_income">
                        Penghasilan Orangtua/Bulan <small>required</small>
                    </label>
                    <input class="form-control" type="text" placeholder="Penghasilan Orangtua"  id="parrent_job" autocomplete="off" name="parrent_income" required/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="ktm">
                        KTM <small>Max Size 500 KB</small>
                    </label>
                    <input type="file" class="form-control"   id="ktm" name="ktm"/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="ktp">
                        KTP <small>Max Size 500 KB</small>
                    </label>
                    <input type="file" class="form-control"  id="ktp" name="ktp"/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="foto" >
                        Foto <small>Max Size 500 KB</small>
                    </label>
                    <input type="file" class="form-control"  id="foto" name="foto"/>
                    <div class="help-block with-errors"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="box box-primary">
            <div class="box-header">

            </div>
            <div class="box-body">
                <input type="checkbox" class="flat-red" required=""/> Saya Menyatakan Bahwa Data yang Saya Isikan adalah Benar dan Saya Bertanggung Jawab dan Bersedia Menerima Sanksi dari ITS Jika Data yang Saya Isikan Tidak Benar
            </div>
            <div class="box-footer">
                <input type="submit" class="btn btn-primary" value="Submit"/>
            </div>
        </div>
    </div>
</div>
<?php echo form_close(); ?>

