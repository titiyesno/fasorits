<div class="container">
    <center><h3 >Contact</h3></center>
    <hr>
    <div class="row">
        <div class="col-sm-4 col-md-4 col-lg-4">
            <div id="body">

                <div class="row">
                    <div class="col-md-12">
Asrama ITS Surabaya<br/>

                KAMPUS ITS SUKOLILO<br/>

                Surabaya 60111<br/>

                Ph. ( 031 ) 592 5965<br/>

                Fax . ( 031 ) 592 5962<br/>

                Email : asrama@its.ac.id<br/>

                Public relation office : Kurnia Ardiyani ( 085648101073 )<br/>

                Administratioe service : Monday – Friday at 08.00 – 16.00 WIB<br/>
                    </div>
                </div>

            </div>
        </div>
        <div class="col-md-8">
            <div style="min-height: 300px">
                
            </div>
        </div>
    </div>
</div>
