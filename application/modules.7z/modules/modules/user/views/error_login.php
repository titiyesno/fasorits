<div class="row" style="min-height: 400px">
<div class="callout callout-danger" >
    <h4>Registrasi Gagal</h4>
    <?php if(isset($pesan)){?>
        <p><?php echo $pesan;?></p>
    <?php } else echo "<p>Registrasi Gagal, silahkan menghubungi Contact Person Asrama untuk informasi lebih lanjut</p>";?>
</div>
</div>
