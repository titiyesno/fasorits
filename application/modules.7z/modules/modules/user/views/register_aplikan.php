<form method="POST" action="aplikan/registrasi" class="custom">
    <div class="row">
        <div  class="large-12 columns shadowborder">
            <div class="large-3 columns">
                &nbsp;
            </div>
            <div class="large-6 columns">
                <span class="label"><h3 class="oxigenfont">Account</h3></span>
                <div class="panel ">
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="username" class="oxigenfont left inline" style="color: black">
                                Username
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" placeholder="Username" id="username" name="username" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="password" class="oxigenfont left inline" style="color: black">
                                Password
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="password" placeholder="Password" id="password" name="password" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="email" class="oxigenfont left inline" style="color: black">
                                Email
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="email" id="answer" placeholder="Email" name="email" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <labelf or="question" class="oxigenfont left inline" style="color: black">
                                <span data-tooltip data-options="disable-for-touch:true" class="has-tip" title="Pertanyaan Ini digunakan untuk <br/>membantu pemulihan password ketika anda lupa">Safety Question</span>
                                </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" id="question" placeholder="Question" name="question" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="answer" class="oxigenfont left inline" style="color: black">
                                <span data-tooltip data-options="disable-for-touch:true" class="has-tip" title="Jawaban pada pertanyaan anda diatas">Answer</span>
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" id="answer" placeholder="Answer" name="answer" required/>
                        </div>
                    </div>
                </div>
                <span class="label"><h3 class="oxigenfont">Profile</h3></span>
                <div class="panel">
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="nrp" class="oxigenfont left inline" style="color: black" required>
                                NRP
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" placeholder="NRP" id="nrp" name="nrp" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="nama" class="oxigenfont left inline" style="color: black">
                                NAMA
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" placeholder="Nama" id="nama" name="nama" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="dp1" class="oxigenfont left inline" style="color: black">
                                TTL 
                            </label>
                        </div>

                        <div class="large-4 columns">
                            <input type="text" name="tempat" placeholder="Tempat Lahir" id="tempat" required/>
                        </div>
                        <div class="large-4 columns">
                            <input type="text" id="dp1" placeholder="Tanggal Lahir" name="tanggal" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="x1" class="oxigenfont left inline" style="color: black">
                                Jenis Kelamin 
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <div class="switch small round">
                                <input id="x" name="jenis_kelamin" type="radio" checked>
                                <label for="x" onclick=""> Laki-laki</label>
                                <input id="x1" name="jenis_kelamin" type="radio">
                                <label for="x1" onclick="">Perempuan </label>
                                <span></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="agama" class="oxigenfont left inline" style="color: black">
                                Agama 
                            </label>
                        </div>
              a          <div class="large-8 columns">
                            <select id="agama" name="agama">
                                <option selected DISABLED>Agama</option>
                                <option>Islam</option>
                                <option>Kristen</option>
                                <option>Protestan</option>
                                <option>Hindu</option>
                                <option>Budha</option>
                                <option>Kong Hu Cu</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="alamat" class="oxigenfont left inline" style="color: black">
                                Alamat
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <textarea placeholder="Alamat" id="alamat" name="alamat" required></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="telp" class="oxigenfont left inline" style="color: black">
                                Telp
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="tel" placeholder="Telepon Aplikan" id="telp" name="telp" required/>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="jurusan" class="oxigenfont left inline" style="color: black">
                                Jurusan
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" placeholder="Jurusan" id="jurusan" name="jurusan" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="fakultas" class="oxigenfont left inline" style="color: black">
                                Fakultas
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" placeholder="Fakultas" id="fakultas" name="fakultas" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="programditerima" class="oxigenfont left inline" style="color: black">
                                Program Diterima
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <select id="programditerima" name="programditerima">
                                <option selected DISABLED>Program Diterima</option>
                                <option>SNMPTN</option>
                                <option>PMDK</option>
                                <option>Kemitraaan</option>
                                <option>Bidik Misi</option>
                                <option>DEPAG</option>
                                <option>International</option>
                            </select>
                        </div>
                    </div>

                    <hr>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="parrent_name" class="oxigenfont left inline" style="color: black">
                                Nama Orangtua
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" placeholder="Telepon Aplikan" id="parrent_name" name="parrent_name" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="parrent_address" class="oxigenfont left inline" style="color: black">
                                Alamat Orangtua
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <textarea placeholder="Alamat Orangtua" id="parrent_address" name="parrent_address" required></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="parrent_telp" class="oxigenfont left inline" style="color: black">
                                Telp Orangtua
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="tel" placeholder="Telepon Orangtua" id="parrent_telp" name="parrent_telp" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="parrent_job" class="oxigenfont left inline" style="color: black">
                                Pekerjaan Orangtua
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="text" placeholder="Pekerjaan Orangtua" id="parrent_job" name="parrent_job" required/>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="ktm" class="oxigenfont left inline" style="color: black">
                                KTM
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="file" size="100" class="small button" placeholder="File KTM" id="ktm" name="ktm" required/>
                        </div>
                    </div>  
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="ktp" class="oxigenfont left inline" style="color: black">
                                KTP
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="file" size="100" class="small button" placeholder="File KTP" id="ktm" name="ktp" required/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-4 columns">
                            <label for="ktp" class="oxigenfont left inline" style="color: black">
                                Foto
                            </label>
                        </div>
                        <div class="large-8 columns">
                            <input type="file" size="100" class="small button" placeholder="File Foto" id="ktm" name="foto" required/>
                        </div>
                    </div>
                </div>
                <input class="button round" type="submit" name="submit_register_aplikan" id="submit_id_aplikan"/>
            </div>
            <div class="large-3 columns">
                &nbsp;
            </div>
        </div>
    </div>
</form>
<script>
    $(function() {
        $('.dp1').fdatepicker()
    });
</script>
