<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class admin extends Admin_Controller {

    private $status_submit = array();

    function __construct() {
        parent::__construct();
        $this->load->driver('session');
        $this->load->helper(array(
            'url'
        ));
        $this->load->model('pemesanan/kamar_model');
        $this->load->model('pemesanan/reservasi_model');
        $this->load->model('pemesanan/akun_model');
        $this->load->model('pemesanan/aplikan_model');
    }

    function bulan_masuk() {
        $bulan = $this->input->post("bulan");
        $codebook = $this->input->post("codebook");
        $this->reservasi_model->bulan_masuk($bulan, $codebook);
        redirect("index.php/pembayaran/admin/pembayaran/" . $codebook);
    }

    // /ini tampilan home reservasi admin
    function index() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $subnav = "admin/subnav.php";
        $data ["reservasi"] = $this->reservasi_model->getallstatus() or null;
        $data ["kamar"] = $this->reservasi_model->getallstatuskamar() or null;
        $data ['periode'] = $this->reservasi_model->getAllPeriode() or null;
        $data ['pendaftaran'] = $this->reservasi_model->getAllPendaftar() or null;
        $data ["periode"] = $this->reservasi_model->getPeride();
        $data ["tahun"] = $this->reservasi_model->gettahunperiode();
		$data["laki"] = $this->kamar_model->getDataAllKamar("Laki-laki");
		$data["perempuan"] = $this->kamar_model->getDataAllKamar("Perempuan");
        $this->template->set_layout('back_end');
        $this->template->title("Register Management | Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("admindboard.php", $data);
    }

    function periode() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $data ["periode"] = $this->reservasi_model->getPeride();
        $data ["tahun"] = $this->reservasi_model->gettahunperiode();
        $this->template->set_layout('back_end');
        $this->template->title("Register Management | Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("admin/setting_periode.php", $data);
    }

    function tambahperiode() {
        $mulai = $this->input->post('mulai');
        $akhir = $this->input->post('akhir');
        $nama = $this->input->post('nama');
        $this->reservasi_model->addperiode($mulai, $akhir, $nama);
        redirect("pemesanan/admin/periode");
    }

    function tahunperiode($tahun) {
        $array = explode("-", $tahun);
        $data ["awal"] = $array [0];
        $data ["akhir"] = $array [1];
        $data ["tahun"] = $this->reservasi_model->gettahunperiode();
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Rekap");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("admin/lihatpemesanan.php", $data);
    }

    public function getsubmitdata($awal, $akhir) {
        $temp1 = $this->reservasi_model->getsubmitperiode($awal, $akhir);
        $data ["submit"] = $this->getPivot($temp1);
        return $data ["submit"];
    }

    public function pendaftar() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $subnav = "admin/subnav.php";
        $this->template->set_layout('back_end');
        $this->template->title("Report Pendaftar Sistem Asrama ITS - Management | Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("pivot/pivot_pendaftar.php");
    }

    public function pemesan() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $subnav = "admin/subnav.php";
        $this->template->set_layout('back_end');
        $this->template->title("Report Pemesan Kamar Sistem Asrama ITS - Management | Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("pivot/pivot_pemesan.php");
    }

    public function pemesan_source() {
        $temp1 = $this->reservasi_model->pemesan();
        $data ["submit"] = $this->getPivot($temp1);
        return $data ["submit"];
    }

    public function pendaftar_source() {
        $temp1 = $this->reservasi_model->pendaftar();
        $data ["submit"] = $this->getPivot($temp1);
        return $data ["submit"];
    }

    function clean($string) {
        //$string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
        //return str_replace(array('\'', '\\', '/', '*'), ' ', $string);
        return preg_replace('/[^A-Za-z0-9\-@ .,]/', '-', $string); // Removes special chars.
    }

    private function getPivot($data) {
        header('Cache-Control: no-cache, must-revalidate');
        header('Content-type: application/json');
        $header = "[[";
        foreach ($data as $value) {
            foreach ($value as $key => $sembarang) {
                $header .= '"' . str_replace("_", " ", strtoupper($key)) . '"';
                break;
            }
            $count = 1;
            foreach ($value as $key => $sembarang) {
                if ($count > 1) {
                    $header .= ',"' . str_replace("_", " ", strtoupper($key)) . '"';
                }
                $count ++;
            }
            $header .= "]";
            break;
        }

        foreach ($data as $value) {
            $header .= ",[";
            foreach ($value as $key => $data) {
                $data = $this->clean($data);
                if ($key == "NRP_APLIKAN") {
                    $header .= '"<a href=\'' . base_url() . 'index.php/pemesanan/admin/lihatsubmit/' . $data . '\'>' . $data . '</a>"';
                } else {
                    $header .= '"' . $data . '"';
                }
                break;
            }
            $count = 1;
            foreach ($value as $key => $data) {
                $data = $this->clean($data);
                if ($count > 1) {
                    if ($key == "NRP_APLIKAN") {
                        $header .= ',"<a href=\'' . base_url() . 'index.php/pemesanan/admin/lihatsubmit/' . $data . '\'>' . $data . '</a>"';
                    } else {
                        $header .= ',"' . $data . '"';
                    }
                }
                $count ++;
            }
            $header .= "]";
        }
        $header .= "]";
        echo $header;
    }

    private function getHeader($data) {
        $array = array();
        foreach ($data as $value) {
            foreach ($value as $key) {
                $key = strtoupper(str_replace("_", " ", $key));
                array_push($array, $key);
            }
            return $array;
        }
    }

    function pendaftaran_rekap() {
        $tahun = $this->reservasi_model->getperiodesekarang();
        $array = explode("-", $tahun [0]->TAHUN);
        $data ["awal"] = $array [0];
        $data ["akhir"] = $array [1];
        $data ["tahun"] = $this->reservasi_model->gettahunperiode();
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Rekap");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("admin/lihatpemesanan.php", $data);
    }

    // pendaftaran
    function registrasi() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Register");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("register.php");
    }

    function submit() {
        $akun ['USERNAME'] = $this->input->post('username');
        $akun ['PASSWORD'] = ($this->input->post('password'));
        $akun ['PERTANYAAN_AKUN'] = ($this->input->post('question'));
        $akun ['JAWABAN'] = ($this->input->post('answer'));
        $akun ['EMAIL'] = ($this->input->post('email'));
        $aplikan ['NRP_APLIKAN'] = ($this->input->post('nrp'));
        $aplikan ['NAMA_APLIKAN'] = ($this->input->post('nama'));
        $aplikan ['TEMPAT_LAHIR_APLIKAN'] = ($this->input->post('tempat'));
        $aplikan ['TGL_LAHIR_APLIKAN'] = ($this->input->post('ttl_t'));
        $aplikan ['JENIS_KEL_APLIKAN'] = ($this->input->post('jenis_kelamin'));
        $aplikan ['AGAMA_APLIKAN'] = ($this->input->post('agama'));
        $aplikan ['ALAMAT_APLIKAN'] = ($this->input->post('alamat'));
        $aplikan ['TELP_APLIKAN'] = ($this->input->post('telp'));
        $aplikan ['JURUSAN_APLIKAN'] = ($this->input->post('jurusan'));
        $aplikan ['FAKULTAS_APLIKAN'] = ($this->input->post('fakultas'));
        $aplikan ['PROGRAM_DITERIMA'] = ($this->input->post('programditerima'));
        $aplikan ['NAMA_ORANGTUA'] = ($this->input->post('parrent_name'));
        $aplikan ['ALAMAT_ORANGTUA'] = ($this->input->post('parrent_address'));
        $aplikan ['TELP_ORANGTUA'] = ($this->input->post('parrent_telp'));
        $aplikan ['PEKERJAAN_ORANTUA'] = ($this->input->post('parrent_job'));
        $ktp_path = $this->upload_aplikan("ktp", $aplikan ['NRP_APLIKAN']);
        $foto_path = $this->upload_aplikan("foto", $aplikan ['NRP_APLIKAN']);
        $ktm_path = $this->upload_aplikan("ktm", $aplikan ['NRP_APLIKAN']);
        $idn = $this->akun_model->insert($akun);
        if (isset($idn->ID_AKUN) && $idn->ID_AKUN != 0) {
            $aplikan ['ID_APLIKAN'] = $idn->ID_AKUN;
            $aplikan ['ID_AKUN'] = $idn->ID_AKUN;
            $aplikan ['COPY_KTP'] = $ktp_path;
            $aplikan ['COPY_KTM'] = $ktm_path;
            $aplikan ['COPY_FOTO'] = $foto_path;
            $this->aplikan_model->insert($aplikan);
            $this->session->set_userdata("pendaftaran", $aplikan);
            redirect("pemesanan/pemesan/pilih_kamar"); // $this->pilih_kamar();
        } else {
            $this->registrasi();
        }
    }

    function upload_aplikan($name, $nrp) {
        if ($this->createPath(getcwd() . "\uploads\\" . $nrp)) {
            $config ['upload_path'] = getcwd() . "\uploads\\" . $nrp;
            $config ['allowed_types'] = 'gif|jpg|png';
            $config ['max_size'] = '10000';
            $config ['max_width'] = '1024';
            $config ['max_height'] = '768';
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload($name)) {
                $data = array(
                    'error' => $this->upload->display_errors()
                );
            } else {
                $data = array(
                    'upload_data' => $this->upload->data()
                );
            }
            $newfile = $nrp . "_" . $name . $data ['upload_data'] ["file_ext"];
            rename($data ['upload_data'] ["full_path"], getcwd() . "\uploads\\" . $nrp . "\\" . $newfile);
            return $nrp . "\\" . $newfile;
        }
    }

    function createPath($path) {
        if (!file_exists($path)) {
            mkdir($path, 0777, true);
        }
        return true;
    }

    function pilihjeniskamar() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $data ['kamar'] = $this->kamar_model->getKamar();
        $data ['gedung'] = $this->kamar_model->getGedung();
        $data ['jenis_kamar'] = $this->kamar_model->getJenisKamar();
        $data ['lantai'] = $this->kamar_model->getLantai();
        $this->template->set_layout('back_end');
        $this->template->title("Pilih Kamar | ITS Student Dormmitory");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("pilihjeniskamar.php", $data);
    }

    function pilihkamar() {
        if (!isset($this->session->userdata ['jenis_kamar'] ['id_jenis_kamar'])) {
            $this->pilihjeniskamar();
        }
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $data ['kamar'] = $this->reservasi_model->getkamarbyjeniskamar($this->session->userdata ['jenis_kamar'] ['id_jenis_kamar']);
        $this->template->set_layout('back_end');
        $this->template->title("Pilih Kamar | ITS Student Dormmitory");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("pilihkamar.php", $data);
    }

    function formpilihjeniskamar() {
        $data ['id_jenis_kamar'] = $this->input->post('pilih');
        $data ['pembayaran'] = $this->input->post('pembayaran');
        $this->session->set_userdata("jenis_kamar", $data);
        $this->pilihkamar();
    }

    function formpilihkamar($id_kamar) {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $data ['booking_code'] = base_convert(2981, 10, 19);
        $data ['booking_code'] = strtoupper($this->reservasi_model->zeropad($data ['booking_code']));
        $this->template->set_layout('back_end');
        $this->template->title("Pilih Kamar | ITS Student Dormmitory");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("bookingcode.php", $data);
    }

    function lihatsubmit($nrp) {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $subnav = "admin/subnav.php";
        $data ["pesan"] = $this->kamar_model->getsumit() or null;
        $data ["aplikan"] = $this->reservasi_model->getdataaplikanbycode($nrp);
        $data ["available"] = $this->kamar_model->AvailabilityRoom($data ["aplikan"] [0]->ID_KAMAR);
        $code = $data ["aplikan"];
        $data ["code_booking"] = $code [0]->CODE_BOOKING or null;
        $this->template->set_layout('back_end');
        $this->template->title("Rekap");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("viewaplikan.php", $data);
    }

    function reject($id_submit) {
        $state = -2;
        $id_pengelola = $this->session->userdata ["logged_in"] ["id"];
        $this->reservasi_model->ubahstatussubmit($state, $id_submit, $id_pengelola);
        redirect("pembayaran/admin/pivot_pembayaran");
    }
	function reject2($id_submit) {
        $state = -2;
        $id_pengelola = $this->session->userdata ["logged_in"] ["id"];
        $this->reservasi_model->ubahstatussubmit($state, $id_submit, $id_pengelola);
        redirect("pemesanan/admin/pemesanan");
    }
    function approval() {
        $nrp = $this->input->post("nrp");
        $pindah_pagu = $this->input->post("pindah_pagu");
        $data ["aplikan"] = $this->reservasi_model->getdataaplikanbycode($nrp);
        $id_submit = $this->input->post("id_submit");
        $state = 0;
        $email = $this->aplikan_model->getEmail($nrp);
        if ($pindah_pagu == 1) {
            $this->reservasi_model->ubahpagu($id_submit);
        }
        $approve = $this->input->post("approve");
        $reject = $this->input->post("reject");
		echo $approve;
		echo reject;
        $id_pengelola = $this->session->userdata ["logged_in"] ["id"];
        if (isset($approve) || $approve=='approve') {
            $state = 2;
        } else {
            $state = -2;
        }
        $data_kamar = $this->kamar_model->AvailabilityRoom($data["aplikan"][0]->ID_KAMAR);
        if ($data_kamar[0]->AVAILABLE > 0) {
            $this->reservasi_model->ubahstatussubmit($state, $id_submit, $id_pengelola);
            $this->load->helper('email');
            sendEmail($email [0]->EMAIL, 'Pengumuman PENERIMAAN', "Selamat Anda Dinyatakan Diterima di Asrama ITS, Loginlah ke Sistem Asrama Untuk Pengumuman Lebih Lanjut");

            redirect("pemesanan/admin/pemesan", "refresh");
        } else {
            redirect("pemesanan/admin/lihatsubmit/" . $data ["aplikan"][0]->NRP_APLIKAN);
        }
    }

    public function getPemesananXLS() {
        $data = $this->reservasi_model->pendaftar();
        $this->generateCSV($data, "Pemesanan Kamar Asrama");
    }

    public function generateCSV($data, $nama) {
        header("Content-type: application/octet-stream");
        header("Content-Disposition: attachment; filename=" . $nama . "-asramaITS.xls");
        header("Pragma: no-cache");
        header("Expires: 0");

        $header = "";
        foreach ($data as $value) {
            foreach ($value as $key => $sembarang) {
                $header .= $key;
                break;
            }
            $count = 1;
            foreach ($value as $key => $sembarang) {
                if ($count > 1) {
                    $header .= '	' . $key;
                }
                $count ++;
            }
            $header .= "\n";
            break;
        }

        foreach ($data as $value) {
            foreach ($value as $key => $data) {
                $header .= $data;
                break;
            }
            $count = 1;
            foreach ($value as $key => $data) {
                if ($count > 1) {
                    if ($key == "SITE_ID" && $this->isAdmin()) {
                        $header .= '	' . $data;
                    } else {
                        $header .= '	' . $data;
                    }
                }
                $count ++;
            }
            $header .= "\n";
        }
        echo $header;
    }

}
