<script language="javascript" type="text/javascript">
    function getXMLHTTP() { //fuction to return the xml http object
        var xmlhttp = false;
        try {
            xmlhttp = new XMLHttpRequest();
        }
        catch (e) {
            try {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (e) {
                try {
                    xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
                }
                catch (e1) {
                    xmlhttp = false;
                }
            }
        }
        return xmlhttp;
    }
    function getDataFromPeriode(idPeriode) {
        var strURL = "<?php echo base_url() ?>index.php/user/user/getJurusan/" + fakid;
        var req = getXMLHTTP();

        if (req) {

            req.onreadystatechange = function() {
                if (req.readyState == 4) {
                    if (req.status == 200) {
                        document.getElementById('divjurusan').innerHTML = req.responseText;
                    } else {
                        alert("There was a problem while using XMLHTTP:\n" + req.statusText);
                    }
                }
            }
            req.open("GET", strURL, true);
            req.send(null);
        }

    }
</script>
<section class="content-header">
    <h1>
        Statistika Reservasi
        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
    </ol>
</section>
<div class="content">
    <div class="row">
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <a style="color: whitesmoke" href="<?php echo base_url(); ?>index.php/pemesanan/admin/pendaftar"><?php echo count($pendaftaran); ?></a>
                    </h3>
                    <p>
                        Pendaftar
                    </p>
                </div>
                <div class="icon">
                    <i class="ion ion-android-data"></i>
                </div>
                <a href="<?php echo base_url() ?>index.php/pemesanan/admin/getPemesananXLS" class="small-box-footer">
                    Download Data <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
                <div class="inner">
                    <h3>
                        <a style="color: whitesmoke" href="<?php echo base_url(); ?>index.php/pemesanan/admin/pemesan"><?php
                            $i = 0;
                            foreach ($reservasi as $data) {
                                if ($data->STATUS_SUBMIT == "daftar") {
                                    echo $data->total;
                                    $i = 1;
                                    break;
                                }
                            }
                            if ($i == 0)
                                echo "0";
                            ?></a>
                    </h3>
                    <p>
                        Pemesan Kamar
                    </p>
                </div>
                <div class="icon">
                    <i class="ion ion-document"></i>
                </div>
                <a href="<?php echo base_url() ?>index.php/pemesanan/admin/getPemesananXLS" class="small-box-footer">
                    Download Data <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3>
                        <a style="color: whitesmoke" href="<?php echo base_url(); ?>index.php/pembayaran/admin/pivot_pembayaran"><?php
                            $i = 0;
                            foreach ($reservasi as $data) {
                                if ($data->STATUS_SUBMIT == "diterima") {
                                    echo $data->total;
                                    $i = 1;
                                    break;
                                }
                            }
                            if ($i == 0)
                                echo "0";
                            ?></a>
                    </h3>
                    <p>
                        Pembayaran
                    </p>
                </div>
                <div class="icon">
                    <i class="ion ion-ios7-contact"></i>
                </div>
                <a href="<?php echo base_url() ?>index.php/pembayaran/admin/getXLS" class="small-box-footer">
                    Download Data <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
                <div class="inner">
                    <h3>
                        <a style="color: whitesmoke" href="<?php echo base_url(); ?>index.php/penghuni/admin/penghuni_asrama"><?php
                            $i = 0;
                            foreach ($reservasi as $data) {
                                if ($data->STATUS_SUBMIT == "penghuni") {
                                    echo $data->total;
                                    $i = 1;
                                    break;
                                }
                            }
                            if ($i == 0)
                                echo "0";
                            ?></a>
                    </h3>
                    <p>
                        Penghuni
                    </p>
                </div>
                <div class="icon">
                    <i class="ion ion-person"></i>
                </div>
                <a href="<?php echo base_url() ?>index.php/penghuni/admin/getXLS" class="small-box-footer">
                    Download Data <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div><!-- ./col -->
    </div><!-- /.row -->
<div class="row">
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <a style="color: whitesmoke" href="<?php echo base_url(); ?>index.php/pemesanan/admin/pendaftar"><?php echo $kamar[0]->AVAILABLE; ?> Orang</a>
                    </h3>
                    <p>
			<?php 
                       echo  $kamar[0]->nama_jenis_kamar;
			?>
                    </p>
                    <p>
                         <?php 
                            foreach ($laki as $y){
                            if($y->nama_jenis_kamar== $kamar[0]->nama_jenis_kamar)
                                echo "Laki-laki=". $y->_AVAILABLE;
                            }
                            foreach ($perempuan as $y){
                            if($y->nama_jenis_kamar== $kamar[0]->nama_jenis_kamar)
                                echo "<br/>Perempuan=". $y->_AVAILABLE;
                            }
                         ?>
                    </p>
                </div>
                <div class="icon">
                    <i class="ion ion-android-data"></i>
                </div>
                <a href="<?php echo base_url() ?>index.php/pemesanan/admin/getPemesananXLS" class="small-box-footer">
                    Download Data <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
                <div class="inner">
                    <h3>
                        <a style="color: whitesmoke" href="<?php echo base_url(); ?>index.php/pemesanan/admin/pemesan"><?php echo $kamar[1]->AVAILABLE; ?> Orang</a>
                    </h3>
                    <p>
                        <?php echo $kamar[1]->nama_jenis_kamar; ?>
                    </p>
                    <p>
                         <?php 
                            foreach ($laki as $y){
                            if($y->nama_jenis_kamar== $kamar[1]->nama_jenis_kamar)
                                echo "Laki-laki=". $y->_AVAILABLE;
                            }
                             foreach ($perempuan as $y){
                            if($y->nama_jenis_kamar== $kamar[1]->nama_jenis_kamar)
                                echo "<br/>Perempuan=". $y->_AVAILABLE;
                            }
                            ?>
                    </p>
                </div>
                <div class="icon">
                    <i class="ion ion-document"></i>
                </div>
                <a href="<?php echo base_url() ?>index.php/pemesanan/admin/getPemesananXLS" class="small-box-footer">
                    Download Data <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3>
                        <a style="color: whitesmoke" href="<?php echo base_url(); ?>index.php/pembayaran/admin/pivot_pembayaran"><?php echo $kamar[2]->AVAILABLE;
                            ?> Orang</a>
                    </h3>
                    <p>
                        <?php echo $kamar[2]->nama_jenis_kamar; ?>
                    </p>
                    <p>
                         <?php 
                            foreach ($laki as $y){
                            if($y->nama_jenis_kamar== $kamar[2]->nama_jenis_kamar)
                                echo "Laki-laki=". $y->_AVAILABLE;
                            }
                             foreach ($perempuan as $y){
                            if($y->nama_jenis_kamar== $kamar[2]->nama_jenis_kamar)
                                echo "<br/>Perempuan=". $y->_AVAILABLE;
                            }
                            ?>
                    </p>
                </div>
                <div class="icon">
                    <i class="ion ion-ios7-contact"></i>
                </div>
                <a href="<?php echo base_url() ?>index.php/pembayaran/admin/getXLS" class="small-box-footer">
                    Download Data <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
                <div class="inner">
                    <h3>
                        <a style="color: whitesmoke" href="<?php echo base_url(); ?>index.php/penghuni/admin/penghuni_asrama"><?php echo $kamar[3]->AVAILABLE;       ?> Orang</a>
                    </h3>
                    <p>
                         <?php echo $kamar[3]->nama_jenis_kamar; ?>
                    </p>
                    <p>
                         <?php 
                            foreach ($laki as $y){
                            if($y->nama_jenis_kamar== $kamar[3]->nama_jenis_kamar)
                                echo "Laki-laki=". $y->_AVAILABLE;
                            }
                            
                             foreach ($perempuan as $y){
                            if($y->nama_jenis_kamar== $kamar[3]->nama_jenis_kamar)
                                echo "<br/>Perempuan=". $y->_AVAILABLE;
                            }
                            ?>
                    </p>
                </div>
                <div class="icon">
                    <i class="ion ion-person"></i>
                </div>
                <a href="<?php echo base_url() ?>index.php/penghuni/admin/getXLS" class="small-box-footer">
                    Download Data <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div><!-- ./col -->
    </div><!-- /.row -->
    <!-- top row -->
    <div class="row">
        <div class="col-xs-12 connectedSortable">
            <div class="box box-danger">
                <div class="box-header">
                    <h3 class="box-title">Statistika Pendaftaran</h3>
                </div>
                <div class="box-body">
                    <table style="width: 100%" class="table-bordered">
                        <thead>
                            <tr>   
                                <th style="width: 10%"><center>#</center></th>
                        <th style="width: 20%"><center>Tanggal Mulai</center></th>
                        <th style="width: 20%"><center>Tanggal Selesai</center></th>
                        <th style="width: 40%"><center>Nama Periode</center></th>
                        <th style="width: 10%"><center>Jumlah</center></th>
                        <tr/>
                        </thead>
                        <tbody>
                            <?php
                            $d = 1;
                            foreach ($periode as $data) {
                                ?>
                                <tr>
                                    <td ><center><?php echo $d; ?></center></th>
                            <td ><center><?php echo $data->TANGGAL_MULAI; ?></center></td>
                            <td ><center><?php echo $data->TANGGAL_SELESAI; ?></center></td>
                            <td ><center><?php echo $data->NAMA_PERIODE; ?></center></td>
                            <td ><center><?php echo $data->COUNT; ?></center></td>
                            </tr>
                            <?php
                            $d++;
                        }
                        ?>
                        </tbody>
                    </table>

                </div><!-- /.box-body -->
            </div>

        </div><!-- /.col -->
    </div>

</div>


z