<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class reservasi_model extends CI_model {

    function zeropad($num) {
        return (strlen($num) >= 7) ? $num : $this->zeropad("0" . $num);
    }

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    function bulan_masuk($bulan, $codebook) {
        $data = array(
            'BULAN_MASUK' => $bulan
        );
        echo $bulan;
        $this->db->where('CODE_BOOKING', $codebook);
        $this->db->update('submit', $data);
    }

    public function getid($username) {
        $sql = "select ID_AKUN from akun where USERNAME='$username'";
        $query = $this->db->query($sql);
        return $query->result();
    }

    public function insertSubmit($data) {
        $insert = $this->db->insert('submit', $data);
        return $insert;
    }

    public function insert($data) {
        $result = $this->getid($data['USERNAME']);
        if (count($result) == 0) {
            $this->db->insert('akun', $data);
            $result = $this->getid($data['USERNAME']);
            return $result[0];
        }
        return 0;
    }

    public function getIdSubmitMax() {
        $sql = "select ID_SUBMIT as ID from SUBMIT order by ID_SUBMIT desc limit 1";
        return $this->query($sql);
    }

    public function addperiode($mulai, $akhir, $nama) {
        $data = array(
            'TANGGAL_MULAI' => $mulai,
            'TANGGAL_SELESAI' => $akhir,
            'NAMA_PERIODE' => $nama
        );
        $this->db->insert("periode", $data);
    }

    public function getPeride() {
        $sql = 'select DATE_FORMAT(periode.TANGGAL_MULAI,"%d %M %Y") as TANGGAL_MULAI, 
                DATE_FORMAT(periode.TANGGAL_SELESAI,"%d %M %Y") as TANGGAL_SELESAI, 
                periode.NAMA_PERIODE, count(submit.ID_SUBMIT) as "COUNT"
                from 
                periode left join submit on (periode.ID_PERIODE=submit.ID_PERIODE)
                group by periode.ID_PERIODE';
        return $this->query($sql);
    }

    public function gettahunperiode() {
        $sql = 'select concat(extract(year from periode.TANGGAL_MULAI),"-",extract(year from periode.TANGGAL_SELESAI)) as "TAHUN" from periode
                order by periode.TANGGAL_MULAI asc, periode.TANGGAL_SELESAI asc';
        return $this->query($sql);
    }

    function getperiodesekarang() {
        $sql = 'select concat(extract(year from periode.TANGGAL_MULAI),"-",extract(year from periode.TANGGAL_SELESAI)) as "TAHUN" 
                from periode
                where now() between periode.TANGGAL_MULAI and periode.TANGGAL_SELESAI
                order by periode.TANGGAL_MULAI asc, periode.TANGGAL_SELESAI asc';
        return $this->query($sql);
    }

    function getperiode() {
        $sql = "select periode.ID_PERIODE from periode where periode.TANGGAL_MULAI <= now() and periode.TANGGAL_SELESAI>=now() limit 1";
        return $this->query($sql);
    }
    function getCodePeriode(){
        $sql = "select RIGHT(extract(YEAR from periode.TANGGAL_MULAI),2) as TAHUN from periode where periode.TANGGAL_MULAI <= now() and periode.TANGGAL_SELESAI>=now() limit 1";
        return $this->query($sql);
    }

    public function getsubmitperiode($mulai, $akhir) {
        $sql = 'select 
                DATEOR_FMAT(submit.TANGGAL_SUBMIT,"%d %M %Y") as "TANGGAL_SUBMIT", submit.CODE_BOOKING, submit.STATUS_SUBMIT, jenis_submit.NAMA_JENIS_SUBMIT, MONTHNAME(STR_TO_DATE(submit.BULAN_MASUK,"%m")) as "BULAN_MASUK",
                aplikan.NRP_APLIKAN, aplikan.PROGRAM_DITERIMA, aplikan.PENGHASILAN_ORANGTUA,
                kamar.NOMER_KAMAR, jenis_kamar.nama_jenis_kamar,gedung.NAMA_GEDUNG
                from 
                periode inner join submit on (periode.ID_PERIODE=submit.ID_PERIODE)
                left join aplikan on (aplikan.ID_APLIKAN=submit.ID_APLIKAN)
                left join kamar on (kamar.ID_KAMAR=submit.ID_KAMAR) 
                left join jenis_kamar on (kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar)
                left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG)
                right join jenis_submit on (submit.ID_JENIS_SUMBIT=jenis_submit.ID_JENIS_SUMBIT)
                where 
                EXTRACT(year FROM periode.TANGGAL_MULAI)="' . $mulai . '" and 
                EXTRACT(year FROM periode.TANGGAL_SELESAI)="' . $akhir . '" and 
                submit.STATUS_SUBMIT = "daftar"
                group by aplikan.NRP_APLIKAN
                order by submit.TANGGAL_SUBMIT desc';
        return $this->query($sql);
    }

    public function pemesan() {
        $sql = 'select payment_status.PROGRAM_DITERIMA, aplikan.NAMA_APLIKAN, aplikan.AGAMA_APLIKAN, payment_status.ALAMAT_APLIKAN, payment_status.NRP_APLIKAN, payment_status.nama_jenis_kamar, payment_status.CODE_BOOKING, payment_status.BULAN_MASUK, submit.TANGGAL_SUBMIT, aplikan.TELP_APLIKAN from payment_status left join aplikan on (aplikan.ID_APLIKAN=payment_status.ID_APLIKAN) left join submit on (payment_status.ID_SUBMIT=submit.ID_SUBMIT) where payment_status.STATUS_SUBMIT="daftar"';
        return $this->query($sql);
    }

    public function pendaftar() {
        $sql = 'select aplikan.NAMA_APLIKAN, aplikan.NRP_APLIKAN, '
                . 'aplikan.JURUSAN_APLIKAN, '
		. 'aplikan.NAMA_APLIKAN, aplikan.PROGRAM_DITERIMA,aplikan.FAKULTAS_APLIKAN, aplikan.JENIS_KEL_APLIKAN, aplikan.PENGHASILAN_ORANGTUA,'

                . 'akun.EMAIL, aplikan.STATUS, aplikan.TELP_APLIKAN'
                . ' from aplikan left join submit on (submit.ID_APLIKAN=aplikan.ID_APLIKAN) '
                . 'left join akun on (akun.ID_AKUN=aplikan.ID_AKUN) '
               . 'where aplikan.ID_APLIKAN not in '
                . '(select submit.ID_APLIKAN from submit, current_periode where submit.ID_PERIODE=current_periode.ID_PERIODE)';
        
        
        return $this->query($sql);
    }

    public function getkamarbyjeniskamar($id) {
        $sql = 'select kamar.NOMER_KAMAR, kamar.LANTAI, kamar.KETERANGAN_KAMAR, jenis_kamar.nama_jenis_kamar, 
                jenis_kamar.quota_kamar, jenis_kamar.harga_kamar, jenis_kamar.keterangan, gedung.NAMA_GEDUNG, 
                gedung.KETERANGAN_GEDUNG, gedung.JENIS_GEDUNG, available_room.AVAILABLE
                from 
                kamar left join jenis_kamar on (kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar)
                left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG) left join available_room on (available_room.ID_KAMAR=kamar.ID_KAMAR)
                where jenis_kamar.id_jenis_kamar=' . $id . '
                order by kamar.LANTAI
                gtoup by gedung.NAMA_GEDUNG
                ';
        return $this->query($sql);
    }

    function getdataaplikanbycode($code_booking) {
        $sql = "select *, DATE_FORMAT(aplikan.TGL_LAHIR_APLIKAN,'%d %M %Y') as 'TGL_LAHIR_APLIKAN'
                from 
                aplikan left join submit on (aplikan.ID_APLIKAN=submit.ID_APLIKAN)
                left join kamar on (submit.ID_KAMAR=kamar.ID_KAMAR)
                left join jenis_kamar on (kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar)
                left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG)
                where aplikan.NRP_APLIKAN=?";
//	echo $sql.$code_booking;
        return $this->query($sql, array($code_booking));
    }

    function ubahstatussubmit($status, $id_submit, $id_pengelola) {
        $sql = "call update_submit(?,?,?);";
		echo $sql;
        $this->query($sql, array($status, $id_submit, $id_pengelola));
    }

    function ubahpagu($code_booking) {
        $data = array(
            'PINDAH_PAGU' => 1
        );
        $this->db->where('ID_SUBMIT', $code_booking);
        $this->db->update('SUBMIT', $data);
    }

    function getFakultas() {
        $sql = "select * from fakultas";
        return $this->query($sql);
    }

    function getJurusan($id) {
        if (is_int($id * 1)) {
            $sql = "select DISTINCT jurusan.* from fakultas left join jurusan on (jurusan.id_fak=fakultas.id)
                    where fakultas.id=?";
            return $this->query($sql, array($id));
        } else {
            return null;
        }
    }

    function getFakultasID($id) {
        $sql = "select nama from fakultas where id=?";
        return $this->query($sql, array($id));
    }

    function getstatussubmitnow($id) {
        $sql = "select submit.* from submit, periode where submit.TANGGAL_SUBMIT BETWEEN periode.TANGGAL_MULAI and periode.TANGGAL_SELESAI and now() between periode.TANGGAL_MULAI and periode.TANGGAL_SELESAI and submit.ID_APLIKAN=?";
        return $this->query($sql, array($id));
    }

    function getstatus($id) {
        $sql = "SELECT p . * , kamar.NOMER_KAMAR, gedung.NAMA_GEDUNG FROM  `payment_status` p LEFT JOIN submit ON ( p.ID_SUBMIT = submit.ID_SUBMIT )  LEFT JOIN kamar ON ( kamar.ID_KAMAR = submit.ID_KAMAR )  LEFT JOIN gedung ON ( gedung.ID_GEDUNG = kamar.ID_GEDUNG )  where p.ID_APLIKAN=?";
        return $this->query($sql, array($id));
    }

    function getallstatus() {
        $sql = 'select COUNT(payment_status.STATUS_SUBMIT) as "total", payment_status.STATUS_SUBMIT from payment_status group by payment_status.STATUS_SUBMIT';
        return $this->query($sql);
    }

    function angsuran($param) {
        $sql = 'select submit.ID_SUBMIT, aplikan.NRP_APLIKAN, jenis_kamar.nama_jenis_kamar, '
                . 'submit.ANGSURAN, submit.BULAN_MASUK, submit.ID_APLIKAN, jenis_kamar.harga_kamar, '
                . '(EXTRACT(MONTH FROM periode.TANGGAL_SELESAI)+12- submit.BULAN_MASUK) as "MASA_BULAN", '
                . '(jenis_kamar.harga_kamar *(EXTRACT(MONTH FROM periode.TANGGAL_SELESAI)+12- submit.BULAN_MASUK)) as "TOTAL", '
                . '(jenis_kamar.harga_kamar *(EXTRACT(MONTH FROM periode.TANGGAL_SELESAI)+12- submit.BULAN_MASUK))/ submit.ANGSURAN as  "NILAI_ANGSURAN" '
                . 'from submit left join kamar on (submit.ID_KAMAR=kamar.ID_KAMAR) '
                . 'left join jenis_kamar on (jenis_kamar.id_jenis_kamar=kamar.ID_JENIS_KAMAR) '
                . 'left join periode on (periode.ID_PERIODE=submit.ID_PERIODE) '
                . 'left join aplikan on (aplikan.ID_APLIKAN=submit.ID_APLIKAN) '
                . 'where submit.ID_APLIKAN =? ';
        return $this->query($sql, array($param));
    }

    function getallstatuskamar() {
        $sql = "select * from view_jenis_kamar";
        return $this->query($sql);
    }

    /**
     * 
     * @return boolean yang menerangkan bahwa 
     */
    function isGetWaitForRegistration() {
        $sql = "select date_format(periode.TANGGAL_MULAI,'%d %M %Y') as TANGGAL_MULAI, "
                . "date_format(periode.TANGGAL_SELESAI,'%d %M %Y') as TANGGAL_SELESAI, "
                . "periode.NAMA_PERIODE from periode where now() < periode.TANGGAL_MULAI"
                . "";
        return $this->query($sql);
        
    }

    function getAllPeriode() {
        $sql = "select * from periode ";
        return $this->query($sql);
    }

    public function getAllPendaftar() {
        $sql = "select aplikan.NAMA_APLIKAN, aplikan.NRP_APLIKAN, "
                . "aplikan.TGL_LAHIR_APLIKAN, aplikan.TEMPAT_LAHIR_APLIKAN, "
                . "aplikan.FAKULTAS_APLIKAN, aplikan.JURUSAN_APLIKAN, "
                . "aplikan.PROGRAM_DITERIMA, aplikan.JENIS_KEL_APLIKAN, "
                . "aplikan.AGAMA_APLIKAN, aplikan.ALAMAT_APLIKAN, "
                . "aplikan.TELP_APLIKAN, aplikan.NAMA_ORANGTUA, "
                . "aplikan.ALAMAT_ORANGTUA, aplikan.TELP_ORANGTUA, "
                . "aplikan.PEKERJAAN_ORANTUA, aplikan.PENGHASILAN_ORANGTUA, "
                . "akun.USERNAME, akun.EMAIL "
                . "from aplikan "
                //. "left join submit "
                //. "on (submit.ID_APLIKAN=aplikan.ID_APLIKAN) "
                . "left join akun on (akun.ID_AKUN=aplikan.ID_AKUN) "
                . "where aplikan.ID_APLIKAN not in "
                . "(select submit.ID_APLIKAN "
                . "from submit, current_periode "
                . "where submit.ID_PERIODE=current_periode.ID_PERIODE) ";
        //echo $sql;
        return $this->query($sql);
    }

}
