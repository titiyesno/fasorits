<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php $data = $aplikan->result(); { ?>
        <table>
            <tr>
                <td> NRP </td>
                <td><?php echo $data[0]->NRP_APLIKAN ?>"/></td>
            </tr>
            <tr>
                <td>Nama </td>
                <td><?php echo $data[0]->NAMA_APLIKAN ?></td>
            </tr>
            <tr>
                <td>Tempat Lahir </td>
                <td><?php echo $data[0]->TEMPAT_LAHIR_APLIKAN ?></td>
            </tr>
            <tr>
                <td>Tanggal Lahir </td>
                <td><?php echo $data[0]->TGL_LAHIR_APLIKAN ?></td>
            </tr>
            <tr>
                <td>Fakultas </td>
                <td><?php echo $data[0]->FAKULTAS_APLIKAN ?></td>
            </tr>
            <tr>
                <td>Jurusan </td>
                <td><?php echo $data[0]->JURUSAN_APLIKAN ?></td>
            </tr>
            <tr>
                <td>Program Diterima</td>
                <td><?php echo $data[0]->PROGRAM_DITERIMA ?></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td><?php echo $data[0]->JENIS_KEL_APLIKAN ?></td>
            </tr>
            <tr>
                <td>Agama</td>
                <td><?php echo $data[0]->AGAMA_APLIKAN ?></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><?php echo $data[0]->ALAMAT_APLIKAN ?></td>
            </tr>
            <tr>
                <td>Telepon</td>
                <td><?php echo $data[0]->TELP_APLIKAN ?></td>
            </tr>
            <tr>
                <td>Nama Orang Tua</td>
                <td><?php echo $data[0]->NAMA_ORANGTUA ?></td>
            </tr>
            <tr>
                <td>Alamat Orang Tua</td>
                <td><?php echo $data[0]->ALAMAT_ORANGTUA ?></td>
            </tr>
            <tr>
                <td>Telepon Orang Tua</td>
                <td><?php echo $data[0]->TELP_ORANGTUA ?></td>
            </tr>
            <tr>
                <td>Pekerjaan Orang Tua</td>
                <td><?php echo $data[0]->PEKERJAAN_ORANGTUA ?></td>
            </tr>
        </table>
        <?php } ?>
        <?php echo form_close(); ?>
    </body>
</html>
