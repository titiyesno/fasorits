<!--script>
    function caripenghuni(){
        $.ajax({
            type: "POST",
            url: $("#car_penghuni_from").attr('action'),
            data: $("#car_penghuni_from").serialize(),
            success: function(data) {
                $("#tabel_penghuni").html(data);
            }
        });
        return false;
    };
</script--!>
<div id="container oxigenfontblue">
<center><h3 class="oxigenfontblue">Data Penghuni Asrama</h3></center>
<hr>
<!--<form class="custom" id="car_penghuni_from" method="post" action="<?php// echo site_url('penghuni/admin/cari_penghuni'); ?>">
<div class="row">
    <div class="large-2 columns">
        <label for="periode" class="oxigenfont right inline" style="color: black">
            Periode:
        </label>
    </div>
    <div class="large-4 columns">
        <select onchange="caripenghuni()" class="medium"  type="text" name="periode" id="periode">
            <?php// foreach ($list_periode as $r) { ?>
                <option value="<?php// echo $r->ID_PERIODE; ?>" ><?php// echo $r->NAMA_PERIODE; ?></option>
            <?php// } ?>
        </select>
    </div>
    <div class="large-2 columns">
        <label for="periode" class="oxigenfont right inline" style="color: black">
            Gedung:
        </label>
    </div>
    <div class="large-4 columns">
        <select onchange="caripenghuni()" class="medium"  type="text" name="idgedung" id="idgedung">
            <?php// foreach ($list_gedung as $r) { ?>
                <option value="<?php// echo $r->ID_GEDUNG; ?>" ><?php// echo $r->NAMA_GEDUNG; ?></option>
            <?php// } ?>
        </select>
    </div>
</div>
<div class="row">
    <div class="large-2 columns">
        <label for="periode" class="oxigenfont right inline" style="color: black">
            Program Diterima:
        </label>
    </div>
    <div class="large-4 columns">
        <select onchange="caripenghuni()" class="medium"  type="text" name="program" id="program">
            <?php// foreach ($list_program as $r) { ?>
                <option value="<?php// echo $r->PROGRAM_DITERIMA; ?>" ><?php// echo $r->PROGRAM_DITERIMA; ?></option>
            <?php// } ?>
        </select>
    </div>
    <div class="large-2 columns">
        <label for="periode" class="oxigenfont right inline" style="color: black">
            Lantai:
        </label>
    </div>
    <div class="large-4 columns">
        <select onchange="caripenghuni()" class="medium"  type="text" name="lantai" id="lantai">
            <?php// foreach ($list_lantai as $r) { ?>
                <option value="<?php// echo $r->LANTAI; ?>" ><?php// echo $r->LANTAI; ?></option>
            <?php// } ?>
        </select>
    </div>
</div>
</form>-->
<style>
    table{
        white-space: nowrap;
    }
</style>
<script type="text/javascript" src="<?php echo base_url() ?>static/pivot/pivot.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>static/pivot/jquery_pivot.js"></script>
<div class="row oxigenfontblue">
    <div class="large-12 columns">
        <ul class="nav nav-pills">
            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#"> Filter Fields <b class="caret"></b> </a>
                <ul class="dropdown-menu stop-propagation" style="overflow:auto;max-height:450px;padding:10px;">
                    <div id="filter-list"></div>
                </ul>
            </li>
            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#"> Row Label Fields <b class="caret"></b> </a>
                <ul class="dropdown-menu stop-propagation" style="overflow:auto;max-height:450px;padding:10px;">
                    <div id="row-label-fields"></div>
                </ul>
            </li>
        </ul>

        <hr/>

        <h3 class="oxigenfontblue">Hasilnya</h3>
        <span class="hide-on-print" id="pivot-detail"></span>
        <hr/>
        <div style="overflow-x: scroll" id="results"></div>
    </div>
</div>
<div class="row">
    <div class="large-2 columns">
        <label for="gedung" class="oxigenfont right inline" style="color: black">
                </label>
    </div>
    <div class="large-8 columns">
        <table style="width: 100%" id="tabel_penghuni">
            
        </table>
    </div>
    <div class="large-2 columns">
    </div>
</div>

</div>
<script type="text/javascript">
    var fields = [{
            name : 'NAMA PERIODE',
            type : 'string',
            filterable : true
        }, {
            name : 'NAMA GEDUNG',
            type : 'string',
            filterable : true
        }, {
            name : 'LANTAI',
            type : 'string',
            filterable : true
        }, {
            name : 'NOMER KAMAR',
            type : 'string',
            filterable : true
        },
        {
            name : 'NAMA APLIKAN',
            type : 'string',
            filterable : true
        },
        {
            name : 'NRP APLIKAN',
            type : 'string',
            filterable : true
        },
        {
            name : 'PROGRAM DITERIMA',
            type : 'string',
            filterable : true
        }
        
        
    ]

    function setupPivot(input) {
        input.callbacks = {
            afterUpdateResults : function() {
                $('#results > table').dataTable({
                    "sDom" : "<'row'<'span6'l><'span6'f>>t<'row'<'span6'i><'span6'p>>",
                    "iDisplayLength" : 50,
                    "aLengthMenu" : [[25, 50, 100, -1], [25, 50, 100, "All"]],
                    "sPaginationType" : "bootstrap",
                    "oLanguage" : {
                        "sLengthMenu" : "_MENU_ records per page"
                    }
                });
            }
        };
        $('#pivot-demo').pivot_display('setup', input);
    };

    $(document).ready(function() {
var jso;
         var data_pos = {
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        };
        $.ajax({
            type : "POST",
            url : '<?php echo base_url()?>index.php/pindahkamar/admin/getsubmitdata',
            data: data_pos,
            success : function(dataCheck) {
                jso = dataCheck;
                setupPivot({
                    json : jso,
                    fields : fields,
                    rowLabels : ["NAMA APLIKAN","NRP APLIKAN", "NOMER KAMAR","NAMA GEDUNG","LANTAI"]
                })
                $('.stop-propagation').click(function(event) {
                    event.stopPropagation();
                });

            }
        });
    });
</script>
        

