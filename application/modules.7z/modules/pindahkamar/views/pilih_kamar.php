            <div class="row">
                <center>
                    <h3 class="oxigenfontblue">Pilih Gedung</h3>
                    <select id="gedung" class="medium" name="gedung">
                        <?php
                        if (isset($gedung))
                            foreach ($gedung as $data) {
                                ?>
                                <option value="<?php echo $data->ID_GEDUNG ?>"><?php echo $data->NAMA_GEDUNG ?></option>
                            <?php } ?>
                    </select>
                </center>
            </div>