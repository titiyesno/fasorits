<script>
    function getXMLHTTP() { //fuction to return the xml http object
        var xmlhttp = false;
        try {
            xmlhttp = new XMLHttpRequest();
        }
        catch (e) {
            try {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (e) {
                try {
                    xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
                }
                catch (e1) {
                    xmlhttp = false;
                }
            }
        }

        return xmlhttp;
    }

    function getJenisKamar(bulan_masuk) {
        var strURL = "<?php echo base_url() ?>index.php/pemesanan/aplikan/getHTMLJenisKamar/" + bulan_masuk;
        var req = getXMLHTTP();

        if (req) {

            req.onreadystatechange = function() {
                if (req.readyState == 4) {
                    // only if "OK"
                    if (req.status == 200) {
                        document.getElementById('divjeniskamar').innerHTML = req.responseText;
                    } else {
                        alert("There was a problem while using XMLHTTP:\n" + req.statusText);
                    }
                }
            }
            req.open("GET", strURL, true);
            req.send(null);
        }

    }
</script>
<section class="content-header">
    <h1>
        Pilih Jenis Kamar
        <small>Reservasi</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Reservasi</li>
    </ol>
</section>
<section class="content">
    <?php if (isset($open)) { ?>
        <?php echo form_open("pemesanan/aplikan/formpilihjeniskamar"); ?>
        <div class="row">
            <div class="callout callout-info">
                <h4>Informasi Pembayaran</h4>
                <p>Pembayaran dilakukan secara kontan pada saat daftar ulang ketika diterima. KHUSUS untuk mahasiswa dari jalur masuk BIDIK MISI dapat melakukan pembayaran secara cicilan</p>
            </div>
            <div class="col-md-4">
                <!-- Info box -->
                <div class="box box-info">
                    <div class="box-header">
                        <h3 class="box-title">Isian Kamar</h3>
                        <div class="box-tools pull-right">
                            <div class="label bg-aqua">Pilihan Jenis Kamar</div>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            Jenis Pembayaran
                            <select class="form-control" id="pembayaran" name="pembayaran">
                                <option value="1">Kontan</option>
                                <?php
                                if (strpos($program_diterima,"Bidik Misi")!==false) {
                                    ?>
                                    <option value="2">Cicilan 2 kali</option>
                                    <option value="3">Cicilan 3 kali</option>
                                    <option value="4">Cicilan 4 kali</option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group">
                            Bulan Masuk
                            <select name="BULAN_MASUK" class="form-control" onChange="getJenisKamar(this.value)" id="BULAN_MASUK">
                                <option selected disabled value="8" >Pilih Bulan Masuk</option>
                                <option value="7">JULI</option>
                                <option value="8">AGUSTUS</option>
                                <option value="9">SEPTEMBER</option>
                                <option value="10">OKTOBER</option>
                                <option value="11">NOPEMBER</option>
                                <option value="12">DESEMBER</option>
                                <option value="1">JANUARI</option>
                            </select>
                        </div>

                    </div>
                </div><!-- /.box -->
            </div>
            <div class="col-md-8">

                <div id="divjeniskamar">

                </div>
                <input type="submit" value="Next" class="btn btn-primary"/>
            </div>
        </div>
        <?php echo form_close() ?>



    <?php } else { ?>
        <div class="callout callout-danger">
            <h4>Pemberitahuan</h4>
            <p>Pendaftaran Reservasi Asrama ITS Belum Dibuka</p>
        </div>
    <?php } ?>
</section>


<script>
    $(function() {
        window.prettyPrint && prettyPrint();
        $('#dp1').fdatepicker({
            format: 'yyyy-mm-dd'
        });
    });
    var request;
    // bind to the submit event of our form
    $("#foo").submit(function(event) {
        // abort any pending request
        if (request) {
            request.abort();
        }
        // setup some local variables
        var $form = $(this);
        // let's select and cache all the fields
        var $inputs = $form.find("input, select, button, textarea");
        // serialize the data in the form
        var serializedData = $form.serialize();

        // let's disable the inputs for the duration of the ajax request
        $inputs.prop("disabled", true);

        // fire off the request to /form.php
        request = $.ajax({
            url: "/form.php",
            type: "post",
            data: serializedData
        });

        // callback handler that will be called on success
        request.done(function(response, textStatus, jqXHR) {
            // log a message to the console
            console.log("Hooray, it worked!");
        });

        // callback handler that will be called on failure
        request.fail(function(jqXHR, textStatus, errorThrown) {
            // log the error to the console
            console.error(
                    "The following error occured: " +
                    textStatus, errorThrown
                    );
        });

        // callback handler that will be called regardless
        // if the request failed or succeeded
        request.always(function() {
            // reenable the inputs
            $inputs.prop("disabled", false);
        });

        // prevent default posting of form
        event.preventDefault();
    });
</script>
