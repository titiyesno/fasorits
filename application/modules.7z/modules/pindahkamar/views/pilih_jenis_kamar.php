<div class="row shadowborder">
    <div class="large-12 columns" id="container">
        <form class="custom">
            <div class="row">
                <center><h3 class="oxigenfontblue">Daftar Jenis Kamar</h3></center>
                <hr>
                <div id="body">
                    <?php foreach ($jenis_kamar as $r) { ?>
                        <div class="large-3 small-6 columns">
                            <center>
                                <ul class="pricing-table">
                                    <li class="title oxigenfontblue"><?php echo $r->nama_jenis_kamar; ?></li>
                                    <li class="description oxigenfontblue">Per Kamar <?php echo $r->quota_kamar; ?> Mahasiswa</li>
                                    <li class="price oxigenfontblue"> Rp.  <?php echo $r->harga_kamar; ?></li>
                                    <li class="bullet-item"><?php echo $r->keterangan; ?></li>
                                    <li class="cta-button">
                                        <input class="button" type="radio" name="pilih" value="<?php echo $r->id_jenis_kamar; ?>" id="pilih"><label for="pilih">&nbsp</label>
                                    </li>
                                </ul>
                            </center>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </form>
        <div class="row">
            <div  class="right large-12 columns">
                <a href="perjanjian" class="right radius round button">Next</a>    
            </div>
        </div>
    </div>
</div>

