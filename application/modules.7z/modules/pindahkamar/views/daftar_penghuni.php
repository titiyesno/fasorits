<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <div id="container"><center><h3 class="oxigenfontblue">Daftar Penghuni</h3></center>
            <hr>
        <table>
            <thead>
            <th>Nama Penghuni</th>
            <th>Fakultas</th>
            <th>Jurusan</th>
            <th>Gedung</th>
            <th>Nomer Kamar</th>
        </thead>
        <tbody>

            <?php foreach ($aplikan->result() as $row) { ?><tr>
                    <td><?php echo $row->NAMA_APLIKAN; ?></td>
                    <td><?php echo $row->FAKULTAS; ?></td>
                    <td><?php echo $row->JURUSAN; ?></td>
                    <td><?php echo $row->GEDUNG; ?></td>
                    <td><?php echo $row->NOMOR; ?></td>
                    <td>
                        <?php echo '<a href="' . base_url() . 'index.php/pindahkamar/admin/detil/">Lihat Detil Tiket</a>' ?>
                        <?php echo '<a href="' . base_url() . 'index.php/pindahkamar/admin/pindah/' . $row->ID_SUBMIT . '" onclick="return confirm(\'Anda yakin akan memindah kamar ' . $row->NAMA_APLIKAN . '?\')">Ubah</a>' ?></td>  
                </tr>
            <?php } ?>
        </tbody>    
    </table>
</div>
</body>
</html>
