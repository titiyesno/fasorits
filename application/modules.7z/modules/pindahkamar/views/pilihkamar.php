<section class="content-header">
    <h1>
        Pilih Kamar
        <small>Reservasi</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Reservasi</li>
    </ol>
</section>
<p class="callout callout-danger">
Pilih Kamar Lebih Lengkap : <a class="btn btn-primary" href="<?php echo base_url("index.php/pindahkamar/admin/pilihallkamar/".$nrp)?>">Pilih lain</a>
</p>
<section class="container">
	
    <div class="col-sm-12">
	
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
                <?php
                $pids = array();
                foreach ($kamar as $h) {
                    $pids[] = $h->NAMA_GEDUNG;
                }
                $uniquePids = array_unique($pids);
                $i = 0;
                foreach ($uniquePids as $data) {
                    ?>
                    <li <?php
                    if ($i == 0)
                        echo "class='active'";
                    else
                        echo "class"
                        ?>>
                        <a href="#<?php echo str_replace(" ", "-", $data); ?>"  data-toggle="tab" ><?php echo $data; ?>
                        </a>
                    </li>
                    <?php
                    $i++;
                }
                ?>
            </ul>
            <div class="tab-content">
                <?php
                $pids = array();
                foreach ($kamar as $h) {
                    $pids[] = $h->NAMA_GEDUNG;
                }
                $uniquePids = array_unique($pids);
                $i = 0;
                foreach ($uniquePids as $data) {
                    ?>
                    <div class="tab-pane <?php if ($i == 0) echo 'active'; ?>" id="<?php echo str_replace(" ", "-", $data); ?>">
                        <div class="box-group" id="accordion">
                            <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->

                            <?php
                            $temp = -1;
                            foreach ($kamar as $data2) {
                                if ($data2->NAMA_GEDUNG == $data && $temp != $data2->LANTAI) {
                                    ?>    
                                    <div class="panel box box-primary">
                                        <div class="box-header">
                                            <h4 class="box-title">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#<?php echo "lt".$data2->LANTAI; ?>" class="">
                                                    <?php echo "Lantai - " . $data2->LANTAI; ?>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="<?php echo "lt" . $data2->LANTAI; ?>" class="panel-collapse in" style="height: auto;">
                                            <div class="box-body">
                                                <table class="table table-bordered">
                                                    <thead>
                                                    <th>Nomer Kamar</th>
                                                    <th>Jenis Kamar</th>
                                                    <th>Nama Gedung</th>
                                                    <th>Lantai</th>
                                                    <th>Keterangan Gedung</th>
                                                    <th>Tersedia</th>
                                                    <th>Pilih</th>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        foreach ($kamar as $data3) {
                                                            if ($data3->NAMA_GEDUNG == $data && $data2->LANTAI == $data3->LANTAI) {
                                                                ?>
                                                                <tr>
                                                                    <td>
                                                                        <?php echo $data3->NOMER_KAMAR; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $data3->nama_jenis_kamar; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $data3->NAMA_GEDUNG; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $data3->LANTAI; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $data3->KETERANGAN_GEDUNG; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $data3->_AVAILABLE; ?> Mahasiswa
                                                                    </td>
                                                                    <td>
                                                                        <?php if ($data3->_AVAILABLE > 0) { ?>
                                                                            <a href="<?php echo base_url("index.php/pindahkamar/admin/")?>/formpilihkamar/<?php echo $nrp."/".$data3->ID_KAMAR; ?>" class="btn btn-primary" >Book</a>
                                                                            <?php
                                                                        } else {
                                                                            ?>
                                                                            <a href="#" class="btn btn-danger" disabled="" >Empty</a>
                                                                        <?php } ?>
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>


                                    <?php
                                    $temp = $data2->LANTAI;
                                }
                            }
                            ?>
                        </div>
                    </div>
                    <?php
                    $i++;
                }
                ?>

            </div><!-- /.tab-content -->
        </div>
    </div>
</section>
<script>
    $(function() {
        $('#myTab a:last').tab('show')
    })
</script>
