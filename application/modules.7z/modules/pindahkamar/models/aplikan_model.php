	<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	/*
	 * To change this template, choose Tools | Templates
	 * and open the template in the editor.
	 */
	class aplikan_model extends CI_model {
	    
	    function __construct() {
	        parent::__construct();
	        $this->load->database();
	    }
	    
	    //sama dengan getsumit di kamar_model di modul pemesanan, where status submit='penghuni'
	    public function read_penghuni2(){
	        $sql = "select submit.ID_SUBMIT, submit.TANGGAL_SUBMIT, submit.STATUS_SUBMIT,aplikan.NAMA_APLIKAN, aplikan.NRP_APLIKAN, aplikan.PROGRAM_DITERIMA, aplikan.NRP_APLIKAN,jenis_kamar.nama_jenis_kamar, kamar.NOMER_KAMAR, kamar.LANTAI, gedung.NAMA_GEDUNG, periode.NAMA_PERIODE, submit.CODE_BOOKING 
	        from submit, aplikan, kamar, jenis_kamar, periode, jenis_submit, gedung
	        where submit.ID_APLIKAN=aplikan.ID_APLIKAN and submit.ID_KAMAR=kamar.ID_KAMAR and kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar
	        and kamar.ID_GEDUNG=gedung.ID_GEDUNG and submit.ID_JENIS_SUMBIT=jenis_submit.ID_JENIS_SUMBIT and submit.ID_PERIODE=periode.ID_PERIODE and submit.STATUS_SUBMIT='penghuni'";
	        return $this->query($sql);
	    }
	    public function read_penghuni()
	    {
	        $query = 'select submit.CODE_BOOKING, aplikan.NAMA_APLIKAN, aplikan.NRP_APLIKAN, aplikan.TGL_LAHIR_APLIKAN, aplikan.TEMPAT_LAHIR_APLIKAN, aplikan.FAKULTAS_APLIKAN, aplikan.JURUSAN_APLIKAN, aplikan.PROGRAM_DITERIMA, aplikan.JENIS_KEL_APLIKAN, aplikan.AGAMA_APLIKAN, aplikan.ALAMAT_APLIKAN, aplikan.TELP_APLIKAN, aplikan.PEKERJAAN_ORANTUA, aplikan.PENGHASILAN_ORANGTUA,
				kamar.NOMER_KAMAR, kamar.LANTAI, gedung.NAMA_GEDUNG, periode.NAMA_PERIODE, periode.NAMA_PERIODE, submit.TANGGAL_SUBMIT 
	        from submit inner join aplikan on (submit.ID_APLIKAN=aplikan.ID_APLIKAN) 
	        left join kamar on (submit.ID_KAMAR=kamar.ID_KAMAR) 
	        left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG) 
	        left join periode on (submit.ID_PERIODE=periode.ID_PERIODE)
	        where submit.STATUS_SUBMIT = "penghuni"';
	        return $this->db->query($query)->result();
	    }
	    public function update_aplikan($id,$nama,$nrp,$tgllahir,$tempatlahir,$fakultas,$jurusan,$program,$jenis,$agama,$alamat,$telp,$nama_ortu,$alamat_ortu,$telp_ortu,$pekerjaan_ortu,$ktp,$ktm,$foto){
	
	        $data = array(
	            'NAMA_APLIKAN' => $nama,
	            'NRP_APLIKAN' => $nrp,
	            'TGL_LAHIR_APLIKAN' => $tgllahir,
	            'TEMPAT_LAHIR_APLIKAN' => $tempatlahir,
	            'FAKULTAS_APLIKAN' => $fakultas,
	            'JURUSAN_APLIKAN' => $jurusan,
	            'PROGRAM_DITERIMA' => $program,
	            'JENIS_KEL_APLIKAN' => $jenis,
	            'AGAMA_APLIKAN' => $agama,
	            'ALAMAT_APLIKAN' => $alamat,
	            'TELP_APLIKAN' => $telp,
	            'NAMA_ORANGTUA' => $nama_ortu,
	            'ALAMAT_ORANGTUA' => $alamat_ortu,
	            'TELP_ORANGTUA' => $telp_ortu,
	            'PEKERJAAN_ORANGTUA' => $pekerjaan_ortu
	        );
	
	        $this->db->where('ID_APLIKAN',$id);
	        $result = $this->db->update('aplikan', $data);
	        return $result; 
	    }
	    
	    public function delete_aplikan($idaplikan){
	        $this->db->where('ID_APLIKAN', $idaplikan);
	        $this->db->delete('aplikan');
	    }
	    public function getaplikan($nrp){
	    	$sql="select aplikan.NRP_APLIKAN, aplikan.PROGRAM_DITERIMA, aplikan.JENIS_KEL_APLIKAN, kamar.ID_JENIS_KAMAR from aplikan left join submit on (aplikan.ID_APLIKAN=submit.ID_APLIKAN) left  join kamar on (kamar.ID_KAMAR=submit.ID_KAMAR) where aplikan.NRP_APLIKAN=?";
	    	return $this->query($sql,array($nrp));
	    }
	}