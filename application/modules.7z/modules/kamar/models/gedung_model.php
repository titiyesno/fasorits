<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class gedung_model extends CI_model {
    
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function create_gedung($idgaleri,$nama,$ket,$jenis,$profil,$lat,$long){

        $data = array(
            'ID_GALERI' => $idgaleri,
            'NAMA_GEDUNG' => $nama,
            'KETERANGAN_GEDUNG' => $ket,
            'JENIS_GEDUNG' => $jenis,
            'PROFIL_GEDUNG' => $profil,
            'LATITUDE' => $lat,
            'LONGITUDE' => $long,
        );
        $this->db->insert('gedung', $data);    
        return $this->db->insert_id();
    }
    
    public function read_gedung(){
        $sql="select * from view_gedung order by view_gedung.NAMA_GEDUNG";
        return $this->query($sql);
    }
    
    public function read_gedung_by_id($id){
        $this->db->where('ID_GEDUNG',$id);
        $query = $this->db->get('gedung');
        return $query->result();
    }
    
    public function getById(){
        $this->db->select('ID_GEDUNG');
        $this->db->select('NAMA_GEDUNG');
        $this->db->from('gedung');
        $query=$this->db->get()->result();
        return $query;
    }
    
    public function update_gedung($id, $idgaleri,$nama,$ket,$jenis,$profil,$lat,$long){

        $data = array(
            'ID_GALERI' => $idgaleri,
            'NAMA_GEDUNG' => $nama,
            'KETERANGAN_GEDUNG' => $ket,
            'JENIS_GEDUNG' => $jenis,
            'PROFIL_GEDUNG' => $profil,
            'LATITUDE' => $lat,
            'LONGITUDE' => $long,
        );
        $this->db->where('ID_GEDUNG',$id);
        $result = $this->db->update('gedung', $data);
        return $result; 
    }
    
    public function delete_gedung($id){
        $this->db->where('ID_GEDUNG', $id);
        $this->db->delete('gedung');
    }
    
    public function getAllKoordinat() {
        $query = "SELECT nama_gedung as nama, latitude as la, longitude as lo FROM `gedung`";
        return $this->db->query($query)->result();
    }
    
    public function CountRoom($id)
    {
        $query = "select count(g.id_gedung) as jumlah from gedung g, kamar k where g.id_gedung = k.id_gedung and g.id_gedung = $id";
        return $this->db->query($query)->result();
    }
    
//    public function resumeGedung($id)
//    {
//        $query = "";
//    }
}