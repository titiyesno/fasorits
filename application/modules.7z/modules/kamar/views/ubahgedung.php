<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.2.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script>
    var map;
    var markers = [];
    var lat;
    var long;
    var koordGedung;
    function initialize() {

        var myOptions = {
            zoom: 15,
            center: new google.maps.LatLng($("#lat").val(), $("#long").val()),
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            PanControlOptions: false,
            zoomControl: true

        };
        map = new google.maps.Map(document.getElementById('map-canvas'), myOptions);
        koordGedung = new google.maps.LatLng($("#lat").val(), $("#long").val());
        marker = new google.maps.Marker(
                {
                    draggable: true,
                    animation: google.maps.Animation.DROP,
                    map: map,
                    position: koordGedung
                })
        markers.push(marker);
        google.maps.event.addListener(marker, 'mouseup', function(event)
        {

            $("#lat").val(event.latLng.lat());
            $("#long").val(event.latLng.lng());

        })
    }
    function clearMarkers() {
        for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(null)
        }
        markers = [];
    }
    ;
    google.maps.event.addDomListener(window, 'load', initialize);
    $(function() {
        var items = [
<?php
$itung = 0;
foreach ($filter as $p)
    foreach ($p as $u => $i) {
        echo "'" . $u . "',";
    }
?>
        ];

        function split(val) {
            return val.split(/,\s*/);
        }
        function extractLast(term) {
            return split(term).pop();
        }

        $("#jenis")
                .autocomplete({
                    minLength: 0,
                    source: function(request, response) {
                        response($.ui.autocomplete.filter(
                                items, extractLast(request.term)));
                    },
                    focus: function() {
                        return false;
                    },
                    select: function(event, ui) {
                        var terms = split(this.value);
                        // remove the current input
                        terms.pop();
                        // add the selected item
                        terms.push(ui.item.value);
                        // add placeholder to get the comma-and-space at the end
                        terms.push("");
                        this.value = terms.join(", ");
                        return false;
                    }
                });
    });
</script>
<script>
    function simpanfasilitas() {
        $.ajax({
            type: "POST",
            url: $("#tambahfasilitas-form").attr('action'),
            data: $("#tambahfasilitas-form").serialize(),
            success: function(data) {
                $("tbody#tabelfasilitas").html(data);
            }
        });
        return false;
    }
    ;
    function assign_namagaleri() {
        $("#galerinama").val($("#nama").val());
    }
    function clearmodal()
    {
        $("#nama_fasilitas").val(null);
        $("#keterangan_fasilitas").val(null);
        $("#jumlah_fasilitas").val(null);
    }
    function hapusfasilitas(id, idgedung)
    {
        var temp = {};
        temp.id = {};
        temp.id.idgedung = idgedung;
        temp.id.idfasilitas = id;
        $.ajax({
            type: "POST",
            url: '<?php echo base_url("index.php/fasilitas/admin/hapusfasilitasgedung") ?>',
            data: temp,
            success: function(data) {
                $("tbody#tabelfasilitas").html(data);
            }
        });

    }
</script>
<?php foreach ($css_files as $file): ?>
    <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach ($js_files as $file): ?>
    <script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
<section class="content-header">
    <h1>
        Edit Gedung 
        <small>Data Operation</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Katalog</li>
        <li class="active">Gedung</li>
    </ol>
</section>
<div class="content">
    <div class="row">
        <div class="col-sm-12">

            <div class="box">
                <div class="box-header">
                    <center><h3 class="box-title">Ubah Gedung</h3></center>
                </div>
                <div class="box-body">
                    <div id="map-canvas" style="width: 100%px; height: 300px"></div>
                    <input type="hidden" name="lat" id="lat" value="<?php echo $data_gedung[0]->LATITUDE ?>" />
                    <input type="hidden" name="long" id="long" value="<?php echo $data_gedung[0]->LONGITUDE ?>" />
                    <input type="hidden" name="idgedung" id="idgedung" value="<?php echo $data_gedung[0]->ID_GEDUNG ?>" />
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="box">
                <div class="box-header">
                    <center><h3 class="box-title">Ubah Data Gedung</h3></center>
                </div>
                <div class="box-body">
                    <form action="<?php echo base_url() ?>index.php/kamar/admin/SimpanPerubahanGedung" method="POST" class="custom" >
                        <div class="form-group">
                            <label for="nama" >
                                Nama Gedung 
                            </label>
                            <input class="form-control" oninput="assign_namagaleri()" type="text" placeholder="Nama Gedung" value="<?php echo $data_gedung[0]->NAMA_GEDUNG ?>" id="nama" name="nama" required/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">

                            <label for="nama">
                                Keterangan 
                            </label>
                            <input class="form-control" type="text" placeholder="Keterangan" value="<?php echo $data_gedung[0]->KETERANGAN_GEDUNG ?>" id="keterangan" name="keterangan" required/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="nama">
                                Jenis Gedung 
                            </label>
                            <textarea class="form-control" placeholder="Keterangan"  name="jenis" id="jenis" required><?php echo $data_gedung[0]->JENIS_GEDUNG ?></textarea>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">

                            <label for="nama">
                                Profil Gedung 
                            </label>
                            <textarea class="form-control" placeholder="Profil Gedung" id="profile" name="profil" required><?php echo $data_gedung[0]->PROFIL_GEDUNG ?></textarea>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="namagaleri" class="oxigenfont right inline" style="color: black">
                                Nama Galeri 
                            </label>
                            <input type="hidden" value="<?php echo $data_galeri[0]->ID_GALERI ?>" id="galeriid" name="galeriid"/>
                            <input class="form-control" type="text" disabled placeholder="Nama Galeri" value="<?php echo $data_galeri[0]->NAMA_GALERI ?>" id="galerinama" name="galerinama" required/>
                            <div class="help-block with-errors"></div>
                        </div>

                        <div class="form-group">
                            <center><input class="btn btn-primary" type="submit" value="Simpan Perubahan" style="border: 0px; margin-top: 30px"></center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="row">
                <div class="col-sm-12">
                    <div class="box">
                        <div class="box-header">
                            <center><h3 class="box-title">Ubah Gambar Gedung</h3></center>
                        </div>
                        <div class="box-body">
                            <?php echo $output; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="box">
                        <div class="box-header">
                            <center><h3 class="box-title">Ubah Fasilitas Gedung</h3></center>
                        </div>
                        <div class="box-body">
                            <div class="row">
                                <div class="col-sm-4">
                                    <form id="tambahfasilitas-form" action="<?php echo base_url() ?>index.php/fasilitas/admin/simpanfasilitasgedung" method="POST" role="form">
                                        <div class="form-group">
                                            <label for="nama">
                                                Nama Fasilitas
                                            </label>
                                            <input class="form-control" type="text" placeholder="Nama Fasilitas" id="nama_fasilitas" name="nama_fasilitas" required/>
                                        </div>
                                        <div class="form-group">
                                            <label for="keterangan">
                                                Keterangan 
                                            </label>
                                            <textarea class="form-control" placeholder="Keterangan Fasilitas" id="keterangan_fasilitas" name="keterangan_fasilitas" required></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="jumlah">
                                                Jumlah
                                            </label>
                                            <input class="form-control" type="text" placeholder="Jumlah Fasilitas" id="jumlah_fasilitas" name="jumlah_fasilitas" required/>
                                        </div>
                                        <div class="form-group">
                                            <input type="hidden" id="idgedung" name="idgedung" value="<?php echo $idgedung ?>" />
                                            <input type="hidden" id="idkamar" name="idkamar" value="<?php echo $idkamar ?>" />
                                        </div>
                                        <div class="form-group">
                                            <center><input class="btn btn-primary" onclick="simpanfasilitas()" value="Tambahkan" style="border: 0px; margin-top: 30px"></center>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-sm-8">
                                    <table class="table-bordered" style="width: 100%">
                                        <thead>
                                            <tr>
                                                <th >#</th>
                                                <th style="width: 40%">Nama</th>
                                                <th style="width: 40%">Keterangan</th>
                                                <th >Jumlah</th>
                                                <th style="width: 10"></th>
                                            </tr>
                                        </thead>
                                        <tbody id="tabelfasilitas">
                                            <?php
                                            $a = 1;
                                            foreach ($list_fasilitas as $r) {
                                                ?>
                                                <tr>
                                                    <td><?php echo $a; ?></td>
                                                    <td><?php echo $r->nama; ?></td>
                                                    <td><?php echo $r->keterangan; ?></td>
                                                    <td><?php echo $r->jumlah; ?></td>
                                                    <td><input style="width: 60px" class="btn btn-danger btn-sm" onclick="hapusfasilitas(<?php echo $r->id_fasilitas; ?>,<?php echo $idgedung ?>)" value="Hapus"></td>
                                                </tr>
                                                <?php
                                                $a++;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>