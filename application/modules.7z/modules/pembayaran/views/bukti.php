<h3>Bukti Pembayaran Asrama ITS</h3>
<hr/>
<h2 class="oxigenfont">Bukti Pembayaran</h2>
<h4 class="oxigenfontblue">NRP : <?php echo $data[0]->NRP_APLIKAN?></h4>
<h4 class="oxigenfontblue">Kode Booking : <?php echo $data[0]->CODE_BOOKING?></h4>
<h4 class="oxigenfontblue">Tanggal Bayar : <?php echo $data[0]->TANGGAL_BAYAR?></h4>
<h4 class="oxigenfontblue">Via : <?php echo $data[0]->VIA?></h4>
<h4 class="oxigenfontblue">Nominal Angsuran : <?php echo $data[0]->NOMINAL_ANGSURAN?></h4>
<input type="button" class="small button hide-for-print" value="Print this page" onClick="window.print()">