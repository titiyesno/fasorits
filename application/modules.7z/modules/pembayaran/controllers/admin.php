<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class admin extends Admin_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->model('pembayaran/pembayaran_model');
    }

    public function getsubmitdata() {
        $temp1 = $this->pembayaran_model->read_penghuni();
        $data["submit"] = $this->getPivot($temp1);
        return $data["submit"];
    }

    function all() {
        $temp1 = $this->pembayaran_model->read_pembayaran();
        $data["submit"] = $this->getPivot($temp1);
        return $data["submit"];
    }

    function hapus($id, $nrp) {
        $this->pembayaran_model->hapus($id);
        $this->pembayaran($nrp);
    }

    function bayar() {
        $temp1 = $this->pembayaran_model->_read_pembayaran();
        $data["submit"] = $this->getPivot($temp1);
        return $data["submit"];
    }

    function clean($string) {
        //$string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
        //return str_replace(array('\'', '\\', '/', '*'), ' ', $string);
        return preg_replace('/[^A-Za-z0-9\-@ .,]/', '-', $string); // Removes special chars.
    }

    private function getPivot($data) {
        header('Cache-Control: no-cache, must-revalidate');
        header('Content-type: application/json');
        $header = "[[";
        foreach ($data as $value) {
            foreach ($value as $key => $sembarang) {
                $header .= '"' . str_replace("_", " ", strtoupper($key)) . '"';
                break;
            }
            $count = 1;
            foreach ($value as $key => $sembarang) {
                if ($count > 1)
                    $header .= ',"' . str_replace("_", " ", strtoupper($key)) . '"';
                $count++;
            }
            $header .= "]";
            break;
        }

        foreach ($data as $value) {
            $header .= ",[";
            foreach ($value as $key => $data) {
                $data = $this->clean($data);
                if ($key == "NRP_APLIKAN")
                    $header .= '"<a href=\'' . base_url() . 'index.php/pembayaran/admin/pembayaran/' . $data . '\'>' . $data . '</a>"';
                else
                    $header .= '"' . $data . '"';
                break;
            }
            $count = 1;
            foreach ($value as $key => $data) {
                $data = $this->clean($data);
                if ($count > 1) {
                    if ($key == "NRP_APLIKAN")
                        $header .= ',"<a href=\'' . base_url() . 'index.php/pembayaran/admin/pembayaran/' . $data . '\'>' . $data . '</a>"';
                    else
                        $header .= ',"' . $data . '"';
                }
                $count++;
            }
            $header .= "]";
        }
        $header .= "]";
        echo $header;
    }

    private function getHeader($data) {
        $array = array();
        foreach ($data as $value) {
            foreach ($value as $key => $sembarang) {
                $key = str_replace("_", " ", $key);
                $key = strtoupper($key);
                array_push($array, $key);
            }
            return $array;
        }
    }

    function index() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Rekap Pembayaran");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("lihat_pembayaran.php");
    }

    function pivot_pembayaran() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Rekap Pembayaran");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("pembayaran.php");
    }

    public function semua() {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Rekap Pembayaran");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("lihatpemesanan.php");
    }

    public function pembayaran($nrp) {
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Rekap Pembayaran");
//	$temp = $this->pembayaran_model->getcode($nrp);
        $data["aplikan"] = $this->pembayaran_model->readaplikan($nrp);
        $data["angsuran"] = $this->pembayaran_model->angsuran($nrp);
        $data["histori"] = $this->pembayaran_model->histori($nrp);
        $data["status"] = $this->pembayaran_model->status($nrp);
        $data['kuisioner'] = $this->pembayaran_model->getkuisioner($nrp);
        $data['deposit'] = $this->pembayaran_model->getdeposit($nrp);
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("profileaplikan.php", $data);
    }

    public function checkout($bookingcode) {
        $this->pembayaran_model->chekout($bookingcode);
        redirect("pembayaran/admin/index");
    }

    public function pay() {
        $data["ID_PENGELOLA"] = $this->session->userdata["logged_in"]["id"];
        $data["NOMINAL_ANGSURAN"] = $this->input->post("nominal");
        $nrp = $this->input->post("nrp");
        $data["ID_SUBMIT"] = $this->input->post("id");
        $data["TANGGAL_BAYAR"] = date("Y-m-d", strtotime($this->input->post('tanggal')));
        $data["VIA"] = $this->input->post("via");
        $this->pembayaran_model->pay($data);
        redirect("pembayaran/admin/pembayaran/" . $nrp, "refresh");
    }

    public function deposit() {
        $data["DEPOSIT"] = $this->input->post("nominal");
        $data["TANGGAL_BAYAR_DEPOSITO"] = date("Y-m-d", strtotime($this->input->post('tanggal')));
        $nrp = $this->input->post("nrp");
        $id = $this->input->post("id");
        $this->pembayaran_model->deposit($data, $id);
        redirect("pembayaran/admin/pembayaran/" . $nrp, "refresh");
    }

    public function getXLS() {
        $data = $this->pembayaran_model->_read_pembayaran();
        $this->generateCSV($data, "Pembayaran Asrama");
    }

    public function bukti($id) {
        $data["data"] = $this->pembayaran_model->bukti($id);
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('cetak');
        $this->template->title("Rekap Pembayaran");
        $this->template->build("bukti.php", $data);
    }

    public function generateCSV($data, $nama) {
        header("Content-type: application/octet-stream");
        header("Content-Disposition: attachment; filename=" . $nama . "-asramaITS.xls");
        header("Pragma: no-cache");
        header("Expires: 0");

        $header = "";
        foreach ($data as $value) {
            foreach ($value as $key => $sembarang) {
                $header .= $key;
                break;
            }
            $count = 1;
            foreach ($value as $key => $sembarang) {
                if ($count > 1)
                    $header .= '	' . $key;
                $count++;
            }
            $header .= "\n";
            break;
        }

        foreach ($data as $value) {
            foreach ($value as $key => $data) {
                $header .= $data;
                break;
            }
            $count = 1;
            foreach ($value as $key => $data) {
                if ($count > 1) {
                    if ($key == "SITE_ID" && $this->isAdmin())
                        $header .= '	' . $data;
                    else
                        $header .= '	' . $data;
                }
                $count++;
            }
            $header .= "\n";
        }
        echo $header;
    }

}

?>
