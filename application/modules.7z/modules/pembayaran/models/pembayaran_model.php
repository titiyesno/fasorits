<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class pembayaran_model extends CI_model {

    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    function hapus($id){
        
        $this->db->where('ID_ANGSURAN', $id);
        $this->db->delete('angsuran'); 
        
    }
            function _read_pembayaran() {
        $sql = 'select 
                submit.STATUS_SUBMIT,
                aplikan.NAMA_APLIKAN, aplikan.NRP_APLIKAN, aplikan.TGL_LAHIR_APLIKAN, aplikan.TEMPAT_LAHIR_APLIKAN, 
                aplikan.FAKULTAS_APLIKAN, aplikan.JURUSAN_APLIKAN, aplikan.PROGRAM_DITERIMA, 
                CASE 
                      WHEN aplikan.JENIS_KEL_APLIKAN = 0 THEN "Male"
                      ELSE "Female" 
                END AS GENDER,
                aplikan.AGAMA_APLIKAN, aplikan.ALAMAT_APLIKAN, aplikan.TELP_APLIKAN, aplikan.PEKERJAAN_ORANTUA, aplikan.PENGHASILAN_ORANGTUA, MONTHNAME(STR_TO_DATE(submit.BULAN_MASUK,"%m")) as "BULAN_MASUK", jenis_kamar.nama_jenis_kamar,
                kamar.NOMER_KAMAR, kamar.LANTAI, gedung.NAMA_GEDUNG, 
                periode.NAMA_PERIODE, periode.NAMA_PERIODE, submit.TANGGAL_SUBMIT, upper(submit.CODE_BOOKING) as CODE_BOOKING, jenis_submit.NAMA_JENIS_SUBMIT
                from submit inner join aplikan on (submit.ID_APLIKAN=aplikan.ID_APLIKAN) 
                left join kamar on (submit.ID_KAMAR=kamar.ID_KAMAR) 
                left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG)
                left join periode on (submit.ID_PERIODE=periode.ID_PERIODE)
                left join jenis_submit on (submit.ID_JENIS_SUMBIT=jenis_submit.ID_JENIS_SUMBIT)
                left join jenis_kamar on (kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar)
                left join payment_status on (submit.ID_SUBMIT=payment_status.ID_SUBMIT)
                where submit.STATUS_SUBMIT = "penghuni" or submit.STATUS_SUBMIT="diterima"  and payment_status.`STATUS`="BELUM LUNAS"';
        return $this->query($sql);
    }

    function read_pembayaran() {
        $sql = 'select payment_status.*, submit.DEPOSIT, aplikan.NAMA_APLIKAN, aplikan.TELP_APLIKAN, concat(gedung.NAMA_GEDUNG," ",kamar.NOMER_KAMAR) as "KAMAR"
                from payment_status left join aplikan on (aplikan.ID_APLIKAN=payment_status.ID_APLIKAN) 
                left join submit on (payment_status.ID_SUBMIT=submit.ID_SUBMIT)
                left join kamar on (kamar.ID_KAMAR=submit.ID_KAMAR)
                left join gedung on (gedung.ID_GEDUNG=kamar.ID_GEDUNG)
                where payment_status.STATUS_SUBMIT="diterima" or payment_status.STATUS_SUBMIT="penghuni" and payment_status.STATUS="BELUM LUNAS" and submit.DEPOSIT!=NULL and submit.DEPOSIT>0';
        return $this->query($sql);
    }

    function readaplikan($booking_code) {
        $sql = "select *, DATE_FORMAT(aplikan.TGL_LAHIR_APLIKAN,'%d %M %Y') as 'TGL_LAHIR_APLIKAN'
                from 
                aplikan right join submit on (aplikan.ID_APLIKAN=submit.ID_APLIKAN)
                left join kamar on (submit.ID_KAMAR=kamar.ID_KAMAR)
                left join jenis_kamar on (kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar)
                left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG)
                where aplikan.NRP_APLIKAN='$booking_code'";
        return $this->query($sql);
    }

    function angsuran($booking_code) {
        $sql = 'select submit.ID_SUBMIT, aplikan.NRP_APLIKAN, jenis_kamar.nama_jenis_kamar, submit.ANGSURAN, submit.BULAN_MASUK, submit.ID_APLIKAN, jenis_kamar.harga_kamar, 
                (EXTRACT(MONTH FROM periode.TANGGAL_SELESAI)+12- submit.BULAN_MASUK) as "MASA_BULAN",
                (jenis_kamar.harga_kamar *(EXTRACT(MONTH FROM periode.TANGGAL_SELESAI)+12- submit.BULAN_MASUK)) as "TOTAL", 
                (jenis_kamar.harga_kamar *(EXTRACT(MONTH FROM periode.TANGGAL_SELESAI)+12- submit.BULAN_MASUK))/ submit.ANGSURAN as  "NILAI_ANGSURAN"
                from 
                submit left join kamar on (submit.ID_KAMAR=kamar.ID_KAMAR)
                left join jenis_kamar on (jenis_kamar.id_jenis_kamar=kamar.ID_JENIS_KAMAR)
                left join periode on (periode.ID_PERIODE=submit.ID_PERIODE)
                left join aplikan on (aplikan.ID_APLIKAN=submit.ID_APLIKAN)
                where aplikan.NRP_APLIKAN = "' . $booking_code . '" ';
        return $this->query($sql);
    }
	function deposit($data, $id){
		$this->db->where('ID_SUBMIT', $id);
		$this->db->update('submit', $data);
	}
    function histori($booking_code) {
        $sql = 'select *, DATE_FORMAT(angsuran.TANGGAL_ANGSURAN,"%d %M %Y") as "TANGGAL_ANGSURAN", DATE_FORMAT(angsuran.TANGGAL_BAYAR,"%d %M %Y") as "TANGGAL_BAYAR" from angsuran left join submit on (submit.ID_SUBMIT=angsuran.ID_SUBMIT) left join aplikan on (aplikan.ID_APLIKAN=submit.ID_APLIKAN)
                where aplikan.NRP_APLIKAN="' . $booking_code . '"';
        return $this->query($sql);
    }

    function pay($data) {
        $this->db->insert("angsuran", $data);
        $sql = 'call update_submit(3,"' . $data["ID_SUBMIT"] . '","' . $data["ID_PENGELOLA"] . '")';
        return $this->query($sql);
    }

    function status($booking_code) {
        $sql = "select * from payment_status where CODE_BOOKING='$booking_code' or NRP_APLIKAN='$booking_code'";
        return $this->query($sql);
    }

    function getkuisioner($code) {
        $sql = "select * from kuisioner left join submit on (kuisioner.ID_SUBMIT=submit.ID_SUBMIT) left join aplikan on (aplikan.ID_APLIKAN=submit.ID_APLIKAN)
                where aplikan.NRP_APLIKAN=?";
        return $this->query($sql, array($code));
    }

    function chekout($code) {
        $sql = "update submit set STATUS_SUBMIT='cekout' where CODE_BOOKING=?";
        $this->db->query($sql, array($code));
    }

    function bukti($id) {
        $sql = 'select * from angsuran left join payment_status on (angsuran.ID_SUBMIT = payment_status.ID_SUBMIT)
              where angsuran.ID_ANGSURAN = ?';

        return $this->query($sql, array($id));
    }
    function getdeposit($nrp)
    {
        $sql = 'select submit.*, DATE_FORMAT(submit.TANGGAL_BAYAR_DEPOSITO,"%d %M %Y") from submit, aplikan where submit.ID_APLIKAN=aplikan.ID_APLIKAN and aplikan.NRP_APLIKAN=?';
        return $this->query($sql, array($nrp));
    }
}
