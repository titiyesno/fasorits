<script src="<?php echo base_url() ?>assets/js/plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/js/plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/js/plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url() ?>assets/js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url() ?>assets/js/plugins/colorpicker/bootstrap-colorpicker.min.js" type="text/javascript"></script>
<!-- bootstrap time picker -->
<script src="<?php echo base_url() ?>assets/js/js/plugins/timepicker/bootstrap-timepicker.min.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript">

    function getXMLHTTP() { //fuction to return the xml http object
        var xmlhttp = false;
        try {
            xmlhttp = new XMLHttpRequest();
        }
        catch (e) {
            try {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (e) {
                try {
                    xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
                }
                catch (e1) {
                    xmlhttp = false;
                }
            }
        }

        return xmlhttp;
    }

    function getJurusan(fakid) {
        var strURL = "<?php echo base_url() ?>index.php/user/user/getJurusan/" + fakid;
        var req = getXMLHTTP();

        if (req) {

            req.onreadystatechange = function() {
                if (req.readyState == 4) {
                    // only if "OK"
                    if (req.status == 200) {
                        document.getElementById('divjurusan').innerHTML = req.responseText;
                    } else {
                        alert("There was a problem while using XMLHTTP:\n" + req.statusText);
                    }
                }
            }
            req.open("GET", strURL, true);
            req.send(null);
        }

    }
</script>
<section class="content-header">
    <h1>
        Profile
        <small>View and Update Data</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Profile</li>
    </ol>
</section>
<section class="content">
<div  class="col-lg-12 col-md-12  col-sm-12 col-xs-12">
    <div class="col-md-6 col-sm-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">Scanned Identity</h3>
            </div>
            <div class="box-body">
                <div class="form-group">
                    <img src="<?php echo base_url("content/aplikan/uploads/" . $aplikan[0]->COPY_KTP); ?>" alt="..." class="img-thumbnail" style="max-width: 100px" >
                    <img src="<?php echo base_url("content/aplikan/uploads/" . $aplikan[0]->COPY_KTM); ?>" alt="..." class="img-thumbnail" style="max-width: 100px" >
                    <img src="<?php echo base_url("content/aplikan/uploads/" . $aplikan[0]->COPY_FOTO); ?>" alt="..." class="img-thumbnail" style="max-width: 100px" >
                </div>
                <div class="form-group">
                    <?php
                    $att = array("role" => "form", "enctype" => "multipart/form-data", "id" => "registrasi-form", "data-toggle" => "validator");
                    echo form_open("user/aplikan/upload", $att)
                    ?>
                    <div class="form-group">
                        <label for="ktm">
                            KTM <small>required. Max Size 500 KB</small>
                        </label>
                        <input type="file" class="form-control"   id="ktm" name="ktm"/>
                        <input type="hidden" class=""   id="ktm" name="nrp" value="<?php echo $aplikan[0]->NRP_APLIKAN;?>"/>
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                        <label for="ktp">
                            KTP <small>required. Max Size 500KB</small>
                        </label>
                        <input type="file" class="form-control"  id="ktp" name="ktp"/>
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                        <label for="foto" >
                            Foto <small>required Max Size 500 KB</small>
                        </label>
                        <input type="file" class="form-control"  id="foto" name="foto"/>
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                        <center><input type="submit" class="btn btn-primary" value="Upload"/></center>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-sm-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">Informations</h3>
            </div><!-- /.box-header -->
            <!-- form start -->
            
            <div class="box-body">
                <?php echo form_open("user/aplikan/update");?>
                <div class="form-group">
                    <label for="nama" >
                        NAMA <small>required</small>
                    </label>
                    <input class="form-control" type="text" placeholder="Nama" value="<?php echo $aplikan[0]->NAMA_APLIKAN?>" id="nama" name="nama" required autocomplete="off"/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="dp1">
                        Tempat Lahir <small>required</small>
                    </label>
                    <input type="text" name="tempat" class="form-control" value="<?php echo $aplikan[0]->TEMPAT_LAHIR_APLIKAN;?>" placeholder="Tempat Lahir" id="tempat" required autocomplete="off"/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label >
                        Tanggal Lahir <small>required</small> <small>format : mm/dd/yyyy ex:03/19/1995</small>
                    </label>
                    <input type="text" name="ttl_t" class="form-control" value="<?php echo date("m/d/Y", strtotime($aplikan[0]->TGL_LAHIR_APLIKAN));?>"/>
                    <div class="help-block with-errors"></div>
                </div>

                <div class="form-group">
                    <label for="x1" >
                        Jenis Kelamin <small>required</small>
                    </label>
                    <label class="checkbox-inline">
                        <input id="checkbox1"  name="jenis_kelamin" type="radio" value="1" <?php if($aplikan[0]->JENIS_KEL_APLIKAN=="Laki-laki") echo "checked";?>>Laki-laki
                    </label>
                    <label class="checkbox-inline">
                        <input id="checkbox2" name="jenis_kelamin" type="radio" value="0" <?php if($aplikan[0]->JENIS_KEL_APLIKAN=="Perempuan") echo "checked";?>>Perempuan
                    </label>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="agama">
                        Agama <small>required</small>
                    </label>
                    <select id="agama" name="agama" class="form-control" required="">
                        <option DISABLED>Agama</option>
                        <option <?php if($aplikan[0]->AGAMA_APLIKAN=="Islam") echo "selected";?> >Islam</option>
                        <option <?php if($aplikan[0]->AGAMA_APLIKAN=="Kristen") echo "selected";?>>Kristen</option>
                        <option <?php if($aplikan[0]->AGAMA_APLIKAN=="Protestan") echo "selected";?>>Protestan</option>
                        <option <?php if($aplikan[0]->AGAMA_APLIKAN=="Hindu") echo "selected";?>>Hindu</option>
                        <option <?php if($aplikan[0]->AGAMA_APLIKAN=="Budha") echo "selected";?>>Budha</option>
                        <option <?php if($aplikan[0]->AGAMA_APLIKAN=="Kong Hu Cu") echo "selected";?>>Kong Hu Cu</option>
                        <option <?php if($aplikan[0]->AGAMA_APLIKAN=="Lainnya") echo "selected";?>>Lainnya</option>
                    </select>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="alamat">
                        Alamat <small>required</small>
                    </label>
                    <textarea placeholder="Alamat" id="alamat" name="alamat" class="form-control" required><?php echo $aplikan[0]->ALAMAT_APLIKAN;?></textarea>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="telp">
                        Telp <small>required</small>
                    </label>
                    <input type="text" placeholder="Telepon Aplikan" class="form-control" id="telp" name="telp" autocomplete="off"  value="<?php echo $aplikan[0]->TELP_APLIKAN;?>" required/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="fakultas">
                        Fakultas <small>required</small>
                    </label>
                    <select name="fakultas" class="form-control" required="" id="fakultas" onChange="getJurusan(this.value)">
                        <option disabled>Pilih Fakultas</option>
                        <?php  foreach ($fakultas as $data) { ?>
                        <option <?php if(count($fak)!=0)if($fak[0]->id_fak==$data->id) echo "selected";?> value="<?php echo $data->id; ?>"><?php echo $data->nama; ?></option>
                        <?php } ?>
                    </select>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="jurusan">
                        Jurusan <small>required</small>
                    </label>
                    <div  id="divjurusan">
                        <select name="jurusan"  required="" id="jurusan" class="form-control">
                            <option ><?php echo $aplikan[0]->JURUSAN_APLIKAN?></option>
                        </select>
                    </div>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="programditerima">
                        Program Diterima <small>required</small>
                    </label>
                    <select id="programditerima" class="form-control" name="programditerima">
                        <option DISABLED>Program Diterima</option>
                        <option <?php if($aplikan[0]->PROGRAM_DITERIMA=="SNMPTN/Bidik Misi") echo "selected";?>>SNMPTN/Bidik Misi</option>
                        <option <?php if($aplikan[0]->PROGRAM_DITERIMA=="SNMPTN/Reguler") echo "selected";?>>SNMPTN/Reguler</option>
                        <option <?php if($aplikan[0]->PROGRAM_DITERIMA=="SBMPTN/Bidik Misi") echo "selected";?>>SBMPTN/Bidik Misi</option>
                        <option <?php if($aplikan[0]->PROGRAM_DITERIMA=="SBMPTN/Reguler") echo "selected";?>>SBMPTN/Reguler</option>
                        <option <?php if($aplikan[0]->PROGRAM_DITERIMA=="ITK") echo "selected";?>>ITK</option>
                        <option <?php if($aplikan[0]->PROGRAM_DITERIMA=="Beasiswa Kemenag") echo "selected";?>>Beasiswa Kemenag</option>
                        <option <?php if($aplikan[0]->PROGRAM_DITERIMA=="Kemitraan dan Mandiri") echo "selected";?>>Kemitraan dan Mandiri</option>
                        <option <?php if($aplikan[0]->PROGRAM_DITERIMA=="UMDESIGN") echo "selected";?>>UMDESIGN</option>
                        <option <?php if($aplikan[0]->PROGRAM_DITERIMA=="International") echo "selected";?>>International</option>
                        <option <?php if($aplikan[0]->PROGRAM_DITERIMA=="DIII-Kerjasama") echo "selected";?>>DIII-Kerjasama</option>
			<option <?php if($aplikan[0]->PROGRAM_DITERIMA=="DIII-PLN") echo "selected";?>>DIII-PLN</option>
			<option <?php if($aplikan[0]->PROGRAM_DITERIMA=="DIV-Teknik Sipil") echo "selected";?>>DIV-Teknik Sipil</option>
			<option <?php if($aplikan[0]->PROGRAM_DITERIMA=="DIV-Teknik Sipil Mandiri") echo "selected";?>>DIV-Teknik Sipil Mandiri</option>
			<option <?php if($aplikan[0]->PROGRAM_DITERIMA=="Lanjut Jenjang") echo "selected";?>>Lanjut Jenjang</option>
                        <option <?php if($aplikan[0]->PROGRAM_DITERIMA=="Afirmasi Dikti") echo "selected";?>>Afirmasi Dikti</option>
                        
                        
                        
                    </select>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="parrent_name" >
                        Nama Orangtua <small>required</small>
                    </label>
                    <input type="text" placeholder="Nama Orangtua" value="<?php echo $aplikan[0]->NAMA_ORANGTUA;?>" class="form-control" id="parrent_name" name="parrent_name" autocomplete="off" required/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="parrent_address">
                        Alamat Orangtua <small>required</small>
                    </label>
                    <textarea class="form-control" placeholder="Alamat Orangtua" id="parrent_address" name="parrent_address" required><?php echo $aplikan[0]->ALAMAT_ORANGTUA;?></textarea>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="parrent_telp">
                        Telp Orangtua <small>required</small>
                    </label>
                    <input type="text" placeholder="Telepon Orangtua" value="<?php echo $aplikan[0]->TELP_ORANGTUA;?>" class="form-control" id="parrent_telp" name="parrent_telp" autocomplete="off" required/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="parrent_job">
                        Pekerjaan Orangtua <small>required</small>
                    </label>
                    <input class="form-control"  value="<?php echo $aplikan[0]->PEKERJAAN_ORANTUA;?>" type="text" placeholder="Pekerjaan Orangtua" id="parrent_job" name="parrent_job" autocomplete="off" required/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <label for="parrent_income">
                        Penghasilan Orangtua/Bulan <small>required</small>
                    </label>
                    <input class="form-control" value="<?php echo $aplikan[0]->PENGHASILAN_ORANGTUA;?>" type="text" placeholder="Penghasilan Orangtua"  id="parrent_job" autocomplete="off" name="parrent_income" required/>
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Save"/>
                </div>
                <?php echo form_close();?>
            </div>
        </div>
    </div>
</div>

</section>
<script>
    $(function() {
        window.prettyPrint && prettyPrint();
        $('#dp1').fdatepicker({
            format: 'yyyy-mm-dd'
        });
    });
    
</script>
