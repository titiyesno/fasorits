<div class="panel">
    <ul class="side-nav">
        <li><a href="<?php echo base_url()?>index.php/pemesanan/aplikan/pilihjeniskamar">Pendaftaran</a></li>
        <li><a href="#">Perpanjangan</a></li>
        <li><a href="#">Pindah Kamar</a></li>
    </ul>
</div>
