<section class="content-header">
    <h1>
        Dashboard Pemesanan
        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <?php if (isset($pesan) && isset($data)) { ?>
            <div class="callout callout-danger">
                <h4>Pemberitahuan</h4>
                <p><?php echo $pesan["isi"]; ?></p>
            </div>
            <div class="col-sm-3">
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3>
                            <?php echo $data[0]->CODE_BOOKING; ?>
                        </h3>
                        <p>
                            Kode Booking
                        </p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="#" class="small-box-footer">
                        &nbsp;
                    </a>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3>
                            <?php echo $data[0]->nama_jenis_kamar; ?>
                        </h3>
                        <p>
                            Jenis Kamar
                        </p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="#" class="small-box-footer">
                        &nbsp;
                    </a>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3>
                            <?php echo $data[0]->NAMA_GEDUNG. "-".$data[0]->NOMER_KAMAR; ?>
                        </h3>
                        <p>
                            Kamar
                        </p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="#" class="small-box-footer">
                        &nbsp;
                    </a>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php
                            if ($data[0]->STATUS_SUBMIT == "daftar")
                                echo "Daftar";
                            else if ($data[0]->STATUS_SUBMIT == "diterima")
                                echo "Rp. ".numberToConcurent(".",$data[0]->KURANG);
                            else if ($data[0]->STATUS_SUBMIT == "penghuni")
                                echo $data[0]->KURANG;
                            ?>
                        </h3>
                        <p>
                            <?php
                            if ($data[0]->STATUS_SUBMIT == "daftar")
                                echo "Status Pendaftaran";
                            else if ($data[0]->STATUS_SUBMIT == "diterima")
                                echo "Total Tagihan";
                            else if ($data[0]->STATUS_SUBMIT == "penghuni")
                                echo "Sisa Pembayaran";
                            ?>

                        </p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="#" class="small-box-footer">
                        &nbsp;
                    </a>
                </div>
            </div>

            <?php
        }
        else {
            ?>

            <div class="callout callout-danger">
                <h4>Pemberitahuan</h4>
                <p>Anda Belum Melakukan Reservasi Kamar. Silahkan Melakukan Reservasi Kamar Asrama</p>
            </div>

        <?php }
        ?>
    </div>
    <div class="row">
        <div class="col-xs-12 connectedSortable">

        </div><!-- /.col -->
    </div>
</section>
