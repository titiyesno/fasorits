<div class="row">
    <table>
        <thead>
        <th>NRP</th>
        <th>Nama Aplikan</th>
        <th>Jenis Kamar</th>
        <th>Program Diterima</th>
        <th>Tanggal Pesan</th>
        <th>Gedung</th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        </thead>
        <tbody>
            <?php foreach ($pesan as $row) { ?><tr>
                    <td><?php echo $row->NRP_APLIKAN; ?></td>
                    <td><?php echo $row->NAMA_APLIKAN; ?></td>
                    <td><?php echo $row->nama_jenis_kamar; ?></td>
                    <td><?php echo $row->PROGRAM_DITERIMA; ?></td>
                    <td><?php echo $row->TANGGAL_SUBMIT; ?></td>
                    <td><?php echo $row->NAMA_GEDUNG; ?></td>
                    <td><?php echo $row->STATUS_SUBMIT; ?></td>
                    <td>
                        <?php echo '<a href="' . base_url() . 'index.php/pemesanan/update/' . $row->ID_SUBMIT . '" onclick="return confirm(\'Anda yakin akan mengubah ' . $row->ID_SUBMIT . '?\')">Confirm</a>' ?>
                        <?php echo '<a href="' . base_url() . 'index.php/pemesanan/hapus/' . $row->ID_SUBMIT . '" onclick="return confirm(\'Anda yakin akan menghapus ' . $row->ID_SUBMIT . '?\')">Waiting List</a>' ?></td>  
                    <?php echo '<a href="' . base_url() . 'index.php/pemesanan/hapus/' . $row->ID_SUBMIT . '" onclick="return confirm(\'Anda yakin akan menghapus ' . $row->ID_SUBMIT . '?\')">Reject</a>' ?></td>  
                </tr>
            <?php } ?>
        </tbody>    
    </table>
</div>