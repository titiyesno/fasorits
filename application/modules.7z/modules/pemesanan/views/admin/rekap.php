<script type="text/javascript" charset="utf-8">
    /* Define two custom functions (asc and desc) for string sorting */
    jQuery.fn.dataTableExt.oSort['string-case-asc']  = function(x,y) {
        return ((x < y) ? -1 : ((x > y) ?  1 : 0));
    };
			
    jQuery.fn.dataTableExt.oSort['string-case-desc'] = function(x,y) {
        return ((x < y) ?  1 : ((x > y) ? -1 : 0));
    };
			
    $(document).ready(function() {
        /* Build the DataTable with third column using our custom sort functions */
        $('#example').dataTable( {
            "aaSorting": [ [0,'asc'], [1,'asc'] ],
            "aoColumnDefs": [
                { "sType": 'string-case', "aTargets": [ 2 ] }
            ]
        } );
    } );
</script>

<div class="row">
  <div class="large-6 columns">
    <ul class="inline-list">
      <li>
        <a href="#" class="button dropdown" data-dropdown="drop1">Show</a>
        <ul id="drop1" class="f-dropdown">
          <li><a href="#">Item 1</a></li>
          <li><a href="#">Item 2</a></li>
          <li><a href="#">Item 3</a></li>
        </ul>
      </li>
    </ul>
  </div>
</div>
<form class="custom">
    <table id="example" >
        <thead>
            <tr>
                <?php foreach ($header as $item) { ?>
                    <th><smaller><?php echo $item ?></smaller></th>
        <?php } ?>
        </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $item) { ?>
                <tr>
                    <?php foreach ($item as $unit) { ?>
                        <td><smaller><?php echo $unit ?></smaller></td>
            <?php } ?>
            </tr>
        <?php } ?>
        </tbody>
        <tfoot>
        </tfoot>
    </table>
</form>
<script>
    $(document).ready(function() 
    { 
        $("#myTable").tablesorter(); 
    } 
); 
   
</script>