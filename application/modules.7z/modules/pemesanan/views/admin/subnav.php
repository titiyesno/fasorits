<div class="section-container accordion oxigenfontblue" data-section="accordion" style="margin-top: 50px;">
    <section >
       <p class="title" data-section-title><a href="#">Periode</a></p>
        <div class="content" data-section-content>
            <p><a href="<?php echo base_url();?>index.php/pemesanan/admin/periode">Semua Periode</a></p>
            <?php foreach ($tahun as $data){?>
            <p><a href="<?php echo base_url();?>index.php/pemesanan/admin/tahunperiode/<?php echo $data->TAHUN; ?>"><?php echo $data->TAHUN; ?></a></p>
            <?php }?>
        </div>
    </section>
    <section >
        <p class="title" data-section-title><a href="#">Pendaftaran</a></p>
        <div class="content" data-section-content>
            <p><a href="<?php echo base_url();?>index.php/pemesanan/admin/pendaftaran_rekap">Rekap Pendaftaran</a></p>
            <p><a href="<?php echo base_url();?>index.php/pemesanan/admin/registrasi">Registrasi</a></p>
        </div>
    </section>
    <section >
        <p class="title" data-section-title><a href="<?php echo base_url();?>index.php/pemesanan/admin/perpanjangan">Perpanjangan</a></p>
        <div class="content" data-section-content>
            <p><a href="<?php echo base_url();?>index.php/kamar/admin/daftar_jeniskamar">Daftar Jenis Kamar</a></p>
            <p><a href="<?php echo base_url();?>index.php/kamar/admin/tambah_jeniskamar">Tambah Jenis Kamar</a></p>
        </div>
    </section>
    
    <section >
        <p class="title" data-section-title><a href="<?php echo base_url();?>index.php/pemesanan/admin/pindahkamar">Pindah Kamar</a></p>
        <div class="content" data-section-content>
          <p><a href="<?php echo base_url();?>index.php/kuisioner/admin">Daftar Kuisioner</a></p>
          <p><a href="<?php echo base_url();?>index.php/kuisioner/admin/isikuisioner">Isi Kuisioner</a></p>
        </div>
    </section>
</div>