<form method="POST" action="tambahperiode" class="custom">
    <div class="row oxigenfontblue" style="min-height: 500px">
        <div class="large-12 columns">
            <div class="row">
                <center><h3 class="oxigenfontblue">Periode Submit Permohonan<br/> Pendaftaran, Perpanjangan, dan Pindah Kamar</h3></center>
                <hr/>
            </div>
            <div class="row" style="min-height: 100px;">
                <div class="large-6 columns">
                    <center><img style="height: 200px" src="<?php echo base_url()?>assets/web_statis/img/icon-calender.png"/></center>
                </div>
                <div class="large-6 columns">
                    <div class="row">
                        <div class="large-6 columns">
                            <input type="text" id="dp1" name="mulai" placeholder="Tanggal Mulai"/>
                        </div>
                        <div class="large-6 columns">
                            <input type="text" id="dp2" name="akhir" placeholder="Tanggal Berakhir"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-12 columns">
                            <textarea name="nama" style="max-width: 500px; max-height: 100px" placeholder="Nama dan Keterangan Periode"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="large-12 columns">
                            <input type="submit" name="submit" value="Tambah Periode" class="right button small"/>
                        </div>
                    </div>
                </div>

            </div>
            <hr/>
            <div class="row">
                <table style="width: 100%">
                    <thead>
                        <tr>   
                            <th style="width: 10%"><center>No</center></th>
                    <th style="width: 20%"><center>Tanggal Mulai</center></th>
                    <th style="width: 20%"><center>Tanggal Selesai</center></th>
                    <th style="width: 40%"><center>Nama Periode</center></th>
                    <th style="width: 10%"><center>Jumlah</center></th>
                    <tr/>
                    </thead>
                    <tbody>
                        <?php
                        $d = 1;
                        foreach ($periode as $data) {
                            ?>
                            <tr>
                                <td ><center><?php echo $d; ?></center></th>
                        <td ><center><?php echo $data->TANGGAL_MULAI; ?></center></td>
                        <td ><center><?php echo $data->TANGGAL_SELESAI; ?></center></td>
                        <td ><center><?php echo $data->NAMA_PERIODE; ?></center></td>
                        <td ><center><?php echo $data->COUNT; ?></center></td>
                        </tr>
                        <?php
                        $d++;
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</form>
<script>
    $(function() {
        window.prettyPrint && prettyPrint();
        $('#dp1').fdatepicker({
            format: 'yyyy-mm-dd'
        });
        $('#dp2').fdatepicker({
            format: 'yyyy-mm-dd'
        });
    });
</script>
