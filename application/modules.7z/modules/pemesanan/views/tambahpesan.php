<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Tambah Tiket</title>
    </head>
    <body>
        <?php echo form_open('pemesanan/tambah'); ?>
        <table>
            <tr>
                <td> Aplikan </td>
                <td>
                    <select name="idaplikan">
                    <?php foreach ($id_aplikan as $row) {?>
                    <option value="<?php echo $row->ID_APLIKAN ?>"><?php echo $row->NAMA_APLIKAN; ?></option>
                    <?php } ?>
                </select>
                </td>
            </tr>
            <tr>
                <td> Gedung </td>
                <td>
                    <select name="idgedung">
                    <?php foreach ($id_gedung as $row) {?>
                    <option value="<?php echo $row->ID_GEDUNG ?>"><?php echo $row->NAMA_GEDUNG; ?></option>
                    <?php } ?>
                </select>
                </td>
            </tr>
            <tr>
                <td> Kamar </td>
                <td>
                    <select name="idkamar">
                    <?php foreach ($id_kamar as $row) {?>
                    <option value="<?php echo $row->ID_KAMAR ?>"><?php echo $row->NOMER_KAMAR; ?></option>
                    <?php } ?>
                </select>
                </td>
            </tr>
            <tr>
                <td>Tanggal Masuk</td>
                <td>
                    <select name="tglmulai">
                    <?php foreach ($id_periode as $row) {?>
                    <option value="<?php echo $row->ID_PERIODE ?>"><?php echo $row->TANGGAL_MULAI; ?></option>
                    <?php } ?>
                </select>
                </td>
            </tr>
            <tr>
                <td>Tanggal Keluar</td>
                <td>
                    <select name="tglselesai">
                    <?php foreach ($id_periode1 as $row) {?>
                    <option value="<?php echo $row->ID_PERIODE ?>"><?php echo $row->TANGGAL_SELESAI; ?></option>
                    <?php } ?>
                </select>
                </td>
            </tr>
            <tr>
                <td>Peralatan Tambahan</td>
                <td>
                    <select name="peralatan">
                    <?php foreach ($id_peralatan as $row) {?>
                    <option value="<?php echo $row->ID_PERALATAN ?>"><?php echo $row->NAMA_PERALATAN; ?></option>
                    <?php } ?>
                </select>
                </td>
            </tr>
            <tr>
                <td> <?php echo form_submit('submit', 'Tambah'); ?> </td>
            </tr>
        </table>
        <?php echo form_close(); ?>

    </body>
</html>
