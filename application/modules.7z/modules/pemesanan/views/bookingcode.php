<section class="content-header">
    <h1>
        Kode Booking
        <small>Reservasi</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Reservasi</li>
    </ol>
</section>

<div class="container">
    <div class="col-sm-10">
        <center>
            <div class="callout callout-danger">
                <h5>Kode Booking Anda</h5>
                <h4><?php if(isset($booking_code["booking_code"]))echo $booking_code["booking_code"];
                else echo $booking_code;?></h4>
                <p>Simpanlan Booking Code ini untuk melakukan pengecekan pengumuman penerimaan Asrama ITS Surabaya</p>
                <p>Silahkan Menunggu Pengumuman Penerimaan Penghuni Asrama atau Anda bisa Datang ke Kantor Asrama untuk Melakukan Pengecekan secara Cepat</p>                                
            </div>
        </center>
    </div>
</div>
