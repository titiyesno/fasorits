<html>
<head>
  <title>Success!</title>
</head>
<body>
  <h1>Success!</h1>
  <p>Thanks, <?php echo $name; ?>!</p>
</body>
</html>
