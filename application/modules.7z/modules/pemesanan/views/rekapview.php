<div class="row shadowborder">
    <div class="large-12 columns">

        <table>
            <thead>
                <tr>
                    <th>NRP</th>
                    <th>Nama Aplikan</th>
                    <th>Program Diterima</th>
                    <th>Gedung</th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pesan as $row) { ?>
                    <tr>
                        <td><?php echo $row->NRP_APLIKAN; ?></td>
                        <td><?php echo $row->NAMA_APLIKAN; ?></td>
                        <td><?php echo $row->PROGRAM_DITERIMA; ?></td>
                        <td><?php echo $row->NAMA_GEDUNG; ?></td>
                        <td><input type="submit" class="small button" value="Comfirm"></td>
                        <td><input style="background-color: yellow; color: #FF0000" type="submit" class="small button" value="Waiting list"></td>  
                        <td><input style="background-color: #FF0000" type="submit" class="small button" value="Reject"></td>  
                    </tr>
                <?php } ?>
            </tbody>    
        </table>
    </div>
</div>