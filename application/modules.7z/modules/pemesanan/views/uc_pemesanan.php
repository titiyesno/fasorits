<div class="tabs">
    <ul class="nav nav-tabs">
        <li class="active"><a href="#tab4-1" data-toggle="tab"><i class="icon-star"></i>Umum</a></li>
        <li class=""><a href="#tab4-2" data-toggle="tab">Dosen, Tenaga Kependidikan, dan Mahasiswa</a></li>
        <li class=""><a href="#tab4-3" data-toggle="tab">Khusus</a></li>
    </ul>
    <div class="tab-content">
        <div class="active tab-pane" id="tab4-1">
            <form method="POST" action="<?php echo site_url() ?>/pemesanan/u/umum">
                <div class="form-group">
                    <label>No KTP/SIM</label>
                    <input class="form-control" type="text" name="noid" placeholder="Isi dengan no KTP atau NRP anda" />
                </div>
                <div class="form-group">
                    <label>Nama </label>
                    <input class="form-control" type="text" name="nama" placeholder="Isi dengan nama anda" />
                </div>
                <div class="form-group">
                    <label>Telepon </label>
                    <input class="form-control" type="text" name="telp"  placeholder="Isi dengan telepon anda" />
                </div>
                <div class="form-group">
                    <label>Email </label>
                    <input class="form-control" type="email" name="email"  placeholder="Isi dengan email anda" />
                </div>
                <div class="form-group">
                    <label>Tanggal</label>
                    <div class='input-group date' id='datetimepicker5'>
                        <input type='text' name="date" readonly="" class="form-control" />
                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div>
                </div>
                <div class="form-group">
                    <label>Lapangan </label>
                    <select class="form-control" name="jenis">
                        <?php foreach ($olahraga as $data2) { ?>
                            <option value="<?php echo $data2->id; ?>"><?php echo $data2->nama; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Slot </label>
                    <select class="form-control" name="slot">
                        <?php foreach ($slot as $data3) { ?>
                            <option value="<?php echo $data3->slot; ?>" <?php if($data3->slot==1) echo "DISABLED"?>><?php echo $data3->start . " - " . $data3->nama . "  ( " . $data3->start . ":00-" . $data3->end . ":00 )"; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Alamat </label>
                    <textarea class="form-control" style="max-width: 100%" type="text" name="alamat"  placeholder="Isi dengan alamat anda" > </textarea>
                </div>
                <div class="form-group">

                    <input class="btn btn-info"  type="submit" name=""  placeholder="Isi dengan email anda" />
                </div>
            </form>
        </div>
        <div class="tab-pane" id="tab4-2">
            <form method="POST" action="<?php echo site_url() ?>/pemesanan/u/akademik">
                <div class="active tab-pane" id="tab4-1">
                    <div class="form-group">
                        <label>NRP/NIP</label>
                        <input class="form-control" type="text" name="noid" placeholder="Isi dengan no NRP anda" />
                    </div>
                    <div class="form-group">
                        <label>Nama </label>
                        <input class="form-control" type="text" name="nama" placeholder="Isi dengan nama anda" />
                    </div>
                    <div class="form-group">
                        <label>Telepon </label>
                        <input class="form-control" type="text" name="telp"  placeholder="Isi dengan telepon anda" />
                    </div>
                    <div class="form-group">
                        <label>Email </label>
                        <input class="form-control" type="email" name="email"  placeholder="Isi dengan email anda" />
                    </div>
                    <div class="form-group">
                        <label>Tanggal Acara</label>
                        <div class='input-group date' id='datetimepicker6'>
                            <input type='text' name="date" readonly="" class="form-control" />
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Keperluan </label>
                        <select class="form-control" name="jenis">
                            <?php foreach ($acara as $data2) { ?>
                                <option value="<?php echo $data2->idjenis_acara; ?>"><?php echo $data2->nama; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Slot </label>
                        <select class="form-control" name="slot">
                            <?php foreach ($slot as $data3) { ?>
                                <option value="<?php echo $data3->slot; ?>"><?php echo $data3->start . " - " . $data3->nama . "  ( " . $data3->start . ":00-" . $data3->end . ":00 )"; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Alamat </label>
                        <textarea class="form-control" style="max-width: 100%" type="text" name="alamat"  placeholder="Isi dengan alamat anda" > </textarea>
                    </div>
                    <div class="form-group">

                        <input class="btn btn-info"  type="submit" name=""  placeholder="Isi dengan email anda" />
                    </div>
                </div>
            </form>
        </div>
        <div class="tab-pane" id="tab4-3">
            <form method="POST" action="<?php echo site_url() ?>/pemesanan/u/khusus">
                <div class="active tab-pane" id="tab4-1">
                    <div class="form-group">
                        <label>No ID</label>
                        <input class="form-control" type="text" name="noid" placeholder="Isi dengan no NRP anda" />
                    </div>
                    <div class="form-group">
                        <label>Nama </label>
                        <input class="form-control" type="text" name="nama" placeholder="Isi dengan nama anda" />
                    </div>
                    <div class="form-group">
                        <label>Telepon </label>
                        <input class="form-control" type="text" name="telp"  placeholder="Isi dengan telepon anda" />
                    </div>
                    <div class="form-group">
                        <label>Email </label>
                        <input class="form-control" type="email" name="email"  placeholder="Isi dengan email anda" />
                    </div>
                    <div class="form-group">
                        <label>Tanggal Mulai</label>
                        <input type='date' name="date" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Tanggal Selesai</label>
                        <input type='date' name="date" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Hari</label>
                        <select class="form-control" name="jenis">
                            <option>Senin</option>
                            <option>Selasa</option>
                            <option>Rabu</option>
                            <option>Kamis</option>
                            <option>Jumat</option>
                            <option>Sabtu</option>
                            <option>Minggu</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Slot </label>
                        <select class="form-control" name="slot">
                            <?php foreach ($slot as $data3) { ?>
                                <option value="<?php echo $data3->slot; ?>"><?php echo $data3->start . " - " . $data3->nama . "  ( " . $data3->start . ":00-" . $data3->end . ":00 )"; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Alamat </label>
                        <textarea class="form-control" style="max-width: 100%" type="text" name="alamat"  placeholder="Isi dengan alamat anda" > </textarea>
                    </div>
                    <div class="form-group">

                        <input class="btn btn-info"  type="submit" name=""  placeholder="Isi dengan email anda" />
                    </div>
                </div>
            </form>
        </div>
    </div>							
</div>


<script type="text/javascript">
    var disabledDays = [
<?php
foreach ($data as $item) {
    echo '"', $item->date . '",';
}
?>
    ];
    $(function () {

        $('#datetimepicker5').datepicker({
            format: 'yyyy-mm-dd',
            beforeShowDay: daysDisabled
        });
        $('#datetimepicker6').datepicker({
            format: 'yyyy-mm-dd',
            beforeShowDay: daysDisabled
        });
    });
    function daysDisabled(date) {
        for (var i = 0; i < disabledDays.length; i++) {
            if (new Date(disabledDays[i]).toString() === date.toString()) {
                return false;
            }
        }
        return true;

    }
</script>