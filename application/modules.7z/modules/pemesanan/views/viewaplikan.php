<section class="content-header">
    <h1>
        Profil Aplikan <?php echo $aplikan[0]->NRP_APLIKAN; ?>
        <small>View and Update Data</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo base_url("index.php/pemesanan/aplikan") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Aplikan</li>
        <li class="">Profil</li>
    </ol>
</section>
<section class="content">
    <?php  if ($aplikan[0]->STATUS_SUBMIT == "daftar") { ?>
        <div  class="col-lg-12 col-md-12  col-sm-12 col-xs-12">
            <div class="col-md-6 col-sm-12">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Scanned Identity</h3>
                    </div>
                    <div class="box-body">
                        <div class="form-group">			
                            <img src="<?php echo base_url("content/aplikan/uploads/" . $aplikan[0]->COPY_KTP); ?>" alt="..." class="img-thumbnail" style="max-width: 100%" >
                            <img src="<?php echo base_url("content/aplikan/uploads/" . $aplikan[0]->COPY_KTM); ?>" alt="..." class="img-thumbnail" style="max-width: 100%px" >
                            <img src="<?php echo base_url("content/aplikan/uploads/" . $aplikan[0]->COPY_FOTO); ?>" alt="..." class="img-thumbnail" style="max-width: 100%" >
                        </div>
                    </div>
                </div>
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Reservasi</h3>
                    </div>
                    <div class="box-body">
                        <div class="callout callout-<?php
                        if (count($available)>0 && $available[0]->AVAILABLE > 0)
                            echo "activ";
                        else
                            echo "danger";
                        ?>">
                            <h4>Pemberitahuan</h4>
                            <p><?php
                                if (count($available)>0 && $available[0]->AVAILABLE > 0)
                                    echo "Room is Available";
                                else
                                    echo "Kamar tidak Tersedia " . '<a href="' . base_url() . 'index.php/pindahkamar/admin/pilihkamar/' . $aplikan[0]->NRP_APLIKAN . '">Pindah Kamar</a>';
                                ?></p>
                        </div>
                        <div class="form-group">
                            <label >
                                Nomer Kamar
                            </label>
                            <input class="form-control" type="text" value="<?php echo $aplikan[0]->NOMER_KAMAR; ?>" disabled/>                            
                        </div>
                        <div class="form-group">
                            <label >
                                Nama Gedung
                            </label>
                            <input class="form-control" type="text" value="<?php echo $aplikan[0]->NAMA_GEDUNG; ?>" disabled/>                            
                        </div>
                        <div class="form-group">
                            <label >
                                Lantai
                            </label>
                            <input class="form-control" type="text" value="<?php echo $aplikan[0]->LANTAI; ?>" disabled/>                            
                        </div>
                        <div class="form-group">
                            <label >
                                Jenis Kamar
                            </label>
                            <input class="form-control" type="text" value="<?php echo $aplikan[0]->nama_jenis_kamar; ?>" disabled/>                            
                        </div>
                        <div class="form-group">
                            <label >
                                Bulan Masuk
                            </label>
                            <input class="form-control" type="text" value="<?php
                            echo
                            date('F', mktime(0, 0, 0, $aplikan[0]->BULAN_MASUK, 10));
                            ?>" disabled/>                            
                        </div>
                    </div>
                </div>
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Persetujuan</h3>
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            <?php
                            echo form_open("pemesanan/admin/approval");
                            ?>
                            <input type="radio" name="pindah_pagu" value="1"/>Pindah Pagu 
                            <input type="radio" name="pindah_pagu" value="0"/>Reguler <br/>
                            <input type="hidden" value="<?php echo $aplikan[0]->ID_SUBMIT; ?>" name="id_submit"/>
                            <input type="hidden" value="<?php echo $aplikan[0]->NRP_APLIKAN; ?>" name="nrp"/>     
                            <input type="submit" name="approve" class="btn btn-success" value="Approve"/>
                            <a href="<?php echo base_url("index.php/pemesanan/admin/reject2/".$aplikan[0]->ID_SUBMIT)?>" class="btn btn-danger">
					Reject Mahasiswa
						</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Informations</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->

                    <div class="box-body">
                        <div class="form-group">
                            <label for="nama" >
                                NAMA <small>required</small>
                            </label>
                            <input class="form-control" type="text" placeholder="Nama" value="<?php echo $aplikan[0]->NAMA_APLIKAN; ?>" readonly="" id="nama" name="nama" required autocomplete="off"/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="dp1">
                                Tempat Lahir <small>required</small>
                            </label>
                            <input type="text" name="tempat" class="form-control" value="<?php echo $aplikan[0]->TEMPAT_LAHIR_APLIKAN; ?>" readonly="" placeholder="Tempat Lahir" id="tempat" required autocomplete="off"/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label >
                                Tanggal Lahir <small>required</small>
                            </label>
                            <input type="text" value="<?php echo $aplikan[0]->TGL_LAHIR_APLIKAN; ?>"  readonly="" name="ttl_t" class="form-control" data-inputmask="'alias': 'yyyy/mm/dd'" data-mask="">
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="x1" >
                                Jenis Kelamin <small>required</small>
                            </label>
                            <input type="text" class="form-control" placeholder="Tanggal Lahir" value="<?php echo $aplikan[0]->JENIS_KEL_APLIKAN; ?>"  disabled/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="agama">
                                Agama <small>required</small>
                            </label>
                            <input type="text" class="form-control" placeholder="Tanggal Lahir" value="<?php echo $aplikan[0]->AGAMA_APLIKAN; ?>"  disabled/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="alamat">
                                Alamat <small>required</small>
                            </label>
                            <textarea class="form-control" placeholder="Alamat" id="alamat" name="alamat" disabled><?php echo $aplikan[0]->ALAMAT_APLIKAN; ?></textarea>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="telp">
                                Telp <small>required</small>
                            </label>
                            <input class="form-control" type="tel" placeholder="Telepon Aplikan" value="<?php echo $aplikan[0]->TELP_APLIKAN; ?>" id="telp" name="telp" disabled/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="fakultas">
                                Fakultas <small>required</small>
                            </label>
                            <input type="text" placeholder="Fakultas" class="form-control" id="fakultas" value="<?php echo $aplikan[0]->FAKULTAS_APLIKAN; ?>" name="fakultas" disabled/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="jurusan">
                                Jurusan <small>required</small>
                            </label>
                            <input type="text" placeholder="Jurusan" id="jurusan" class="form-control" value="<?php echo $aplikan[0]->JURUSAN_APLIKAN; ?>" name="jurusan" disabled/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="programditerima">
                                Program Diterima <small>required</small>
                            </label>
                            <input type="text" class="form-control" placeholder="Fakultas" value="<?php echo $aplikan[0]->PROGRAM_DITERIMA; ?>"  disabled/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="parrent_name" >
                                Nama Orangtua <small>required</small>
                            </label>
                            <input type="text" class="form-control" placeholder="Telepon Aplikan" value="<?php echo $aplikan[0]->NAMA_ORANGTUA; ?>" id="parrent_name" name="parrent_name" disabled/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="parrent_address">
                                Alamat Orangtua <small>required</small>
                            </label>
                            <textarea placeholder="Alamat Orangtua" class="form-control" id="parrent_address"  name="parrent_address" disabled><?php echo $aplikan[0]->ALAMAT_ORANGTUA; ?></textarea>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="parrent_telp">
                                Telp Orangtua <small>required</small>
                            </label>
                            <input class="form-control" type="tel" placeholder="Telepon Orangtua" value="<?php echo $aplikan[0]->TELP_ORANGTUA; ?>" id="parrent_telp" name="parrent_telp" disabled/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="parrent_job">
                                Pekerjaan Orangtua <small>required</small>
                            </label>
                            <input class="form-control" type="text" placeholder="Pekerjaan Orangtua" value="<?php echo $aplikan[0]->PEKERJAAN_ORANTUA; ?>" id="parrent_job" name="parrent_job" disabled/>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="parrent_income">
                                Penghasilan Orangtua/Bulan <small>required</small>
                            </label>
                            <input class="form-control" type="text" placeholder="Penghasilan Orangtua" value="Rp. <?php echo $aplikan[0]->PENGHASILAN_ORANGTUA; ?>" id="parrent_job" name="parrent_income" disabled/>
                            <div class="help-block with-errors"></div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </section>


    <?php
} else {
    ?>
    <div class="row">
        <div class="large-12 columns" style="min-height: 400px">
            <center>
                <h3 class="oxigenfontblue">Your Booking Code</h3>
                <h1 class="oxigenfontblue"><?php echo $aplikan[0]->CODE_BOOKING; ?></h1>
                <h6 class="oxigenfontblue">
                    Telah Disetujui Diterima Oleh Admin
                </h6>
            </center>
        </div>
    </div>
<?php }
?>
</div>
<script>
    $(function() {
        window.prettyPrint && prettyPrint();
        $('#dp1').fdatepicker({
            format: 'yyyy-mm-dd'
        });
    });
    s
</script>
