<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class aplikan_model extends CI_model {

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function insert($data) {
        $insert = $this->db->insert('aplikan', $data);
        return $insert;
    }

    public function getData() {
        $sql = 'select submit.TANGGAL_SUBMIT,submit.STATUS_SUBMIT,aplikan.NAMA_APLIKAN, aplikan.NRP_APLIKAN, aplikan.JURUSAN_APLIKAN, aplikan.JENIS_KEL_APLIKAN, aplikan.PROGRAM_DITERIMA, aplikan.ALAMAT_APLIKAN, aplikan.TELP_APLIKAN,jenis_kamar.nama_jenis_kamar,kamar.NOMER_KAMAR,periode.NAMA_PERIODE from 
			submit inner join aplikan on(submit.ID_APLIKAN=aplikan.ID_APLIKAN)
					 inner join kamar on (kamar.ID_KAMAR=submit.ID_KAMAR)
					 inner join jenis_kamar on (kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar)
					 inner join periode on (submit.ID_PERIODE=periode.ID_PERIODE)
					 inner join pengelola on (submit.ID_PENGELOLA = pengelola.ID_PENGELOLA)
					 inner join jenis_submit on (submit.ID_JENIS_SUMBIT = jenis_submit.ID_JENIS_SUMBIT);
					 ';
        $result = $this->query($sql);
        return $result->result();
    }

    function getEmail($codebooking) {
        $sql = 'select akun.EMAIL from akun where akun.USERNAME=?';
        return $this->query($sql, $codebooking);
    }

    function readaplikan($id_akun) {
        $sql = "select *, DATE_FORMAT(aplikan.TGL_LAHIR_APLIKAN,'%d %M %Y') as 'TGL_LAHIR_APLIKAN'
                from 
                aplikan right join submit on (aplikan.ID_APLIKAN=submit.ID_APLIKAN)
                left join kamar on (submit.ID_KAMAR=kamar.ID_KAMAR)
                left join jenis_kamar on (kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar)
                left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG)
                where submit.ID_APLIKAN=?
                order by submit.TANGGAL_SUBMIT DESC
                limit 1
                ";
        return $this->query($sql, array($id_akun));
    }

    function getaplikan($id) {
        $sql = "select * from aplikan where id_aplikan=?";
        return $this->query($sql, array($id));
    }

}
