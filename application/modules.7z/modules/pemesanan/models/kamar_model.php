<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class kamar_model extends CI_model {

    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    public function getKamarbyId($nomer)
    {
        $sql = "select kamar.NOMER_KAMAR, gedung.NAMA_GEDUNG from kamar left join gedung on (gedung.ID_GEDUNG=kamar.ID_GEDUNG) where kamar.ID_KAMAR=?";
        $result = $this->query($sql, array($nomer));
        $blog=  explode(" ", $result[0]->NAMA_GEDUNG);
        return $blog[1].$result[0]->NOMER_KAMAR;
    }
    public function index($id_kamar){
        $sql='select ifnull(count(submit.ID_SUBMIT),0) as Y from current_periode right join submit  on (current_periode.ID_PERIODE=submit.ID_PERIODE) where submit.ID_KAMAR= ? group by submit.ID_KAMAR';
        $result = $this->query($sql, array($sql));
        if(count($result)==0) return 0;
        return $result[0]->Y;
    }

    public function getJenisKamar($program_diterma, $jenis_kelamin) {
        /* $sql = "select available_room.*, view_jenis_kamar.*, sum(available_room.AVAILABLE) from available_room left join view_jenis_kamar on (view_jenis_kamar.nama_jenis_kamar=available_room.nama_jenis_kamar)
          group by available_room.id_jenis_kamar"; */
        $program_diterma="%".$program_diterma."%";
        $jenis_kelamin="%".$jenis_kelamin."%";
        $sql = "select DISTINCT kamar.ID_KAMAR, available_room.*, gedung.*, sum(available_room.AVAILABLE)  as 'AVAILABLE', view_jenis_kamar.*
from available_room 
inner join kamar on (available_room.ID_KAMAR=kamar.ID_KAMAR) 
left join gedung on (gedung.ID_GEDUNG=kamar.ID_GEDUNG)
left join view_jenis_kamar on (view_jenis_kamar.nama_jenis_kamar=available_room.nama_jenis_kamar)
where gedung.JENIS_GEDUNG LIKE ? and gedung.JENIS_GEDUNG LIKE ?
group by kamar.ID_JENIS_KAMAR";
        return $this->query($sql, array($program_diterma,$jenis_kelamin));
    }

    public function getGedung() {
        $sql = "select gedung.ID_GEDUNG, gedung.NAMA_GEDUNG from gedung";
        return $this->query($sql);
    }

    public function getKamar() {
        $sql = "select kamar.NOMER_KAMAR, jenis_kamar.nama_jenis_kamar, jenis_kamar.nama_jenis_kamar, jenis_kamar.quota_kamar, jenis_kamar.harga_kamar from kamar, jenis_kamar where kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar and kamar.LANTAI=1 and kamar.ID_GEDUNG=2";
        return $this->query($sql);
    }

    public function getLantai() {
        $sql = "select DISTINCT(kamar.LANTAI) as lantai from kamar order by kamar.LANTAI ASC";
        return $this->query($sql);
    }
    public function getDataAllKamar($jenis_kelamin) {
    
    	$sql = "select DISTINCT SUM(available_room.AVAILABLE) as '_AVAILABLE', view_jenis_kamar.nama_jenis_kamar, view_jenis_kamar.id_jenis_kamar from available_room inner join kamar on (available_room.ID_KAMAR=kamar.ID_KAMAR) left join gedung on (gedung.ID_GEDUNG=kamar.ID_GEDUNG) left join view_jenis_kamar on (view_jenis_kamar.nama_jenis_kamar=available_room.nama_jenis_kamar)
where gedung.JENIS_GEDUNG LIKE '%$jenis_kelamin%'
group by kamar.ID_JENIS_KAMAR
    	";
    	return $this->query($sql);
    }
    public function getsumit() {
        $sql = "select submit.ID_SUBMIT, submit.BULAN_MASUK, submit.TANGGAL_SUBMIT, submit.STATUS_SUBMIT,aplikan.NAMA_APLIKAN, aplikan.NRP_APLIKAN, aplikan.PROGRAM_DITERIMA, aplikan.NRP_APLIKAN,jenis_kamar.nama_jenis_kamar, kamar.NOMER_KAMAR, kamar.LANTAI, gedung.NAMA_GEDUNG, periode.NAMA_PERIODE 
        from submit, aplikan, kamar, jenis_kamar, periode,jenis_submit, gedung
        where submit.ID_APLIKAN=aplikan.ID_APLIKAN and submit.ID_KAMAR=kamar.ID_KAMAR and kamar.ID_JENIS_KAMAR=jenis_kamar.id_jenis_kamar
        and kamar.ID_GEDUNG=gedung.ID_GEDUNG and submit.ID_JENIS_SUMBIT=jenis_submit.ID_JENIS_SUMBIT and submit.ID_PERIODE=periode.ID_PERIODE";
        return $this->query($sql);
    }

    public function getDataKamar($jenis_kamar, $program_diterma, $jenis_kelamin) {

        $sql = "select DISTINCT kamar.ID_KAMAR, kamar.*,  available_room.*, gedung.*, available_room.AVAILABLE as '_AVAILABLE', view_jenis_kamar.* from available_room inner join kamar on (available_room.ID_KAMAR=kamar.ID_KAMAR) left join gedung on (gedung.ID_GEDUNG=kamar.ID_GEDUNG) left join view_jenis_kamar on (view_jenis_kamar.nama_jenis_kamar=available_room.nama_jenis_kamar) 
where kamar.id_jenis_kamar='$jenis_kamar' and gedung.JENIS_GEDUNG LIKE '%$program_diterma%' and gedung.JENIS_GEDUNG LIKE '%$jenis_kelamin%'
    group by kamar.ID_KAMAR
";
        
        return $this->query($sql);
    }

    public function AvailabilityRoom($room_code) {
        $sql = "select * from available_room where ID_KAMAR = ".$room_code;
//	echo $room_code.$sql;
//	echo $sql. $room_code;
        $data =  $this->query($sql);
//	print_r(count($data));
	return $data;
    }

}
