<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class akun_model extends CI_model {
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    public function getid($username){
        $sql = "select ID_AKUN from akun where USERNAME=?";
        return $this->query($sql, array($username));
        
    }

    public function insert($data){
        $result = $this->getid($data['USERNAME']);
        if(count($result)==0){
            $this->db->insert('akun',$data);
            $result = $this->getid($data['USERNAME']);
            return $result[0];
        }
        return 0;
    }
}
