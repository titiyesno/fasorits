<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class support extends MX_Controller {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $attributes = array('class' => 'email', 'id' => 'myform','data-abide');
        echo form_open('email/send', $attributes);
    }

}

?>
