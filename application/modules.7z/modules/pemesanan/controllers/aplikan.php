<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class aplikan extends Aplikan_Controller {

    private $path = "aplikan/";
    private $status_submit = array();
    private $link_gambar = "\uploads\\";

    function __construct() {
        parent::__construct();
        $this->load->driver('session');
        $this->load->library('session');
        $this->load->helper(array('url'));
        $this->load->helper("code");
        $this->load->model('pemesanan/kamar_model');
        $this->load->model('pemesanan/reservasi_model');
        $this->load->model('pemesanan/akun_model');
        $this->load->model('pemesanan/aplikan_model');
    }

    function bulan_masuk() {
        $bulan = $this->input->post("bulan");
        $codebook = $this->input->post("codebook");
        $this->reservasi_model->bulan_masuk($bulan, $codebook);
        redirect("pemesanan/aplikan/index");
    }

    function createnotifikasi() {
        $data = $this->reservasi_model->getstatus($this->session->userdata["logged_in"]["id"]);
        if (count($data) == 0)
            return null;
        if ($data[0]->STATUS_SUBMIT == "daftar") {
            $pesan["isi"] = "Anda Telah Melakukan Pendaftaran dengan Code Booking " . $data[0]->CODE_BOOKING . " Pengumuman Penerimaan akan di kirimkan lewat Email";
            $pesan["jenis"] = "success";
        } else if ($data[0]->STATUS_SUBMIT == "diterima") {
            $pesan["isi"] = "Anda Telah Melakukan Pendaftaran dengan Code Booking " . $data[0]->CODE_BOOKING . " dan Dinyatakan Diterima.<br/> MAHASISWA YANG DINYATAKAN DITERIMA  WAJIB MELAKUKAN PEMBAYARAN MAKSIMAL 3 HARI KERJA SETELAH DIUMUMKAN. PEMBAYARAN DITUJUKAN KEPADA No. Rek <b>0049842577</b> BANK BNI A.N. Rektor ITS MELALUI TELLER/LOKET BANK. Informasi Lebih Lanjut Hubungi CP Asrama. <b>Mohon Menyediakan Materai 6000 ketika daftar ulang</b>. Anda diwajibkan membayar deposito sebesar 1 bulan harga sewa kamar.";
            $pesan["jenis"] = "warning";
        } else if ($data[0]->STATUS_SUBMIT == "penghuni") {
            $pesan["isi"] = "Anda telah diterima sebagai Penghuni Asrama dan telah melakukan pembayaran dengan SISA TAGIHAN= " . $data[0]->KURANG;
            $pesan["jenis"] = "info";
        }
        return $pesan;
    }

    function index() {
        $menu = "hf/menu/menu_pemesan.php";
        $footer = "hf/footer/footer.php";
        $data["pesan"] = $this->createnotifikasi() or null;
        $data["data"] = $this->reservasi_model->getstatus($this->session->userdata["logged_in"]["id"]) or null;
        $data['angsuran'] = $this->reservasi_model->angsuran($this->session->userdata["logged_in"]["id"]);
        $this->template->set_layout('big_end');
        $this->template->title("Dashboard | Aplikan");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("home_aplikan.php", $data);
    }

    function pindahkamar() {
        $menu = "hf/menu/menu_pemesan.php";
        $footer = "hf/footer/footer.php";
        $subnav = "subnav_aplikan.php";

        $u = $this->aplikan_model->getaplikan($this->session->userdata["logged_in"]["id"]);
        $data['aplikan'] = $this->aplikan_model->readaplikan($this->session->userdata['logged_in']['id']);
        $data['kamar'] = $this->kamar_model->getDataKamar($data['aplikan'][0]->id_jenis_kamar, $u[0]->PROGRAM_DITERIMA, $u[0]->JENIS_KEL_APLIKAN);

        $this->template->set_layout('back_end');
        $this->template->title("Register Management | Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("pindah_kamar.php", $data);
    }

    function pilihjeniskamar() {

        $oo = $this->ceksubmit();
        if (isset($oo)) {
            $this->bookingcode($oo);
            return;
        }



        $this->load->library('session');
        $menu = "hf/menu/menu_pemesan.php";
        $footer = "hf/footer/footer.php";

        $u = $this->aplikan_model->getaplikan($this->session->userdata["logged_in"]["id"]);
        $data['jenis_kamar'] = $this->kamar_model->getJenisKamar($u[0]->PROGRAM_DITERIMA, $u[0]->JENIS_KEL_APLIKAN);
        $data['program_diterima'] = $u[0]->PROGRAM_DITERIMA;
        $periode = $this->reservasi_model->getperiode();
        if (count($periode) == 0) {
            $data["open"] = false;
        }
        else $data["open"] = true;
        //$data['lantai'] = $this->kamar_model->getLantai();
        $this->template->set_layout('back_end');
        $this->template->title("Pilih Kamar | ITS Student Dormmitory");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("pilihjeniskamar.php", $data);
    }

    function ceksubmit() {
        $data = $this->reservasi_model->getstatussubmitnow($this->session->userdata['logged_in']['id']);
        if (count($data) > 0) {
            return $data[0]->CODE_BOOKING;
        } else
            return null;
    }

    function pilihkamar() {
        $periode = $this->reservasi_model->getperiode();
        if (count($periode) == 1) {
            $this->load->library('session');
            $temp = $this->session->userdata("jenis_kamar");
            if (!isset($temp["id_jenis_kamar"])) {
                redirect('pemesanan/pemesan/pilihjeniskamar');
                return;
                //$temp["id_jenis_kamar"] = 3;
            }
            $u = $this->aplikan_model->getaplikan($this->session->userdata["logged_in"]["id"]);
            $data['kamar'] = $this->kamar_model->getDataKamar($temp["id_jenis_kamar"], $u[0]->PROGRAM_DITERIMA, $u[0]->JENIS_KEL_APLIKAN);

            $menu = "hf/menu/menu_pemesan.php";
            $footer = "hf/footer/footer.php";
            //$data['kamar'] = $this->reservasi_model->getkamarbyjeniskamar($this->session->userdata['jenis_kamar']['id_jenis_kamar']);
            $this->template->set_layout('big_end');
            $this->template->title("Pilih Kamar | ITS Student Dormmitory");
            $this->template->set_partial("menu", $menu);
            $this->template->set_partial("footer", $footer);
            $this->template->build("pilihkamar.php", $data);
        }
    }

    function formpilihjeniskamar() {

        $periode = $this->reservasi_model->getperiode();
        if (count($periode) == 1) {
            $this->session->unset_userdata('jenis_kamar');
            $data['id_jenis_kamar'] = $this->input->post('pilih');
            $data['pembayaran'] = $this->input->post('pembayaran');
            $data['bulanmasuk'] = $this->input->post('BULAN_MASUK');
            $this->session->set_userdata("jenis_kamar", $data);
            redirect("pemesanan/aplikan/pilihkamar");
        }
    }

    function formpilihkamar($id_kamar) {
        $periode = $this->reservasi_model->getperiode();
        if (count($periode) == 1) {
            $pendaftaran = $this->session->userdata["logged_in"]["id"];
            $jeniskamar = $this->session->userdata("jenis_kamar");
            $pembayaran = $this->session->userdata("pembayaran");
            $date = new DateTime();
            $uu = $date->getTimestamp() . $pendaftaran . $id_kamar;
            $code['booking_code'] = my_number_decrypt($uu, $pendaftaran);
            $periode = $this->reservasi_model->getperiode();
            $periode2 = $this->reservasi_model->getCodePeriode();
            $code["booking_code"] = $this->getCode($periode2,$id_kamar);
            if (isset($pendaftaran) && isset($jeniskamar) && isset($pembayaran)) {
                $data["ID_APLIKAN"] = $pendaftaran;
                $data["ID_KAMAR"] = $id_kamar;
                $data["ID_PERIODE"] = $periode[0]->ID_PERIODE;
                $data["ID_JENIS_SUMBIT"] = 1;
                $data["STATUS_SUBMIT"] = "daftar";
                $data["ANGSURAN"] = $jeniskamar["pembayaran"];
                $data["BULAN_MASUK"] = $jeniskamar["bulanmasuk"];
                $data["CODE_BOOKING"] = $code["booking_code"];
                $this->reservasi_model->insertSubmit($data);
            }
            $this->bookingcode($code);
        }
    }
    public function getCode($periode,$id_kamar){
        
        return $periode[0]->TAHUN.$this->kamar_model->getKamarbyId($id_kamar).'-'.$this->kamar_model->index($id_kamar);
    }

    public function getHTMLJenisKamar($bulan_masuk) {
        $u = $this->aplikan_model->getaplikan($this->session->userdata["logged_in"]["id"]);
        $data['jenis_kamar'] = $this->kamar_model->getJenisKamar($u[0]->PROGRAM_DITERIMA, $u[0]->JENIS_KEL_APLIKAN);
        $html = '';
        
        foreach ($data['jenis_kamar'] as $r) {
            if ($bulan_masuk < 6)
                $bulan_masuk+=12;
            $html.='<div class="col-lg-6 col-xs-6">
                            <div class="small-box bg-aqua">
                                <div class="inner">
                                    <h3>
                                        ' . $r->nama_jenis_kamar . '
                                    </h3>
                                    <p>
                                       Kuota : ' . $r->quota_kamar . ' Mahasiswa
                                    </p>
                                    <p>Harga Sewa : ' . $r->harga_kamar * (18 - $bulan_masuk +1) . ' per ' . (18 - $bulan_masuk+1) . ' Bulan<p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="#" class="small-box-footer" data-toggle="modal" data-target="#myModal">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                    <div class="modal-dialog  modal-sm">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                          <h4 class="" id="myModalLabel">' . $r->nama_jenis_kamar . '</h4>
                                        </div>
                                        <div class="modal-body">
                                          <p></p>
                                          <a href="' . base_url("content/asrama/kamar/" . $r->ALAMAT_GAMBAR) . '"><img src="' . base_url("content/asrama/kamar/" . $r->ALAMAT_GAMBAR) . '"></a>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                 &nbsp;Pilih <input type="radio" name="pilih" value="' . $r->id_jenis_kamar . '" id="pilih"><label for="pilih">&nbsp</label>
                            </div>
                        </div>';
        }
        echo $html;
    }

    public function bookingcode($code) {
        $data["booking_code"] = $code;
        $menu = "hf/menu/menu_pemesan.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('big_end');
        $this->template->title("Pilih Kamar | ITS Student Dormmitory");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("bookingcode.php", $data);
    }

    public function getsubmitdata($awal, $akhir) {
        $temp1 = $this->reservasi_model->getsubmitperiode($awal, $akhir);
        $data["submit"] = $this->getPivot($temp1);
        return $data["submit"];
    }

}
?>

