<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class pemesan extends MX_Controller {

    private $status_submit = array();
    private $link_gambar = "\uploads\\";

    function __construct() {
        parent::__construct();
        $this->load->driver('session');
        $this->load->library('session');
        $this->load->helper(array('url'));
        $this->load->library('image_lib');
        $this->load->helper("code");
        $this->load->model('pemesanan/kamar_model');
        $this->load->model('pemesanan/reservasi_model');
        $this->load->model('pemesanan/akun_model');
        $this->load->model('pemesanan/aplikan_model');
    }



}
?>

