<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class admin extends Admin_Controller {

    const IMAGE_UPLOAD_DIR = 'content/berita/gambar';
    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('berita/berita_model');
        $this->load->model('berita/gambar_model');
        $this->load->model('berita/file_berita_model');
        $this->load->library('form_validation');
        $this->load->helper('dompdf');
        $this->load->helper('file');
        $this->_supported_extensions = array('jpg', 'jpeg', 'gif', 'png', 'pdf');
    }
    private function _move_image($temp_location)
    {
        $filename = basename($temp_location['name']);
        $info = pathinfo($filename);
        $ext = strtolower($info['extension']);
        
        if (isset($temp_location['tmp_name']) &&
            isset($info['extension']) &&
            in_array($ext, $this->_supported_extensions)) {
            $new_file_path = self::IMAGE_UPLOAD_DIR . '/'  . $filename;
            if (!is_dir(self::IMAGE_UPLOAD_DIR) ||
                !is_writable(self::IMAGE_UPLOAD_DIR)) {
                // Attempt to auto-create upload directory.
                if (!is_writable(self::IMAGE_UPLOAD_DIR) ||
                    FALSE === @mkdir(base_url().self::IMAGE_UPLOAD_DIR, null , TRUE)) {
                    throw new Exception('Error: File permission issue, ' .
                        'please consult your system administrator');
                }
            }
 
            if (move_uploaded_file($temp_location['tmp_name'], $new_file_path)) {
                return base_url() . $new_file_path;
            }
        }
 
        throw new Exception('File could not be uploaded.');
    }
    private function _setup_ckeditor($id)
    {
        $this->load->helper('url');
        $this->load->helper('ckeditor');
        $ckeditor = array(
            'id' => $id,
            'path' => 'gui_modul/ckeditor',
            'config' => array(
                'toolbar' => 'Full',
                'width' => '960px',
                'height' => '400px',
                'filebrowserImageUploadUrl' => base_url("index.php/berita/admin/upload/")));
 
        return $ckeditor;
    }
public function upload()
    {
        $callback = 'null';
        $url = '';
        $get = array();
 
        // for form action, pull CKEditorFuncNum from GET string. e.g., 4 from
        // /form/upload?CKEditor=content&CKEditorFuncNum=4&langCode=en
        // Convert GET parameters to PHP variables
        $qry = $_SERVER['REQUEST_URI'];
        parse_str(substr($qry, strpos($qry, '?') + 1), $get);
 
        if (!isset($_POST) || !isset($get['CKEditorFuncNum'])) {
            $msg = 'CKEditor instance not defined. Cannot upload image.';
        } else {
            $callback = $get['CKEditorFuncNum'];
 
            try {
                $url = $this->_move_image($_FILES['upload']);
                $msg = "File uploaded successfully to: {$url}";
 
                // Persist additions to file manager CMS here.
 
            } catch (Exception $e) {
                $url = '';
                $msg = $e->getMessage();
            }
        }
 
        // Callback function that will insert image into the correct CKEditor instance
        $output = '<html><body><script type="text/javascript">' .
            'window.parent.CKEDITOR.tools.callFunction(' .
            $callback .
            ', "' .
            $url .
            '", "' .
            $msg .
            '");</script></body></html>';
 
        echo $output;
    }
 

    public function index() {
        $data['data_berita_all'] = $this->berita_model->read_all_berita();
        $data['data_jenis_all'] = $this->berita_model->read_all_jenis();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("pencarian.php", $data);
    }
    
    public function tambah() {
        $data['error'] = '';
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $data['jenis_berita'] = $this->berita_model->getAlljenisberita();
        $data = array(
                'ckeditor' => $this->_setup_ckeditor('content'),
                'content_html' => '' // your model property's HTML for CKEditor textarea
        );
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("tambahberita.php", $data);
    }

    public function simpantambah() {
        $jmlfile = $this->input->post('jmlfl');
        $judul = $this->input->post('judul');
        $text_berita = $this->input->post('editor1');
        $jenis = $this->input->post('jenis');
        $tes = $this->berita_model->get_last_id();
        $filename_foto = 'fotoberita'.$tes[0]->ID_BERITA;
        $fotober = 'fotoberita';
        $aa = $this->upload_fileberita($fotober, $filename_foto);
        if(!$aa){
            $error = array('error' => "Ukuran File Terlalu Besar / Tipe File Salah");

            $menu = "hf/menu/menu_pengelola.php";
            $footer = "hf/footer/footer.php";
            $this->template->set_layout('back_end');
            $this->template->title("Home Admin");
            $this->template->set_partial("menu", $menu);
            $this->template->set_partial("footer", $footer);
            $this->template->build("tambahberita.php", $error);
        } else {
            $idberita = $this->berita_model->create_berita($judul, $text_berita, $jenis);
            $this->gambar_model->create_gambar($idberita, NULL, $judul, $aa, NULL);
            
            for($e=0;$e<$jmlfile;$e++)
            {
                $name2='file'.($e+1);
                $temp = array();
                $tek = $this->file_berita_model->get_last_id();
                $filename_berita = $name2.$tek[0]->id_berita.$tek[0]->id_file_berita;
                $temp2 = $this->upload_fileberita($name2,$filename_berita);
                $this->file_berita_model->create_file($idberita,$temp2);
            }
            redirect("berita/admin/ubah/".$idberita);
        }
    }
    
    function upload_fileberita($name,$qq) {
            $config['upload_path'] = './assets/berita/file_berita';
            $config['allowed_types'] = 'pdf|doc|gif|jpg|png';
            $config['max_width'] = '1600';
            $config['max_height'] = '2400';
            $config['max_size'] = '10000KB';
//            $config['file_name'] = $qq;
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload($name)) {
                return false;
            } else {
                $data = array('upload_data' => $this->upload->data());
                $filename = $this->upload->file_name;
                return $filename;
            }
    }

    public function lihat($idberita = "") {
        $data["data_berita"] = $this->berita_model->read_berita_by_id($idberita);
        $data['data_foto'] = $this->gambar_model->read_gambar_by_idberita($idberita);
        $data["file"] = $this->file_berita_model->read_file_by_idberita($idberita);
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("lihatberita.php", $data);
    }

    public function daftarberita() {
        $data["list_berita"] = $this->berita_model->read_all_berita();
        $this->load->view('header');
        $this->load->view('listberita', $data);
    }

    public function ubah($idberita = "") {
        $data['error'] = array('error' => "");;
        $data["hasil"] = $this->berita_model->read_berita_by_id($idberita);
        $data["gambar"] = $this->gambar_model->read_gambar_by_idberita($idberita);
        $data["file"] = $this->file_berita_model->read_file_by_idberita($idberita);
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("ubahberita.php", $data);
    }

    public function simpanperubahan() {
        $idberita = $this->input->post('idberita');
        $judul = $this->input->post('judul');
        $text_berita = $this->input->post('editor1');
        $jenis = $this->input->post('jenis');
        
        $config['upload_path'] = './assets/berita/file_berita';
        $config['allowed_types'] = 'pdf|doc';
        $config['max_size'] = '10000KB';
        $this->load->library('upload', $config);
            if (!$this->upload->do_upload()) {
                $data["hasil"] = $this->berita_model->read_berita_by_id($idberita);
                $data["gambar"] = $this->gambar_model->read_gambar_by_idberita($idberita);
                $data["file"] = $this->file_berita_model->read_file_by_idberita($idberita);
                $data["error"] = array('error' => "Ukuran File Terlalu Besar / Tipe File Salah");
                $menu = "hf/menu/menu_pengelola.php";
                $footer = "hf/footer/footer.php";
                $this->template->set_layout('back_end');
                $this->template->title("Home Admin");
                $this->template->set_partial("menu", $menu);
                $this->template->set_partial("footer", $footer);
                $this->template->build("ubahberita.php", $data);
            } else {
                $data = array('upload_data' => $this->upload->data());
                $filename = $this->upload->file_name;
                $this->berita_model->update_berita($idberita, $judul, $text_berita, $jenis);
                $this->file_berita_model->create_file($idberita,$filename);
                redirect("berita/admin");
            }
    }

    public function hapus($idberita = "") {
        $this->berita_model->delete_berita($idberita);
        redirect("berita/admin");
    }

    public function read_by_id() {
        $idberita = $this->input->post('idberita');
        $temp = $this->berita_model->read_berita_by_id($idberita);
        $berita = $temp->row();
        $htmlres = "
                <tr>
                    <td style=\"width: 10%\">
                        Judul :
                    </td>
                    <td style=\"width: 90%\">
                        <textarea type=\"text\" name=\"judul\" value=\"\" style=\"width: 300px\">" . $berita->JUDUL . "</textarea>
                    </td>
                </tr>
                <tr>
                    <td>Jenis Berita:</td>
                    <td><input type=\"text\" name=\"jenis\" value=" . $berita->JENIS_BERITA . " style=\"width: 300px\" /></td>
                </tr>
                <tr>
                    <td>
                        Isi Berita:
                    </td>
                    <td>
                        <textarea name=\"editor1\">$berita->TEXT_BERITA</textarea>
                        <script>
                            CKEDITOR.replace( 'editor1' );
                        </script>
                    </td>
                </tr>
                <tr>
                    <td><input  type=\"hidden\" name=\"idberita\" id=\"idberita\" value=" . $berita->ID_BERITA . " /></td>
                    <td></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type=\"submit\" value=\"Simpan Perubahan\"></td>
                </tr>
            ";
        echo $htmlres;
    }

    public function pencarian() {
        $data['data_berita_all'] = $this->berita_model->read_all_berita();
        $data['data_jenis_all'] = $this->berita_model->read_all_jenis();
        $this->load->view('header');
        $this->load->view('pencarian', $data);
    }

    public function cari_all_berita() {

        $berita = $this->berita_model->read_all_berita();

        $a = 1;
        $htmlres = '';

        foreach ($berita as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $matches = array();
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" . mem('/assets/berita/gambar/$g->ALAMAT_GAMBAR')."\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "index.php/berita/admin/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "index.php/berita/admin/ubah/$p->ID_BERITA\">Ubah</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

    public function cari_berita_by_tanggal() {
        $tanggal = $this->input->post('tanggal');
        $tanggal_hasil = $this->berita_model->cari_by_tanggal($tanggal);
        $a = 1;
        $htmlres = '';
        foreach ($tanggal_hasil as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" .  mem('assets/berita/gambar/$g->ALAMAT_GAMBAR')."\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "index.php/berita/admin/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "index.php/berita/admin/ubah/$p->ID_BERITA\">Ubah</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

    public function cari_berita_by_jenis() {
        $jenis = $this->input->post('jenis');
        $jenis_hasil = $this->berita_model->cari_by_jenis($jenis);
        $a = 1;
        $htmlres = '';
        foreach ($jenis_hasil as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" .  mem('/assets/berita/gambar/$g->ALAMAT_GAMBAR')."\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "index.php/berita/admin/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "index.php/berita/admin/ubah/$p->ID_BERITA\">Ubah</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

    public function cari_berita_by_judul() {
        $judul = $this->input->post('judul');
        $judul_hasil = $this->berita_model->cari_by_judul($judul);
        $a = 1;
        $htmlres = '';
        foreach ($judul_hasil as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" .  mem('/assets/berita/gambar/$g->ALAMAT_GAMBAR')."\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "index.php/berita/admin/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "index.php/berita/admin/ubah/$p->ID_BERITA\">Ubah</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

}

?>
