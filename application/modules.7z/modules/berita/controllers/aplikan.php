<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class aplikan extends Aplikan_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('berita/berita_model');
        $this->load->model('berita/gambar_model');
        $this->load->library('form_validation');
        //tes
    }

    public function index() {
        $data['data_berita_all'] = null;// $this->berita_model->read_all_berita();
        $data['data_jenis_all'] = null;//$this->berita_model->read_all_jenis();
        $menu = "hf/menu/menu_pemesan.php";
        $subnav = "subnav_aplikan.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("pencarian.php", $data);
    }

    public function lihat($id = "") {
        $data['data_berita'] = $this->berita_model->read_berita_by_id($id);
        $data['data_foto'] = $this->gambar_model->read_gambar_by_idberita($id);
        $data["file"] = $this->file_berita_model->read_file_by_idberita($idberita);
        $menu = "hf/menu/menu_pemesan.php";
        $subnav = "subnav_aplikan.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("lihatberita.php", $data);
    }

    public function pencarian() {
        $data['data_berita_all'] = $this->berita_model->read_all_berita();
        $data['data_jenis_all'] = $this->berita_model->read_all_jenis();
        $this->load->view('header');
        $this->load->view('pencarian', $data);
    }

    public function cari_all_berita() {

        $berita = $this->berita_model->read_all_berita();

        $a = 1;
        $htmlres = '';

        foreach ($berita as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $matches = array();
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" . base_url() . "/static/images/berita/$g->ALAMAT_GAMBAR\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "/index.php/berita/admin/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

    public function cari_berita_by_tanggal() {
        $tanggal = $this->input->post('tanggal');
        $tanggal_hasil = $this->berita_model->cari_by_tanggal($tanggal);
        $a = 1;
        $htmlres = '';
        foreach ($tanggal_hasil as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" . base_url() . "/static/images/berita/$g->ALAMAT_GAMBAR\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "/index.php/berita/aplikan/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

    public function cari_berita_by_jenis() {
        $jenis = $this->input->post('jenis');
        $jenis_hasil = $this->berita_model->cari_by_jenis($jenis);
        $a = 1;
        $htmlres = '';
        foreach ($jenis_hasil as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" . base_url() . "/static/images/berita/$g->ALAMAT_GAMBAR\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "/index.php/berita/aplikan/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

    public function cari_berita_by_judul() {
        $judul = $this->input->post('judul');
        $judul_hasil = $this->berita_model->cari_by_judul($judul);
        $a = 1;
        $htmlres = '';
        foreach ($judul_hasil as $p) {
            $foto = $this->gambar_model->read_gambar_by_idberita($p->ID_BERITA);
            $g = $foto[0];
            preg_match("/<p>(.*)<\/p>/", $p->TEXT_BERITA, $matches);
            if (count($matches) > 0)
                $s = strip_tags($matches[1]);
            else
                $s = "";
            $htmlres .=
                    "   
                    <hr>    
                    <div class=\"row\" style=\"margin-bottom: 15px;\">
                        <div class=\"small-3 columns\">
                            <div class=\"row\">
                                <img style=\"margin-left:35%;\" width=120px; height=75px; src=\"" . base_url() . "static/images/berita/$g->ALAMAT_GAMBAR\">
                            </div>
                        </div>
                        <div class=\"small-9 columns\">
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"margin-bottom:5px;\">$p->JUDUL</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\" style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: justify\"> " . $s . "</div>
                            </div>
                            <div class=\"row\">
                                <div class=\"small-12 columns\">
                                    <a href=\"" . base_url() . "index.php/berita/aplikan/lihat/$p->ID_BERITA\">Read more</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            $a++;
        }
        echo $htmlres;
    }

}

?>
