<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class berita_model extends CI_model {
    
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function create_berita($judul,$teks,$jenis){
        $data = array(
            'JUDUL' => $judul,
            'TEXT_BERITA' => $teks,
            'JENIS_BERITA' => $jenis,
        );
        $this->db->insert('berita', $data);    
        return $this->db->insert_id();
    }
    
    public function read_all_berita(){
        $query = $this->db->get('berita');
        return $query->result();
    }
    
    public function read_berita_by_id($id){
        $this->db->select("*");
        $this->db->select("DATE_FORMAT(TANGGAL_BERITA,'%h:%i - %d %b %Y ') as `TANGGAL_BERITA`",FALSE);
        $this->db->where('ID_BERITA',$id);
        $query = $this->db->get('berita');
        return $query->result();
    }
    
    public function read_all_jenis()
    {
        $query = "SELECT DISTINCT jenis_berita as m FROM `berita`";
        $result = $this->db->query($query);
        return $result->result();
    }

    public function update_berita($id,$judul,$teks,$jenis){
        $data = array(
            'JUDUL' => $judul,
            'TEXT_BERITA' => $teks,
            'JENIS_BERITA' => $jenis
        );
        $this->db->where('ID_BERITA',$id);
        $result = $this->db->update('berita', $data);
        return $result; 
    }
    
    public function delete_berita($id){
        $this->db->where('ID_BERITA', $id);
        $this->db->delete('berita');
    }
    
    public function cari_by_tanggal($tanggal){
        $query = "SELECT * FROM `berita` WHERE tanggal_berita >= '$tanggal'";
        return $this->db->query($query)->result();
    }
    
    public function cari_by_jenis($jenis){
        $query = "SELECT * FROM `berita` WHERE jenis_berita = '$jenis'";
        return $this->db->query($query)->result();
    }
    
    public function cari_by_judul($judul){
        $query = "SELECT * FROM `berita` WHERE judul LIKE '%$judul%'";
        $hasil = $this->db->query($query);
        return $hasil->result();
    }
    public function getAlljenisberita(){
        $sql="select DISTINCT berita.JENIS_BERITA from berita";
        return $this->query($sql);
    }
    
    public function get_last_id() {
        $sql = "select * from berita order by berita.ID_BERITA desc limit 1";
        $result = $this->db->query($sql);
        return $result->result();
    }
    
}