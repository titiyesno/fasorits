<script type="text/javascript" src="<?php echo base_url(); ?>gui_modul/ckeditor/ckeditor.js"></script>
<section class="content-header">
    <h1>
        Berita dan Artikel
        <small>Berita, Pengumuman, dan Artikel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="">Berita</li>
        <li class="active">Tambah Berita</li>
    </ol>
</section>
<div class="content">
    <div  class="box">
        <div class="box-header"><h3 class="box-title">Tambah Berita</h3></div>
        <div class="box-body">

            <?php echo form_open_multipart('berita/admin/simpantambah'); ?>
            <div class="form-group">
                <label>Judul Berita</label>
                <input class="form-control" type="text" name="judul" required/>
            </div>
            <div class="form-group">
                <label>Content</label>
                <textarea name="content" id="content" class="form-control"><?php echo $content_html; ?></textarea>
                <?php echo display_ckeditor($ckeditor); ?>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-default"/>
            </div>
            <div class="form-group">
                <button type="button" class="button small round" onclick="addfield()">Tambah File</button>
            </div>
            <div class="form-group" id="file_section">
                <label>File Berita 1 <label>               
                <input type="file" name="file1" /><br>
                <small>Ukuran File < 1Mb, Jenis: pdf/doc </small>
            </div>
            <?php echo form_close() ?>
            
        </div>
        
    </div>
</div>

<script>
    var a = 2;
    function addfield() {
        $('#file_section').append("<label>File Berita "+a+" <label><input type=\"file\" name=\"file"+a+"\" /><br><small>Ukuran File < 1Mb, Jenis: pdf/doc </small>");
        $('#jmlfl').val(a);
        a++;
    }
</script>
