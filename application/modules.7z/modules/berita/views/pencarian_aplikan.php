<script src="<?php echo base_url(); ?>assets/web_statis/ckeditor/ckeditor.js"></script>
<script src="<?php echo base_url()?>assets/global/js/livesearch.js"></script>
<script>
    function getberita_bytanggal(){
        $.ajax({
            type: "POST",
            url: $("#cari_berita_form").attr('action'),
            data: $("#cari_berita_form").serialize(),
            success: function(data) {
                $("tbody#listberita").html(data);
                alert(data);
            }
        });
        return false;
    }
    function getberita_byjenis(){
        $.ajax({
            type: "POST",
            url: $("#cari_berita_byjenis_form").attr('action'),
            data: $("#cari_berita_byjenis_form").serialize(),
            success: function(data) {
                $("tbody#listberita").html(data);
            }
        });
        return false;
    }
    
    function getberita_byjudul(){
        $.ajax({
            type: "POST",
            url: $("#cari_berita_byjudul_form").attr('action'),
            data: $("#cari_berita_byjudul_form").serialize(),
            success: function(data) {
                $("tbody#listberita").html(data);
                //                    alert(JSON.stringify(data));
                //alert(data);
            }
        });
        return false;
    }
    
    function daftarberita(){
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>index.php/berita/<?php if (isset($this->session->userdata["logged_in"]["privilege"])) echo $this->session->userdata["logged_in"]["privilege"]; else echo "zong"; ?>/cari_all_berita",
            data: {sro-its: $.cookie('sro-its');}
            success: function(data){
                $("#listberita").html(data);
            }
        
        });
    };
    window.onload = daftarberita();
</script>
<div id="container">
    <center><h3 class="oxigenfontblue">Pencarian Berita</h3></center>
    <hr>
    <div id="body">
        <?php 
        $att = array('id'=>'cari_berita_form');
        echo form_open('berita/admin/cari_berita_by_tanggal',$att);
        ?>
            <div class="row">
                <div class="large-3 columns">
                    <label for="tanggal" class="oxigenfont right inline" style="color: black">
                        Dari Tanggal
                    </label>
                </div>
                <div class="large-3 columns">
                    <input onchange="getberita_bytanggal()" type="text" id="tanggal" name="tanggal"  />
                </div>
                <div class="large-6 columns"></div>
            </div>
        </form>
        <?php 
        $att = array('id'=>'cari_berita_byjenis_form');
        echo form_open('berita/admin/cari_berita_by_jenis',$att);
        ?>
            <div class="row">
                <div class="large-3 columns">
                    <label for="jenis" class="oxigenfont right inline" style="color: black">
                        Jenis Berita
                    </label>
                </div>
                <div class="large-3 columns">
                    <select onchange="getberita_byjenis()" class="medium"  name="jenis" id="jenis">
                        <?php foreach ($data_jenis_all as $r) { ?>
                            <option value="<?php echo $r->m; ?>" ><?php echo $r->m; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="large-6 columns"></div>
            </div>
        </form>
        <?php 
        $att = array('id'=>'cari_berita_byjudul_form');
        echo form_open('berita/admin/cari_berita_by_judul',$att);
        ?>
            <div class="row">
                <div class="large-3 columns">
                    <label for="judul" class="oxigenfont right inline" style="color: black">
                        Judul Berita
                    </label>
                </div>
                <div class="large-3 columns">
                    <input oninput="getberita_byjudul()" placeholder="Judul Berita" type="text" name="judul" value="" style="width: 300px" />
                </div>
                <div class="large-6 columns"></div>
            </div>
        </form>
        <div id="listberita" >
            <div class="row" style="margin-top: 5px;">
                <div class="small-3 columns" ></div>
                <div class="small-9 columns" >
                    <div class="row">
                        <div class="small-12 columns" ></div>
                    </div>
                    <div class="row">
                        <div class="small-12 columns" style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; padding: 10px;"></div>
                    </div>
                    <div class="row"></div>
                </div>
            </div>
        </div>
<!--        <div class="row large-12">
            <table style="width: 100%">
                <thead>
                    <tr>
                        <th>Nomor</th>
                        <th>Judul</th>
                        <th>Isi Berita</th>
                        <th>Tanggal Berita</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="listberita">
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                </tbody>
            </table>
        </div>-->
    </div>
</div>
<script>
    $(function() {
        $('#tanggal').fdatepicker({
            format: 'yyyy-mm-dd'
        });
    });
</script>
