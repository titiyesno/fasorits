<div class="section-container accordion" data-section="accordion" style="margin-top: 50px;">
    <section >
        <p class="title" data-section-title><a href="<?php echo base_url(); ?>index.php/berita/admin">Pencarian Berita</a></p>
    </section>
    <section >
        <p class="title" data-section-title><a href="<?php echo base_url(); ?>index.php/berita/admin/tambah">Tambah Berita</a></p>
    </section>
</div>