<script src="<?php echo base_url; ?>assets/web_statis/ckeditor/ckeditor.js"></script>
<script src="<?php echo base_url(); ?>assets/web_statis/ckeditor/adapters/jquery.js"></script>
<script src="<?php echo base_url(); ?>assets/global/js/jquery.js"></script>
<div id="container">
    <div class="social-sidebar">
        <div class="sidebar-button-container-outside">
            <div class="sidebar-button-container-inside">
                <div class="sharelogo"><a class="twitter popup" href="https://twitter.com/share?url=<?php echo current_url(); ?>"><img src="<?php echo base_url(); ?>assets/web_statis/img/twitkecil.jpg"></a>
                    <script>
                        $('.popup').click(function(event) {
                            var width = 575,
                                    height = 400,
                                    left = ($(window).width() - width) / 2,
                                    top = ($(window).height() - height) / 2,
                                    url = this.href,
                                    opts = 'status=1' +
                                    ',width=' + width +
                                    ',height=' + height +
                                    ',top=' + top +
                                    ',left=' + left;
                            window.open(url, 'twitter', opts);
                            return false;
                        });
                    </script>
                </div>
                <div class="sharelogo"><a href="https://plus.google.com/share?url=<?php echo current_url(); ?>" onclick="javascript:window.open(this.href,
                                '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');
                        return false;"><img
                            src="https://www.gstatic.com/images/icons/gplus-32.png" alt="Share on Google+"/></a>
                    <script type="text/javascript">
                        window.___gcfg = {
                            lang: 'en-US'
                        };
                        (function() {
                            var po = document.createElement('script');
                            po.type = 'text/javascript';
                            po.async = true;
                            po.src = 'https://apis.google.com/js/plusone.js';
                            var s = document.getElementsByTagName('script')[0];
                            s.parentNode.insertBefore(po, s);
                        })();
                    </script>
                </div>
                <div class="sharelogo"><a class="tes" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo current_url(); ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/web_statis/img/fbkecil.jpg"></a>
                    <script>
                        $('.tes').click(function(event) {
                            var width = 575,
                                    height = 400,
                                    left = ($(window).width() - width) / 2,
                                    top = ($(window).height() - height) / 2,
                                    url = this.href,
                                    opts = 'status=1' +
                                    ',width=' + width +
                                    ',height=' + height +
                                    ',top=' + top +
                                    ',left=' + left;
                            window.open(url, 'facebook', opts);
                            return false;
                        });
                    </script>
                </div>

            </div>
        </div>

    </div>
    <center><h3 class="oxigenfontblue">Detail Berita</h3></center>
    <hr>
    <div class="row">
        <div class="large-2 columns">
                <label for="" class="oxigenfont right inline" style="color: black">
                </label>
            </div>
        <div class="large-10 columns">
            <div class="row">
                <div class="large-12 columns">
                    <h4 class="oxigenfont" style="color: orange"><?php echo $data_berita[0]->JENIS_BERITA ?></h4>
                    <h1 class="oxigenfontblue"> <?php echo $data_berita[0]->JUDUL ?></h1>
                    <h5 class="oxigenfont" style="color: grey"> <?php echo $data_berita[0]->TANGGAL_BERITA ?></h5>
                </div>
            </div>
            <div class="row">
                <div class="large-4 columns"></label>
                    <img style="padding-bottom: 10px;"src="<?php echo base_url(); ?>static/images/berita/<?php echo $data_foto[0]->ALAMAT_GAMBAR ?>">
                </div>
            
                <div class="large-8 columns">
                    <?php echo $data_berita[0]->TEXT_BERITA ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
            <div class="large-2 columns">
                <label for="" class="oxigenfont right inline" style="color: black">
                </label>
            </div>
            <div class="large-10 columns"></label>
                <?php if(!empty($file)) { ?>
                    <?php foreach($file as $t) {?>
                        <div class="row">
                            <div class="large-12 columns">
                                <a href="<?php mem("assets/berita/file_berita/".$t->nama_file)?>"><?php echo $t->nama_file?></a>
                            </div>
                        </div>
                    <?php }?>
                <?php } else { ?>
                    <label for="ket" class="oxigenfont left inline" style="color: black">
                    Tidak Ada File Untuk Berita Ini
                    </label>
                <?php } ?>
            </div>
        </div>
</div>