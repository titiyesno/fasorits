<script type="text/javascript">
    function getberita_byjenis(sel) {
        var query = sel.options[sel.selectedIndex].value;
        if (query != "")
        {
            var data_pos = {
                'jenis': query,
                '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
            };
            $.ajax({
                type: "POST",
                url: "<?php echo $this->session->userdata["logged_in"]['privilege'];?>/cari_berita_by_jenis",
                data: data_pos,
                success: function(data) {
                    $("#listberita").html(data);
                }
            });
            return false;
        }
        else
            daftarberita();
    }

    function getberita_byjudul() {
        var query = $("input#judul").val()
        if (query != "")
        {
            var data_pos = {
                'judul': $("input#judul").val(),
                '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
            };
            $.ajax({
                type: "POST",
                url: "<?php echo $this->session->userdata["logged_in"]['privilege'];?>/cari_berita_by_judul",
                data: data_pos,
                success: function(data) {
                    $("#listberita").html(data);
                }
            });
            return false;
        }
        else
            daftarberita();
    }

    function daftarberita() {
        var post_data = {
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        };
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>index.php/berita/<?php
if (isset($this->session->userdata["logged_in"]["privilege"]))
    echo $this->session->userdata["logged_in"]["privilege"];
else
    echo "zong";
?>/cari_all_berita",
            data: post_data,
            success: function(data) {
                $("#listberita").html(data);
            }

        });
    }
    ;
    window.onload = daftarberita();
</script>

    <center><h3 >Pencarian Berita</h3></center>
    <hr>
    <div class="row">
        <div class="col-sm-4 col-md-4 col-lg-4">
            <div id="body">

                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-4">
                            <label for="jenis" class="" style="color: black">
                                Jenis Berita
                            </label>
                        </div>
                        <div class="col-md-8">
                            <?php
                            $attribut = array("id" => "cari_berita_byjenis_form");
                            echo form_open("", $attribut)
                            ?>
                            <select onchange="getberita_byjenis(this)" name="jenis" id="jenis">
                                <?php foreach ($data_jenis_all as $r) { ?>
                                    <option value="<?php echo $r->m; ?>" ><?php echo $r->m; ?></option>
                                <?php } ?>
                            </select>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-4">
                            <label for="judul" style="color: black">
                                Judul Berita
                            </label>
                        </div>
                        <div class="col-md-8">
                            <?php
                            $attribut = array("id" => "cari_berita_byjudul_form");
                            echo form_open("", $attribut)
                            ?>
                            <input onkeyup="getberita_byjudul()" placeholder="Judul Berita" type="text" name="judul" id="judul" value=""  />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
<!--            <div id="listberita" style="min-height: 300px">
                
            </div>-->
        </div>
    </div>

<script>
    $(function() {
        $('#tanggal').fdatepicker({
            format: 'yyyy-mm-dd'
        });
    });
</script>
