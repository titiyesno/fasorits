<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class navigasi extends MX_Controller{
    
    function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('navigasi/model_navigasi');
        $this->load->library('form_validation');
                    //tes
    }
    public function index()
    {
        $data["list_gedung"]=$this->model_navigasi->read_gedung();
        $menu = "hf/menu/menu_umum.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('front_end');
        $this->template->title("Peta Navigasi - Asrama ITS");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("mapnavigasi.php",$data);
        
//        $this->load->view('mapnavigasi',$data);
    }
    
    public function koord_gedung()
    {
        header('Cache-Control: no-cache, must-revalidate');
        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');
        $koord = $this->model_navigasi->read_koord_gedung();
        echo json_encode(array('hasil'=>$koord));
    }
    
    public function koord_gedung_by_id()
    {
        header('Cache-Control: no-cache, must-revalidate');
        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');
        $data = $this->input->post('d');
        $id = $data['idgedung'];
        $koord = $this->model_navigasi->read_koord_gedung_by_id($id);
        echo json_encode(array('hasil'=>$koord));
    }
    
}

?>
