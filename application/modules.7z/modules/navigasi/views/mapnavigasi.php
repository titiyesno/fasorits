<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&langu‌​age=id&libraries=places"></script>
<script>
    var map;
    var markers = [];
    var gedung = [];
    var geocoder = new google.maps.Geocoder();
    var rendererOptions = {
        draggable: true
    };
    var directionsDisplay = new google.maps.DirectionsRenderer(rendererOptions);
    var directionsService = new google.maps.DirectionsService();
    var infowindow = new google.maps.InfoWindow();

    function initialize() {

        var myOptions = {
            zoom: 15,
            center: new google.maps.LatLng(-7.276513, 112.791692),
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            PanControlOptions: false,
            zoomControl: true

        };
        map = new google.maps.Map(document.getElementById('map-canvas'), myOptions);
        var input = /** @type {HTMLInputElement} */(
                document.getElementById('namajalan'));
        var autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.bindTo('bounds', map);


        google.maps.event.addListener(autocomplete, 'place_changed', function() {
            infowindow.close();
            marker.setVisible(false);
            var place = autocomplete.getPlace();
            if (!place.geometry) {
                return;
            }

            // If the place has a geometry, then present it on a map.
            if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
            } else {
                map.setCenter(place.geometry.location);
                map.setZoom(17);  // Why 17? Because it looks good.
            }
            marker.setIcon(/** @type {google.maps.Icon} */({
                url: place.icon,
                size: new google.maps.Size(71, 71),
                origin: new google.maps.Point(0, 0),
                anchor: new google.maps.Point(17, 34),
                scaledSize: new google.maps.Size(35, 35)
            }));
            marker.setPosition(place.geometry.location);
            marker.setVisible(true);
            markers.push(marker);
            var address = '';
            if (place.address_components) {
                address = [
                    (place.address_components[0] && place.address_components[0].short_name || ''),
                    (place.address_components[1] && place.address_components[1].short_name || ''),
                    (place.address_components[2] && place.address_components[2].short_name || '')
                ].join(' ');
            }

            infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
            infowindow.open(map, marker);
        });

        google.maps.event.addListener(map, 'click', function(event)
        {
            clearMarkers();
            markers = [];
            marker = new google.maps.Marker(
                    {
                        draggable: false,
                        animation: google.maps.Animation.DROP,
                        map: map,
                        position: event.latLng,
                        title: 'Lokasi Anda'
                    })
            markers.push(marker);
            geocoder.geocode({
                latLng: marker.getPosition()
            }, function(responses, status) {
                if (status == google.maps.GeocoderStatus.OK)
                {
                    if (responses[0])
                    {
                        $("#namajalan").val(responses[0].formatted_address);
                    }
                }
            });
        })
        get_koord();
    }

    function clearMarkers() {
        for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(null)
        }
    }
    ;

    function get_tujuan()
    {
        directionsDisplay.setMap(null);
        directionsDisplay.setPanel(null);

        var tes = {};
        tes.d = {};
        tes.d.idgedung = $("#idgedung").val();
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>index.php/navigasi/koord_gedung_by_id",
            data: tes,
            success: function(data) {
                var koordTujuan = new google.maps.LatLng(data.hasil[0]['latitude'], data.hasil[0]['longitude']);
                var request = {
                    origin: markers[0].getPosition(),
                    destination: koordTujuan,
                    travelMode: google.maps.DirectionsTravelMode.DRIVING
                };
                directionsService.route(request, function(response, status) {
                    if (status == google.maps.DirectionsStatus.OK) {
                        directionsDisplay.setDirections(response);
                        directionsDisplay.setPanel(document.getElementById('directionsPanel'));
                        directionsDisplay.setMap(map);
                        clearMarkers();
                    }
                });
            }

        });
    }
    ;

    function get_koord() {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>index.php/navigasi/koord_gedung",
            success: function(data) {
                for (var i = 0; i < data.hasil.length; i++)
                {
                    marker = new google.maps.Marker(
                            {
                                draggable: true,
                                animation: google.maps.Animation.DROP,
                                map: map,
                                position: new google.maps.LatLng(data.hasil[i]['latitude'], data.hasil[i]['longitude']),
                                title: data.hasil[i]['nama_gedung']

                            });
                    google.maps.event.addListener(marker, "mouseover", function(e) {
                        e.infoWindowHtml = "<div><h3>" + marker.title + "</h3></div>";
                    })

                    gedung.push(marker);
                }
            }

        });
    }
    ;

    google.maps.event.addDomListener(window, 'load', initialize);
</script>


        <div class="col-xs-12 col-md-12 col-sm-12">
            <center><h3>Penunjuk Arah</h3></center>
            <div class="col-xs-8 col-md-8 col-sm-8">
                <div class="row">
                    <div id="map-canvas" style="width: 100%; height: 400px; " ></div>
                    <br/>
                    <a>*klik pada peta untuk menentukan posisi anda</a>
                </div>
                <div class="row form-group">
                    <div class="col-xs-3 col-md-3 col-sm-3">
                        <label for="lokasi" style="color: black">
                            Alamat Lokasi Anda:
                        </label>
                    </div>
                    <div class="col-xs-6 col-md-6 col-sm-6" >
                        <input type="text" placeholder="Lokasi Asal" class="form-control" id="namajalan" name="namajalan" value=""/>
                    </div>
                    <div class="col-xs-3 col-md-3 col-sm-3" >
                    </div>
                </div>
                <div class="row">
                    <form action="" class="custom" >
                        <div class="col-xs-3 col-md-3 col-sm-3">
                            <label for="gedung"  style="color: black">
                                Pilih Tujuan Anda
                            </label>
                        </div>
                        <div class="col-xs-6 col-md-6 col-sm-6">
                            <select onchange="" name="idgedung" class="form-control" id="idgedung">
                                <?php foreach ($list_gedung as $r) { ?>
                                    <option value="<?php echo $r->ID_GEDUNG; ?>" ><?php echo $r->NAMA_GEDUNG; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-xs-3 col-md-3 col-sm-3">
                        </div>
                    </form>
                </div>
                <div class="row">
                    <center><input class="btn btn-primary" type="submit" value="Petunjuk Jalan" onclick="get_tujuan()" style="margin-top: 30px"></center>
                    
                </div>
            </div>

            <div class="col-xs-4 col-md-4 col-sm-4" >
                <div class="directionsPanel" id="directionsPanel" style="overflow-y: scroll; height:600px;" ></div>
            </div>
        </div>
 