<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class model_navigasi extends CI_Model{
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function read_gedung(){
        
        $sql= 'select * from gedung order by gedung.NAMA_GEDUNG';
        return $this->query($sql);
    }
    
    public function read_koord_gedung(){
        $sql = 'SELECT id_gedung, nama_gedung, latitude, longitude FROM `gedung`';
        return $this->query($sql);
    }
    
    public function read_koord_gedung_by_id($idgedung){
        $sql = "SELECT latitude, longitude 
            FROM  `gedung` where id_gedung = ?";
        
        return $this->query($sql,array($idgedung));
    }
    
}
?>