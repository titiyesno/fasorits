<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class model_tiket extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function create_tiket($idakun, $idsubmit, $judul, $isi, $nomor, $jenis) {

        $data = array(
            'ID_AKUN' => $idakun,
            'ID_SUBMIT' => $idsubmit,
            'JUDUL_TIKET' => $judul,
            'ISI_TIKET' => $isi,
            'TANGGAL_TIKET' => date("Y-m-d H:i:s"),
            'NOMOR_TIKET' => md5(date("Y-m-d H:i:s")),
            'JENIS_TIKET' => $jenis
        );
        $this->db->insert('tiket', $data);
    }

    public function create_tiket2($judul, $isi, $jenis) {
        $sql = "CALL buat_tiket('" . $judul . "','" . $isi . "','" . $this->session->userdata['logged_in']['id'] . "','" . $jenis . "');";
        echo $sql;
        $this->query($sql);
    }

    public function read_tiket() {
        $sql = 'select tiket.NOMOR_TIKET, tiket.ISI_TIKET, DATE_FORMAT(TANGGAL_TIKET,"%b %d %Y %h:%i %p") as TANGGAL_TIKET, tiket.JUDUL_TIKET, if(tiket_status(tiket.NOMOR_TIKET)="Aplikan","Not Answered","Answered") as "STATUS", DATE_FORMAT(tiket_latestcomment(tiket.NOMOR_TIKET),"%b %d %Y %h:%i %p") as "LAST_UPDATE" from tiket where tiket.ID_AKUN=? GROUP by tiket.NOMOR_TIKET order by tiket.TANGGAL_TIKET desc;';
        return $this->query($sql, array($this->session->userdata["logged_in"]["id"]));
    }

    public function detil($nomer) {
        $sql = "select tiket.JUDUL_TIKET, tiket.NOMOR_TIKET, DATE_FORMAT(TANGGAL_TIKET,'%b %d %Y %h:%i %p') as TANGGAL_TIKET, tiket.ISI_TIKET, umum_getnama(tiket.ID_AKUN) as 'NAMA', getusertype(tiket.ID_AKUN) as 'PRIVILAGE'  
                from tiket
                where tiket.NOMOR_TIKET='" . $nomer . "'
                order by tiket.TANGGAL_TIKET asc;";
        return $this->query($sql);
    }

    public function komen($judul, $isi, $nomor, $id) {
        $sql = "CALL tiket_komen('" . $judul . "','" . $isi . "','" . $nomor . "','" . $id . "');";
        return $this->query($sql);
    }

    public function admin_readtiket() {
        $sql = 'select tiket.ID_TIKET, tiket.JENIS_TIKET, gedung.NAMA_GEDUNG, kamar.LANTAI, tiket.NOMOR_TIKET, aplikan.NRP_APLIKAN, tiket.JUDUL_TIKET, kamar.NOMER_KAMAR, aplikan.NAMA_APLIKAN as "DIMULAI",aplikan.COPY_FOTO, DATE_FORMAT(TANGGAL_TIKET,"%d %b %Y %h:%i %p") as TANGGAL_TIKET, count(tiket.NOMOR_TIKET)-1 as "REPLY",
                 DATE_FORMAT(tiket_latestcomment(tiket.NOMOR_TIKET),"%d %M %Y %h:%i %p")  as "LATEST", if(tiket_status(tiket.NOMOR_TIKET)="Aplikan","Not Answered","Answered") as "STATUS"
                from 
                tiket left join submit on (tiket.ID_SUBMIT=submit.ID_SUBMIT)
                left join kamar on (submit.ID_KAMAR=kamar.ID_KAMAR)
                left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG)
                left join aplikan on (submit.ID_APLIKAN=aplikan.ID_APLIKAN)
                group by tiket.NOMOR_TIKET
                order by `STATUS` desc, LATEST desc';
        return $this->query($sql);
    }

    public function read_tiket_by_num() {
        $this->db->group_by('NOMOR_TIKET');
        $query = $this->db->get('tiket');
        return $query->result();
    }

    function cari_tiket_by_judul($keyword) {
        $this->db->like('JUDUL_TIKET', $keyword);
        $query = $this->db->get('tiket');
        return $query->result();
    }

    function cari_tiket_by_isi($keyword) {
        $this->db->like('ISI_TIKET', $keyword);
        $query = $this->db->get('tiket');
        return $query->result();
    }

    public function getdataprint($id) {
        $sql = 'select tiket.ID_TIKET, tiket.JENIS_TIKET, aplikan.NAMA_APLIKAN, aplikan.NRP_APLIKAN, aplikan.FAKULTAS_APLIKAN, aplikan.JURUSAN_APLIKAN, gedung.NAMA_GEDUNG, kamar.NOMER_KAMAR from tiket left join aplikan on (tiket.ID_AKUN=aplikan.ID_APLIKAN) left join submit on (submit.ID_SUBMIT=tiket.ID_SUBMIT)
left join kamar on (submit.ID_KAMAR=kamar.ID_KAMAR) left join gedung on (gedung.ID_GEDUNG=kamar.ID_GEDUNG)
where tiket.ID_TIKET=?';
        return $this->query($sql, array($id));
    }

    public function getById($id) {
        $this->db->where('ID_TIKET', $id);
        $query = $this->db->get('tiket');
        return $query->result();
    }

    public function update_tiket($id, $judul, $isi) {

        $data = array(
            'JUDUL_TIKET' => $judul,
            'ISI_TIKET' => $isi
        );

        $this->db->where('ID_TIKET', $id);
        $result = $this->db->update('tiket', $data);
        return $result;
    }

    public function delete_tiket($id) {
        $this->db->where('ID_TIKET', $id);
        $this->db->delete('tiket');
    }

    public function balas_tiket() {
        $data = array(
            'ISI_TIKET' => $isi,
            'TANGGAL_TIKET' => date("Y-m-d H:i:s")
        );
        $this->db->insert('tiket', $data);
    }

}

?>