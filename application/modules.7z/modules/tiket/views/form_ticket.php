<div class="row">
    <div class="large-12 columns">
        <div class="row">
            <div class="large-8 columns"> &nbsp;</div>
            <div class="large-4 columns">
                NO. DOK.   : <br/>
                REVISI     : <br/>
                TGL TERBIT :<br/>
                HALAMAN    :<br/><br/>
            </div>
        </div>
        <div class="row">
            <center>
                <h4><b>
                        KEMENTRIAN DAN KEBUDAYAAN<BR/>
                        UNIT ASRAMA MAHASISWA<BR/>
                        INSTITUT TEKNOLOGI SEPULUH NOPEMBER<BR/>
                        (ITS)
                    </b>
                </h4>
                <H6>Jl Teknik Elektro, Surabaya. Telp (031) 5925965 </H6>
                <hr/>
                <h4>
                    SURAT KOMPLAIN
                </h4>
            </center>


        </div>
        <div class="row">
            <div class="large-1 columns">&nbsp;</div>
            <div class="large-10 columns">
                Yang Bertanda Tangan Dibawah Ini : <br/> <br/>
                Nama &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&emsp;<?php echo $tiket[0]->NAMA_APLIKAN; ?><br/>
                NRP &nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&emsp;<?php echo $tiket[0]->NRP_APLIKAN; ?><br/>
                Fakultas/Jurusan &nbsp;&emsp;:&emsp;<?php echo $tiket[0]->FAKULTAS_APLIKAN . "/" . $tiket[0]->JURUSAN_APLIKAN; ?><br/>
                <br/>
                Penghuni Blok  &nbsp;&emsp;:&emsp;<?php echo $tiket[0]->NAMA_GEDUNG ?><br/>
                Nomer Kamar &nbsp;&nbsp;&emsp;:&emsp;<?php echo $tiket[0]->NOMER_KAMAR ?><br/>
                <br/>
                <br/>
                Kami sebagai penghuni Asrama ITS bersama ini kami mengajukan Komplain <b><?php echo $tiket[0]->JENIS_TIKET; ?></b><br/>
                Demikian Pengaduan ini saya buat dengan sesungghnya dan benar. Sebelumnya atas perhatian dan tindak lanjut Bapak, kami sampaikan Terimakasih.
                <br/>
                <br/>
                Surabaya, <?php echo date("d M Y"); ?><br/>
                Pihak Yang Mengajukan
                <br/>
                <br/>
                <br/>
                <br/>
                <?php echo $tiket[0]->NAMA_APLIKAN; ?><br/>
                <hr/>
                <center><i>penanganan</i></center>


            </div>
            <div class="large-1 columns"></div>
        </div>
        <br/>
        <br/>
        <div class="row">
            <div class="large-1 columns">&nbsp;</div>
            <div class="large-10 columns">
                Usulan komplain dari pihak penghuni sudah ditindak lanjuti dengan baik, maka dengan ini kami sebagai petugas melansanakan perintah atasan untuk menyelesaikan tanggung jawab kami sebagai pelayan pelanggan disetiap kegiatan perbaikan yang diberikan.<br/>
                Demikian atas komplainnya yang telah diberikan, kami sebagai petugas melaksanakan dengan sebaik mungkin dan atas kerjasamanya kami ucapkan terimakasih.

                <br/>
                <br/>
                <div class="large-6 columns">
                    <br/>
                    Pihak Penghuni Komplain
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                    <?php echo $tiket[0]->NAMA_APLIKAN; ?><br/>
                </div>
                <div class="large-6 columns">
                    Surabaya, <?php echo date("d M Y"); ?><br/>
                    Pihak Petugas yang memperbaiki
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                    (..................................)<br/>
                </div>
                <div class="row">
                    <div class="large-3 columns">&nbsp;</div>
                    <div class="large-6 columns">
                        <br/>
                        <br/>
                        <br/>
                        <center>
                            Mengetahui<br/>
                            Koordinator Rumah Tangga
                            <br/>
                            <br/>
                            <br/>
                            <br/>
                            (Ahmad Ustadziwais)<br/>
                            NIPH 9 1000 4 00 1<br/>
                        </center>
                    </div>
                    <div class="large-3 columns">&nbsp;</div>
                </div>
            </div>
            <div class="large-1 columns">&nbsp;</div>

        </div>
    </div>
</div>