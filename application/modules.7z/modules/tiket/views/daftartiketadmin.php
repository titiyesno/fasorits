<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/web_statis/fullwidthtabs/css/demo.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/web_statis/fullwidthtabs/css/component.css" />
<div id="tabs" class="tabs" style="min-height: 600px">
    <nav>
        <ul>
            <li><a href="#section-1" class="icon-shop"><span>Belum Terjawab</span></a></li>
            <li><a href="#section-2" class="icon-cup"><span>Sudah Terjawab</span></a></li>
        </ul>
    </nav>
    <div class="content">
        <section id="section-1">
            <table>
                <thead>

                <th style="width: 7%">Tiket</th>
                <th style="width: 25%"><center>Subjek</center></th>
                <th style="width: 10%"><center>Status</center></th>
                <th style="width: 13%"><center>Kamar</center></th>
                <th style="width: 25%"><center>Jawaban</center></th>
                <th style="width: 20%"><center>Cetak Form</center></th>
                </thead>
                <tbody>
                    <?php
                    $temp = $tiket;
                    foreach ($tiket as $data) {
                        if ($data->STATUS == "Answered")
                            continue;
                        ?>
                        <tr>
                            <td> <img src="<?php
                                if (isset($data->COPY_FOTO)) {
                                    $tt = explode("\\", $data->COPY_FOTO);
                                    $nrp = $tt[0];
                                    $nama_file = $tt[1];
                                    $thumb = base_url() . "uploads/" . $nrp . "/thumbs_" . $nama_file;
                                    echo $thumb;
                                } else {
                                    echo base_url() . "static/img/tiket-icon.png";
                                }
                                ?>" style="height: 30px; width: 30px;"/>
                            </td>

                            <td><a href="<?php echo base_url() ?>index.php/tiket/<?php echo $this->session->userdata['logged_in']['privilege']; ?>/detil/<?php echo $data->NOMOR_TIKET; ?>">
                                    <h3 class="oxigenfontblue"><?php echo $data->JUDUL_TIKET; ?></h3></a>
                                <span class="oxigen" style="font-size: smaller">Dimulai oleh : <?php echo $data->DIMULAI; ?></span><br/>
                                <span class="label"><?php echo $data->TANGGAL_TIKET; ?></span>

                            </td>
                            <td><center>
                        <?php
                        if ($data->STATUS == "Answered") {
                            $color = "success";
                        } else
                            $color = "alert";
                        echo '<span class="round ' . $color . ' label">' . $data->STATUS . '</span>';
                        ?></center>
                    </td>
                    <td><center><?php echo $data->NOMER_KAMAR; ?>
                        <span class="oxigen" style="font-size: smaller"> (Lantai : <?php echo $data->LANTAI; ?>)</span></center>
                    <span class="label"><?php echo $data->NAMA_GEDUNG; ?></span>
                    </td>
                    <td class="panel"> <b><?php echo $data->REPLY; ?></b> Jawaban <br/> pada <br/><span class="" style="font-size: smaller"><?php echo str_replace("-", "/", $data->LATEST); ?></span></td>
                    <td><a onclick="window.open('<?php echo base_url() . "index.php/tiket/admin/form/" . $data->ID_TIKET; ?>', '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');">Cetak Bukti</a></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </section>
        <section id="section-2">
            <table>
                <thead>

                <th style="width: 7%">Tiket</th>
                <th style="width: 45%"><center>Subjek</center></th>
                <th style="width: 10%"><center>Status</center></th>
                <th style="width: 13%"><center>Kamar</center></th>
                <th style="width: 25%"><center>Jawaban</center></th>

                </thead>
                <tbody>
                    <?php
                    foreach ($temp as $data) {
                        if ($data->STATUS != "Answered")
                            continue;
                        ?>

                        <tr>
                            <td> <img src="<?php
                                if (isset($data->COPY_FOTO)) {
                                    $tt = explode("\\", $data->COPY_FOTO);
                                    $nrp = $tt[0];
                                    $nama_file = $tt[1];
                                    $thumb = base_url() . "uploads/" . $nrp . "/thumbs_" . $nama_file;
                                    echo $thumb;
                                } else {
                                    echo base_url() . "static/img/tiket-icon.png";
                                }
                                ?>" style="height: 30px; width: 30px;"/>
                            </td>

                            <td><a href="<?php echo base_url() ?>index.php/tiket/<?php echo $this->session->userdata['logged_in']['privilege']; ?>/detil/<?php echo $data->NOMOR_TIKET; ?>">
                                    <h3 class="oxigenfontblue"><?php echo $data->JUDUL_TIKET; ?></h3></a>
                                <span class="oxigen" style="font-size: smaller">Dimulai oleh : <?php echo $data->DIMULAI; ?></span><br/>
                                <span class="label"><?php echo $data->TANGGAL_TIKET; ?></span>

                            </td>
                            <td><center>
                        <?php
                        if ($data->STATUS == "Answered") {
                            $color = "success";
                        } else
                            $color = "alert";
                        echo '<span class="round ' . $color . ' label">' . $data->STATUS . '</span>';
                        ?></center>
                    <span class="round label"> <?php echo $data->JENIS_TIKET; ?></span>
                    </td>
                    <td><center><?php echo $data->NOMER_KAMAR; ?>
                        <span class="oxigen" style="font-size: smaller"> (Lantai : <?php echo $data->LANTAI; ?>)</span></center>
                    <span class="label"><?php echo $data->NAMA_GEDUNG; ?></span>
                    </td>
                    <td class="panel"> <b><?php echo $data->REPLY; ?></b> Jawaban <br/> pada <br/><span class="" style="font-size: smaller"><?php echo str_replace("-", "/", $data->LATEST); ?></span></td>


                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </section>

    </div><!-- /content -->
</div><!-- /tabs -->

<script src="<?php echo base_url() ?>assets/web_statis/fullwidthtabs/js/cbpFWTabs.js"></script>
<script>
                        new CBPFWTabs(document.getElementById('tabs'));
</script>