<?php echo form_open("tiket/aplikan/tambah");?>
    <center><h3 class="oxigenfontblue">Tambah Tiket Keluhan</h3></center>
    <hr/>
    <div class="row">
        <div class="large-6 columns">
            <div class="row oxigenfontblue">
                <input type="text" name="judul" placeholder="Judul Tiket Keluhan" required/>
            </div>
            <div class="row oxigenfontblue">
                <select name="jenistiket">
                    <option selected DISABLED>Tujuan Tiket</option>
                    <option value="Parkiran">Kunci Pintu Kamar Macer</option>
                    <option value="Fasilitas Kamar">Air Keran Tidak Lancar/Buntu</option>
                    <option value="Kebersihan Asrama">Air Bocor Dari Plafon</option>
                    <option value="Fasilitas Asrama">Jendela Tidak Bisa Ditutup</option>
                    <option value="Pelayanan Petugas">Jaringan Listrik Trouble</option>
                    <option value="Pelayanan Petugas">Closed Buntu Tidak Aktif</option>
                    <option value="Pelayanan Petugas">Lampu Penerangan Mati</option>
                    <option value="Pelayanan Petugas">Pelayanan Customer Service</option>
                    <option value="Pelayanan Petugas">Keamanan Asrama</option>
                    <option value="Pelayanan Petugas">Kerapian dan Kebersihan Gedung</option>
                    <option value="Pelayanan Petugas">Lainnya</option>
                </select>
            </div>
            <div class="row oxigenfontblue"> 
                <textarea name="isi" placeholder="Isi Tiket Keluahan" required style="height: 300px;"></textarea>
            </div>
            <div class="right"><input class="small button" type="submit"/></div>
        </div>
        <div class="large-6 columns">
            <div class="row oxigenfontblue">
                <table >
                    <thead>
                        <tr>
                            <th><center>Subjek</center></th>
                    <th width="100"><center>Status</center></th>
                    <th width="150"><center>Latest Update</center></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tiket as $data) { ?>
                            <tr>
                                <td><a href="<?php echo base_url() ?>index.php/tiket/<?php echo $this->session->userdata['logged_in']['privilege']; ?>/detil/<?php echo $data->NOMOR_TIKET; ?>"><?php echo $data->JUDUL_TIKET; ?></a></td>
                                <td><?php
                        if ($data->STATUS == "Answered")
                            echo '<span class="round success label">' . $data->STATUS . '</span>';
                        else
                            echo '<span class="round alert label">' . $data->STATUS . '</span>';
                            ?></td>
                                <td><?php echo $data->LAST_UPDATE; ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</form>