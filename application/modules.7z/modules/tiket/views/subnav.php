<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.2.min.js"></script>
<div class="section-container accordion oxigenfontblue" data-section="accordion" style="margin-top: 50px;">
    <section >
        <p class="title" data-section-title><a href="<?php echo base_url();?>index.php/tiket/aplikan/index">Tiket</a></p>
        <p class="title" data-section-title><a href="<?php echo base_url();?>index.php/tiket/aplikan/lihat">Histori Tiket</a></p>
    </section>
</div>