<div class="row oxigenfontblue">
    <div class="large-12 columns" style="min-height: 500px">
        <h3 class="oxigenfontblue">My Support Tickets</h3><hr/>
        <table >
            <thead>
                <tr>
                    <th width="200"><center>Tanggal</center></th>
            <th><center>Subjek</center></th>
            <th width="150"><center>Status</center></th>
            <th width="150"><center>Latest Update</center></th>
            </tr>
            </thead>
            <tbody>
                <?php foreach ($tiket as $data) { ?>
                    <tr>
                        <td><?php echo $data->TANGGAL_TIKET; ?></td>
                        <td><a href="<?php echo base_url() ?>index.php/tiket/<?php echo $this->session->userdata['logged_in']['privilege']; ?>/detil/<?php echo $data->NOMOR_TIKET; ?>"><?php echo $data->JUDUL_TIKET; ?></a></td>
                        <td><?php 
                        if($data->STATUS=="Answered") 
                            echo '<span class="round success label">'.$data->STATUS.'</span>';
                        else     echo '<span class="round alert label">'.$data->STATUS.'</span>';
                        ?></td>
                        <td><?php echo $data->LAST_UPDATE; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>