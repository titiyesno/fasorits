<div class="row oxigenfontblue">
    <div class="large-12 columns">
        <h4 class="right oxigenfontblue">
            <span class="label">Detail Tiket</span>
        </h4>
        <center>
            <h3 class="oxigenfontblue">Lihat Tiket <?php echo $tiket[0]->JUDUL_TIKET; ?></h3>
            <hr/>
        </center>
        <?php echo form_open("tiket/".$this->session->userdata["logged_in"]["privilege"]."/komen/".$tiket[0]->NOMOR_TIKET)?>
            <div class="large-12 columns">
                <div class="row">
                    <textarea style="width: 100%;" placeholder="Simple Reply Area" name="isi"></textarea>
                    <input type="hidden" name="judul" value="<?php echo $tiket[0]->JUDUL_TIKET;?>"/>
                    <input type="hidden" name="nomer" value="<?php echo $tiket[0]->NOMOR_TIKET;?>"/>
                </div>
                <div class="row">
                    <input class="right small button" type="submit" value="Reply" name="submit"/>
                </div>
            </div>
        </form>
        <?php
        foreach ($tiket as $data) {
            if ($data->PRIVILAGE == "Aplikan") echo '<span class="label blue">';
            else echo '<span class="label orange" style="background-color: #FF7E00;">';
            echo $data->NAMA . " || " . $data->PRIVILAGE;
            echo '</span>';
           
            ?>
        <div class="large-4 columns">
            
        </div>
            <div class="panel alenfont" style="margin-top: 0px;margin-bottom: 0px; background-color: whitesmoke">
                <?php echo $data->ISI_TIKET; 
                ?>
                <hr/>
                <?php  echo '<span class="right label orange" style="background-color: #777;">'.$data->TANGGAL_TIKET.'</span>';?>
            </div>
        <?php } ?>
    </div>
</div>