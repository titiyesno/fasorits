<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class tiket extends MX_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'form'));
        $this->load->model('tiket/model_tiket');
        $this->load->library('form_validation');
    }

    function index() {
        $data['tiket'] = $this->model_tiket->read_tiket();
        $this->load->view('lihatTiket', $data);
    }

    function cari_tiket() {
        $keyword = $this->input->post('keyword');
        $data['results'] = $this->model_tiket->cari_tiket($keyword);
        $this->load->view('hasilcaritiket', $data);
    }
    
    function tambah(){
        $judul = $this->input->post('judul');
        $isi = $this->input->post('isi');
        $data['tiket'] = array(
            'JUDUL_TIKET' => $judul,
            'ISI_TIKET' => $isi
        );

        $this->form_validation->set_rules("judul", "Nama", "trim|required|xss_clean");
        $this->form_validation->set_rules("isi","NRP","trim|required|xss_clean");
        
        if ($this->form_validation->run() == FALSE || $this->form_validation->run() == null) {
            $this->load->view('tambahTiket', $data);
        } else {
            $aplikan=$this->model_tiket->create_tiket($judul, $isi, $tanggal, $nomor);
            redirect('tiket');
        }
    }

    function update($idtiket="") {
        $id = $this->input->post('idtiket');
        $judul = $this->input->post('judul');
        $isi = $this->input->post('isi');
        $data['tiket'] = array(
            'JUDUL_TIKET' => $judul,
            'ISI_TIKET' => $isi
        );

        $this->form_validation->set_message('required', "%s Harus Diisi");
        $this->form_validation->set_rules('judul', 'Judul Tiket', 'trim|required');
        $this->form_validation->set_rules('isi', 'Isi Tiket', 'trim|required');

        if ($this->form_validation->run() == FALSE) {

            $data['tiket'] = $this->model_tiket->getById($idtiket);
            $this->load->view('ubahtiket', $data);
        } else {
            $this->model_tiket->update_tiket($id, $judul, $isi);
            redirect('tiket');
        }
    }

    function hapus($id) {
        $this->model_tiket->delete_tiket($id);
        redirect('tiket');
    }

    function detil($judul="") {
        $id = $this->input->post('idtiket');
        $isi = $this->input->post('isi');
        $data['tiket'] = array(
            'ISI_TIKET' => $isi
        );
        if ($this->form_validation->run() == FALSE) {

            $data['tiket'] = $this->model_tiket->getByJudul($judul);
            $this->load->view('detilTiket', $data);
        } else {
            $this->model_tiket->balas_tiket($id, $judul, $isi);
            redirect('tiket');
        }
    }

}

?>