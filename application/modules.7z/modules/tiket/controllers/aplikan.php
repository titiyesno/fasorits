<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Aplikan extends Aplikan_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'form'));
        $this->load->model('tiket/model_tiket');
        $this->load->model('submit_model');
        $this->load->library('form_validation');
    }

    public function index() {
        $menu = "hf/menu/menu_pemesan.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Tiket Keluhan");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $data["tiket"] = $this->model_tiket->read_tiket();
        $this->template->build("tambahtiket.php",$data);
    }

    function tambah() {
        $judul = $this->input->post('judul');
        $isi = $this->input->post('isi');
        $jenis = $this->input->post('jenistiket');
        $this->model_tiket->create_tiket2($judul, $isi,$jenis);
        redirect('tiket/aplikan/lihat');
    }

    public function detil($no) {
        $data["tiket"] = $this->model_tiket->detil($no);
        $menu = "hf/menu/menu_pemesan.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Lihat Tiket");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("detil.php", $data);
    }
    public function komen($no){
        $judul = $this->input->post('judul');
        $isi = $this->input->post('isi');
        $nomor = $this->input->post('nomor');
        
        $this->model_tiket->komen($judul,$isi,$no,$this->session->userdata["logged_in"]["id"]);
        $this->detil($no);
    }

    public function lihat() {
        $data["tiket"] = $this->model_tiket->read_tiket();
        $menu = "hf/menu/menu_pemesan.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Lihat Tiket");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("tiketku.php", $data);
    }

    public function ubah() {
        $data["tiket"] = $this->model_tiket->read_tiket();
        $menu = "hf/menu/menu_pemesan.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Lihat Tiket");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("ubah_tiket.php");
    }

    public function simpan_ubah() {
        $id = $this->input->post('idtiket');
        $judul = $this->input->post('judul');
        $isi = $this->input->post('isi');
        $this->model_tiket->update_tiket($id, $judul, $isi);
        redirect('tiket/aplikan/lihat');
    }

    public function balas() {
        $data["tiket"] = $this->model_tiket->read_tiket();
        $menu = "hf/menu/menu_pemesan.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Lihat Tiket");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("detil_tiket_aplikan.php");
    }

    public function simpan_balas() {
        $judul = $this->input->post('judul');
        $isi = $this->input->post('isi');
        $nomor = $this->input->post('nomor');
        $this->model_tiket->create_tiket($judul, $isi, $tanggal, $nomor);
        redirect('tiket/aplikan/balas');
    }

    public function hapus($id) {
        $this->model_tiket->delete_tiket($id);
        redirect('tiket');
    }

}

?>
