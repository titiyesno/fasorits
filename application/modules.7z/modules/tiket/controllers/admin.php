<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Admin extends Admin_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'form'));
        $this->load->model('tiket/model_tiket');
        $this->load->library('form_validation');
    }

    public function index() {
        $data["tiket"] = $this->model_tiket->admin_readtiket();
        $data["tiket2"] = $this->model_tiket->admin_readtiket();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav_admin.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Daftar Tiket");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("daftartiketadmin.php", $data);
    }

    public function detil($no) {
        $data["tiket"] = $this->model_tiket->detil($no);
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $subnav = "subnav_admin.php";
        $this->template->set_layout('back_end');
        $this->template->title("Detil Tiket");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("detil.php", $data);
    }

    function komen($no) {
        $judul = $this->input->post('judul');
        $isi = $this->input->post('isi');
        $id = $this->session->userdata["logged_in"]["id"];
        $this->model_tiket->komen($judul, $isi, $no, $id);
        redirect("tiket/admin/detil/".$no);
    }
    public function balas() {
        $idtiket = $this->input->post('idtiket');
        $judul = $this->input->post('judul');
        $isi = $this->input->post('isi');
        $this->model_tiket->create_tiket();
        redirect('tiket/admin/detil');
    }

    public function ubah() {
        $data["tiket"] = $this->model_tiket->read_tiket();
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Lihat Tiket");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("ubah_tiket_admin.php");
    }

    public function simpan_ubah() {
        $isi = $this->input->post('isi');
        $this->model_tiket->update_tiket($id, $judul, $isi);
        redirect('tiket/admin/detil');
    }
    public function form($id)
    {
        $data['tiket']  = $this->model_tiket->getdataprint($id);
        $this->template->set_layout('cetak');
        $this->template->title("Form Pengaduan");
        $this->template->build("form_ticket.php",$data);
    }

    public function cari_tiket_by_isi() {
        $keyword = $this->input->post('keyword');
        $data['results'] = $this->model_tiket->cari_tiket_by_isi($keyword);
        $menu = "hf/menu/menu_pengelola.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Hasil Cari Tiket");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->load->view('hasilcaritiket.php');
    }

    public function hapus($id) {
        $this->model_tiket->delete_tiket($id);
        redirect('tiket/admin');
    }

}

?>
