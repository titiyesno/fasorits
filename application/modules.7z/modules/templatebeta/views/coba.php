<?php
 echo "Ini Berasal dari Template HMVC Header";
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
