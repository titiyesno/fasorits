<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Templates extends MX_Controller{
    
    function __construct(){
        parent::__construct();
        $this->load->library('template');
    }
    public function index()
    {
        $this->template->set_layout('main_layout.php');
        $this->template->title('Coba sesuatu');
        $header_views = 'coba.php';
        $this->template->set_partial('header',$header_views); 
        $this->template->inject_partial('footer','&copy;2012 CodeIgniter 2');
        $this->template->build('index.php');
    }
}
?>
