<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class admin extends Admin_Controller {
    
    function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('penghuni/report_model');
                    //tes
    }
    
    public function penghuni_asrama()
    {
        $data['periode'] = $this->report_model->read_periode();
        $data['program'] = $this->report_model->read_program();
        $data['lantai'] = $this->report_model->read_lantai();
        $data['gedung'] = $this->report_model->read_gedung();
        $data['data'] = $this->report_model->read_penghuni2();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("penghuniasrama.php",$data);
    }
    
    public function getsubmitdata() {
        $temp1 = $this->report_model->read_penghuni2();
        $data["submit"] = $this->getPivot($temp1);
        return $data["submit"];
    }
    function clean($string) {
        //$string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
        //return str_replace(array('\'', '\\', '/', '*'), ' ', $string);
        return preg_replace('/[^A-Za-z0-9\-@ .,]/', '-', $string); // Removes special chars.
    }

    private function getPivot($data) {
        header('Cache-Control: no-cache, must-revalidate');
        header('Content-type: application/json');
        $header = "[[";
        foreach ($data as $value) {
            foreach ($value as $key => $sembarang) {
                $header .= '"' . str_replace("_", " ", strtoupper($key)) . '"';
                break;
            }
            $count = 1;
            foreach ($value as $key => $sembarang) {
                if ($count > 1) {
                    $header .= ',"' . str_replace("_", " ", strtoupper($key)) . '"';
                }
                $count ++;
            }
            $header .= "]";
            break;
        }

        foreach ($data as $value) {
            $header .= ",[";
            foreach ($value as $key => $data) {
                $data = $this->clean($data);
                if ($key == "NRP_APLIKAN") {
                    $header .= '"<a href=\'' . base_url() . 'index.php/pembayaran/admin/pembayaran/' . $data . '\'>' . $data . '</a>"';
                } else {
                    $header .= '"' . $data . '"';
                }
                break;
            }
            $count = 1;
            foreach ($value as $key => $data) {
                $data = $this->clean($data);
                if ($count > 1) {
                    if ($key == "NRP_APLIKAN") {
                        $header .= ',"<a href=\'' . base_url() . 'index.php/pembayaran/admin/pembayaran/' . $data . '\'>' . $data . '</a>"';
                    } else {
                        $header .= ',"' . $data . '"';
                    }
                }
                $count ++;
            }
            $header .= "]";
        }
        $header .= "]";
        echo $header;
    }
    
    public function fasilitas_gedung()
    {
        $data['list_gedung'] = $this->report_model->read_gedung();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("footer", $footer);
        $this->template->build("penghuniasrama.php",$data);
    }
    
    public function cari_penghuni() {
        $periode = $this->input->post('periode');
        $idgedung = $this->input->post('idgedung');
        $lantai = $this->input->post('lantai');
        $program = $this->input->post('program');
        $data = $this->report_model->read_penghuni($periode,$idgedung,$lantai,$program);
        $a = 1;
        $htmlres = "<thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Nomor Kamar</th>
                            <th>Gedung</th>
                        </tr>
                    </thead>";
        foreach ($data as $p) {
            $htmlres .=
                    "
                    <tbody>
                        <tr>
                            <td>$a</td>
                            <td>$p->NAMA_APLIKAN</td>
                            <td>$p->NOMER_KAMAR</td>
                            <td>$p->NAMA_GEDUNG</td>
                        </tr>
                    </tbody>";
            $a++;
        }
        echo $htmlres;
    }
    
    public function getXLS() {
        $data = $this->report_model->read_penghuni2();
        $this->generateCSV($data, "Penghuni Asrama");
    }

    public function generateCSV($data, $nama) {
        header("Content-type: application/octet-stream");
        header("Content-Disposition: attachment; filename=" . $nama . "-asramaITS.xls");
        header("Pragma: no-cache");
        header("Expires: 0");

        $header = "";
        foreach ($data as $value) {
            foreach ($value as $key => $sembarang) {
                $header .= $key;
                break;
            }
            $count = 1;
            foreach ($value as $key => $sembarang) {
                if ($count > 1)
                    $header .= '	' . $key;
                $count++;
            }
            $header .= "\n";
            break;
        }

        foreach ($data as $value) {
            foreach ($value as $key => $data) {
                $header .= $data;
                break;
            }
            $count = 1;
            foreach ($value as $key => $data) {
                if ($count > 1) {
                    if ($key == "SITE_ID" && $this->isAdmin())
                        $header .= '	' . $data;
                    else
                        $header .= '	' . $data;
                }
                $count++;
            }
            $header .= "\n";
        }
        echo $header;
    }
    
}

?>
