<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class report_model extends CI_model {
    
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    /*penghuni asrama, by periode - by gedung - by lantai - by program diterima*/
    public function read_penghuni($periode,$idgedung,$lantai,$programditerima)
    {
        $query = "select aplikan.ID_APLIKAN, aplikan.NAMA_APLIKAN, kamar.NOMER_KAMAR, gedung.NAMA_GEDUNG 
        from submit inner join aplikan on (submit.ID_APLIKAN=aplikan.ID_APLIKAN) 
        left join kamar on (submit.ID_KAMAR=kamar.ID_KAMAR) 
        left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG) 
        where aplikan.ID_APLIKAN IN(
	select aplikan.ID_APLIKAN
	from aplikan, submit, periode
	WHERE aplikan.ID_APLIKAN = submit.ID_APLIKAN and 
        aplikan.PROGRAM_DITERIMA = '$programditerima' and
	submit.ID_PERIODE = periode.ID_PERIODE and 
        submit.STATUS_SUBMIT = 'diterima'
        and periode.ID_PERIODE = $periode and submit.ID_KAMAR IN 
        (select kamar.ID_KAMAR from kamar, gedung
	where kamar.ID_GEDUNG = gedung.ID_GEDUNG and 
        gedung.ID_GEDUNG = $idgedung and kamar.LANTAI = $lantai))";
        return $this->db->query($query)->result();
    }
    
    public function read_penghuni2() {
        $query = 'select submit.CODE_BOOKING, aplikan.NAMA_APLIKAN, aplikan.NRP_APLIKAN, aplikan.TGL_LAHIR_APLIKAN, aplikan.TEMPAT_LAHIR_APLIKAN, aplikan.FAKULTAS_APLIKAN, aplikan.JURUSAN_APLIKAN, aplikan.PROGRAM_DITERIMA, aplikan.JENIS_KEL_APLIKAN, aplikan.AGAMA_APLIKAN, aplikan.ALAMAT_APLIKAN, aplikan.TELP_APLIKAN, aplikan.PEKERJAAN_ORANTUA, aplikan.PENGHASILAN_ORANGTUA,
			kamar.NOMER_KAMAR, kamar.LANTAI, gedung.NAMA_GEDUNG, periode.NAMA_PERIODE, periode.NAMA_PERIODE, submit.TANGGAL_SUBMIT 
        from submit inner join aplikan on (submit.ID_APLIKAN=aplikan.ID_APLIKAN) 
        left join kamar on (submit.ID_KAMAR=kamar.ID_KAMAR) 
        left join gedung on (kamar.ID_GEDUNG=gedung.ID_GEDUNG) 
        left join periode on (submit.ID_PERIODE=periode.ID_PERIODE)
        where submit.STATUS_SUBMIT = "penghuni"';
        return $this->db->query($query)->result();
    }
    
    public function read_periode() 
    {
        $query = $this->db->get('periode');
        return $query->result();
    }
    
    public function read_program() 
    {
        $query = "select distinct aplikan.PROGRAM_DITERIMA from aplikan";
        return $this->db->query($query)->result();
    }
    
    public function read_lantai() 
    {
        $query = "select distinct kamar.LANTAI from kamar ORDER BY kamar.lantai";
        return $this->db->query($query)->result();
    }
    
    public function read_gedung() 
    {
        $query = $this->db->get('gedung');
        return $query->result();
    }
    
}