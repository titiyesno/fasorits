<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class admin extends Admin_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('galeri/galeri_model');
        $this->load->model('kamar/jeniskamar_model');
        $this->load->library('form_validation');
        $this->load->library('image_CRUD');
    }

    public function index() {
        redirect('kamar/admin/daftar_gedung');
    }

    public function menugaleri() {
        $data['listgaleri'] = $this->galeri_model->read_galeri();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer);
        $this->template->build("menugaleri.php",$data);
    }
    
    function organize_foto_galeri($idgaleri="",$idgedung="")
    {
        $data['datagaleri'] = $this->galeri_model->read_galeri_by_id($idgaleri);
        $data['idgedung'] = $idgedung;
        $image_crud = new image_CRUD();
        $image_crud->set_primary_key_field('ID_GAMBAR');
        $image_crud->set_url_field('ALAMAT_GAMBAR');
        $image_crud->set_title_field('JUDUL_GAMBAR');
        $image_crud->set_table('gambar')
        ->set_relation_field('ID_GALERI')
        ->set_ordering_field('PRIORITAS')
        ->set_image_path('assets/uploads');
        $image_crud->set_idgaleri('ID_GALERI');
        $output = $image_crud->render();
        
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
//        $this->template->set_partial("subnav", $subnav);
        $this->template->set_partial("footer", $footer,$data);
        $this->template->build("viewalbum.php", $output);
    }
    
    function organize_foto_galeri_jeniskamar($idgaleri="",$idjeniskamar="")
    {
        $data['datagaleri'] = $this->galeri_model->read_galeri_by_id($idgaleri);
        $data['datajeniskamar'] = $this->jeniskamar_model->read_jeniskamar_by_id($idjeniskamar);
        $image_crud = new image_CRUD();
        $image_crud->set_primary_key_field('ID_GAMBAR');
        $image_crud->set_url_field('ALAMAT_GAMBAR');
        $image_crud->set_title_field('JUDUL_GAMBAR');
        $image_crud->set_table('gambar')
        ->set_relation_field('ID_GALERI')
        ->set_ordering_field('PRIORITAS')
        ->set_image_path('assets/uploads');
        $image_crud->set_idgaleri('ID_GALERI');
        $output = $image_crud->render();
        echo $image_crud->image_path;
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav,$data);
        $this->template->set_partial("footer", $footer);
        $this->template->build("viewalbum_tambah_jeniskamar.php", $output);
    }
    
    function lihat_galeri($id="")
    {
        $data['datagaleri'] = $this->galeri_model->read_galeri_by_id($id);
        $image_crud = new image_CRUD();
        $image_crud->unset_upload();
        $image_crud->unset_delete();

        $image_crud->set_primary_key_field('ID_GAMBAR');
        $image_crud->set_url_field('ALAMAT_GAMBAR');
        $image_crud->set_table('gambar')
        ->set_relation_field('ID_GALERI')
        ->set_ordering_field('PRIORITAS')
        ->set_image_path('assets/uploads');
        $output = $image_crud->render();
        $menu = "hf/menu/menu_pengelola.php";
        $subnav = "subnav.php";
        $footer = "hf/footer/footer.php";
        $this->template->set_layout('back_end');
        $this->template->title("Home Admin");
        $this->template->set_partial("menu", $menu);
        $this->template->set_partial("subnav", $subnav,$data);
        $this->template->set_partial("footer", $footer);
        $this->template->build("viewalbum.php", $output);
    }

}

?>
