<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.2.min.js"></script>
<div class="section-container accordion" data-section="accordion" style="margin-top: 50px;">
    <section >
        <p class="title" data-section-title><a href="#">Gedung</a></p>
        <div class="content" data-section-content>
            <p><a href="<?php echo base_url();?>index.php/kamar/admin/daftar_gedung">Daftar Gedung</a></p>
            <p><a href="<?php echo base_url();?>index.php/kamar/admin/tambah_gedung">Tambah Gedung</a></p>
        </div>
    </section>
    <section >
        <p class="title" data-section-title><a href="#">Kamar</a></p>
        <div class="content" data-section-content>
            <p><a href="<?php echo base_url();?>index.php/kamar/admin/daftar_kamar">Daftar Kamar</a></p>
            <p><a href="<?php echo base_url();?>index.php/kamar/admin/tambah_kamar">Tambah Kamar</a></p>
          
        </div>
    </section>
    <section >
        <p class="title" data-section-title><a href="#">Jenis Kamar</a></p>
        <div class="content" data-section-content>
            <p><a href="<?php echo base_url();?>index.php/kamar/admin/daftar_jeniskamar">Daftar Jenis Kamar</a></p>
            <p><a href="<?php echo base_url();?>index.php/kamar/admin/tambah_jeniskamar">Tambah Jenis Kamar</a></p>
        </div>
    </section>
    <section >
        <p class="title" data-section-title><a href="<?php echo base_url();?>index.php/kamar/admin/menugaleri">Foto Gedung & Kamar</a></p>
    </section>
    <section >
        <p class="title" data-section-title><a href="#">Kuisioner</a></p>
        <div class="content" data-section-content>
          <p><a href="<?php echo base_url();?>index.php/kuisioner/admin">Daftar Kuisioner</a></p>
          <p><a href="<?php echo base_url();?>index.php/kuisioner/admin/isikuisioner">Isi Kuisioner</a></p>
        </div>
    </section>
</div>