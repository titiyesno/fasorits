<?php 
foreach($css_files as $file): ?>
	<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach($js_files as $file): ?>
	<script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
<div id="container">
    <center><h3 class="oxigenfontblue">Galeri Foto <?php echo $datajeniskamar[0]->nama_jenis_kamar;?></h3></center> 
    <hr>
    <div>
            <?php echo $output; ?>
    </div>
    <div class="row">
        <div class="large-3 columns">
        </div>
        <div class="large-9 columns">
            <center><a href="<?php echo base_url(); ?>index.php/kamar/admin/daftar_jeniskamar"><input class="center button" value="Selesai" style="border: 0px; margin-top: 30px"></a></center>
        </div>
    </div>
</div>
    
