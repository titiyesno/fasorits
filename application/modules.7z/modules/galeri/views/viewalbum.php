<?php 
foreach($css_files as $file): ?>
	<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach($js_files as $file): ?>
	<script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
<div id="container">
    <center><h3 class="oxigenfontblue">Galeri Foto <?php echo $datagaleri[0]->NAMA_GALERI;?></h3></center> 
    <hr>
    <div class="row">
        <div class="large-2 columns">
        </div>
        <div class="large-8 columns">
            <?php echo $output; ?>
        </div>
        <div class="large-2 columns">
        </div>
    </div>
    <?php echo form_open("fasilitas/admin/tambahfasilitas_gedung");?>
        <div class="row">
            <div class="large-3 columns">
                <input type="hidden" id="idgedung" name="idgedung" value="<?php echo $idgedung ?>" />
            </div>
            <div class="large-7 columns">
                <center><input class="center button" type="submit" value="Lanjut" style="border: 0px; margin-top: 30px"></center>
            </div>
            <div class="large-2 columns">
            </div>
        </div>
    </form>
</div>
    
